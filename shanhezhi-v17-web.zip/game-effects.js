(function(root,factory){'use strict';const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;root.TKGameEffects=api;})(globalThis,function(root){
  'use strict';
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>Number(n||0).toLocaleString('zh-CN');
  function season(id){
    const stage=root.document?.querySelector('.map-stage');if(!stage||!['spring','summer','autumn','winter'].includes(id))return;
    let layer=stage.querySelector('.season-weather');if(layer?.dataset.season===id)return;
    if(!layer){layer=root.document.createElement('div');layer.className='season-weather';layer.setAttribute('aria-hidden','true');stage.append(layer);}
    layer.dataset.season=id;
    layer.innerHTML=Array.from({length:12},(_,i)=>`<i style="--x:${i%2?81+(i*7)%18:(i*7)%19}%;--drift:${i%2?-35:35}px;--delay:-${i*1.9}s;--duration:${id==='summer'?3+i%3:12+i%7}s;--size:${id==='winter'?3+i%3:5+i%4}px"></i>`).join('');
  }
  function promotionMarkup(result,ours){
    if(!ours||!result.promotions?.length)return '';
    return `<section class="promotion-result" aria-label="参战部队晋阶"><h4>军功晋阶 <small>胜方参战全员 +1 阶</small></h4><div>${result.promotions.map(p=>`<span><strong>${esc(p.name)}</strong><b>${p.from===p.to?'已满 10 阶':p.from+' → '+p.to+' 阶'}</b><small>${esc(p.title)} · 可带 ${fmt(p.capacity)} 兵</small></span>`).join('')}</div></section>`;
  }
  function battleSeal(won){return `<div class="battle-verdict ${won?'is-victory':'is-defeat'}" role="status"><span class="victory-seal" aria-hidden="true">${won?'胜':'整'}</span><div><small>${won?'三军用命 · 此战告捷':'胜负常事 · 来日再战'}</small><strong>${won?'旗开得胜':'收兵整军'}</strong></div>${won?'<i class="victory-arc" aria-hidden="true"></i>':''}</div>`;}
  function prisonResponse(result){
    if(!result?.reply||!result.general)return result?.message?`<p class="people-prison-result" data-prison-result role="status">${esc(result.message)}</p>`:'';
    const g=result.general,portrait=root.TKPortraits?.render(g,{size:'small',isRuler:false})||'';
    return `<section class="prison-response ${result.success?'is-accepted':'is-refused'}" data-prison-result role="status" aria-live="polite"><div class="prison-response-heading">${portrait}<div><small>劝降回应 · ${esc(g.name)}</small><h3>${result.success?'愿意归顺':'拒绝归顺'}</h3></div></div><p class="envoy-request">${esc(result.envoyName)}：${esc(result.envoyLine)}</p><blockquote>“${esc(result.reply)}”</blockquote><p>${result.success?'已加入本城，可安排出征或内政。':'仍在俘虏营，下季可再次劝说。'}</p></section>`;
  }
  function endingMarkup(s,summary){
    const won=s.status==='won',name=s.factions.find(f=>f.id===s.player)?.name||'我方',h=summary;
    const milestones=h.events.filter(e=>e.kind!=='battle'),route=milestones.length>2?milestones:h.events;
    const date=day=>{const d=root.TKCalendar?.fromTotalDays(day);return d?`${d.year}.${String(d.month).padStart(2,'0')}.${String(d.day).padStart(2,'0')}`:`第 ${day} 日`;};
    return `<article class="campaign-finale ${won?'is-victory':'is-defeat'}"><div class="finale-art" aria-hidden="true"><span>${won?'统':'志'}</span><i></i><i></i><i></i></div><small>${esc(name)} · ${won?'一统山河':'征程留名'}</small><h3>${won?'这片山河，记住了你的名字。':'一时成败，困不住你的志向。'}</h3><p class="finale-message">${won?'从一方城池到天下归心，每一次用人、每一场决断，都成就了今日。恭喜你，让战乱止于此刻。':'你曾统兵出征，也曾为一城百姓筹粮。此番征途已留下足迹；带着这次的经验，再择一方，重整旗鼓。'}</p><div class="finale-stats"><span><strong>${fmt(h.days)}</strong>征战日数</span><span><strong>${fmt(h.wins)}</strong>胜仗</span><span><strong>${fmt(h.captures)}</strong>攻取据点</span><span><strong>${fmt(h.peakCities)}</strong>最多城关</span></div>${h.notable.length?`<section class="finale-merit"><h4>功勋人物</h4>${h.notable.map(g=>`<span><b>${esc(g.name)}</b>随军获胜 ${g.wins} 场</span>`).join('')}</section>`:''}<section class="campaign-chronicle"><h4>你的山河征程</h4><p>${h.partial?'本次更新后的征程记录。':'按本局实际经历记载。'}${h.omitted?'早期部分战事已汇总至总战绩。':''}</p><ol>${route.map(e=>`<li class="chronicle-${esc(e.kind)}"><time>${esc(date(e.day))}</time><span>${esc(e.text)}</span></li>`).join('')}</ol></section></article>`;
  }
  if(root.document)root.document.addEventListener('visibilitychange',()=>root.document.body.classList.toggle('effects-paused',root.document.hidden));
  return {season,promotionMarkup,battleSeal,prisonResponse,endingMarkup};
});
