'use strict';
let simulation=null,running=false,timer=null;
const files=['calendar.js','officer-ratings.js','scenario.js','troop-assignments.js','office-titles.js','troops.js','troop-combat.js','personalities.js','campaign-features.js','realm-management.js','war-diplomacy.js','aftermath.js','engine.js'];
function tick(){
  timer=null;if(!running||!simulation)return;
  try{const next=simulation.step(7);postMessage(next.done?{type:'complete',result:next.result}:{type:'progress',progress:next.progress});if(next.done){running=false;simulation=null;}else timer=setTimeout(tick,0);}
  catch(error){running=false;simulation=null;postMessage({type:'error',message:error.message||'推演失败，请重试。'});}
}
onmessage=event=>{
  const data=event.data;
  if(data?.type==='pause'){running=false;if(timer!==null)clearTimeout(timer);timer=null;return;}
  if(data?.type==='resume'&&simulation){if(!running){running=true;timer=setTimeout(tick,0);}return;}
  if(data?.type!=='start'||simulation)return;
  try{
    const base=new URL('.',self.location.href);
    if(!Array.isArray(data.dependencies)||data.dependencies.length!==files.length)throw new Error('推演组件不完整，请刷新游戏。');
    const urls=data.dependencies.map((value,i)=>{const url=new URL(value,base);if(url.origin!==base.origin||url.pathname!==base.pathname+files[i])throw new Error('推演组件路径无效。');return url.href;});
    importScripts(...urls);simulation=TKAftermathModel.create(TKEngine,data.state);running=true;timer=setTimeout(tick,0);
  }catch(error){postMessage({type:'error',message:error.message||'无法加载推演组件。'});}
};
