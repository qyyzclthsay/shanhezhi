(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.TKAftermathModel=api;})(globalThis,function(){
  'use strict';
  const VERSION=1,LIMIT_DAYS=365*15,STALEMATE_DAYS=365*5;
  const record=v=>!!v&&typeof v==='object'&&!Array.isArray(v),integer=(v,min,max)=>Number.isInteger(v)&&v>=min&&v<=max,text=(v,max)=>typeof v==='string'&&v.length<=max;
  function validReport(r,s){
    if(r===undefined)return true;
    if(!record(r)||r.version!==VERSION||s.status!=='lost'||r.sourceDay!==s.totalDays||r.sourcePlayer!==s.player||r.sourceRng!==s.rng||!integer(r.endDay,r.sourceDay,r.sourceDay+LIMIT_DAYS)||!['unified','stalemate','limit'].includes(r.reason)||!integer(r.battles,0,1000000)||!integer(r.cityChanges,0,1000000)||!integer(r.omitted,0,1000000)||!Array.isArray(r.realms)||r.realms.length>s.factions.length||!Array.isArray(r.events)||r.events.length>48)return false;
    const ids=new Set(s.factions.map(f=>f.id)),seen=new Set();let totalCities=0;
    for(const f of r.realms){if(!record(f)||!ids.has(f.id)||f.id===s.player||seen.has(f.id)||!text(f.name,60)||!text(f.leader,30)||!text(f.empire,2)||!integer(f.cities,0,s.cities.length)||!integer(f.troops,0,1000000000)||!integer(f.score,0,1000000000))return false;seen.add(f.id);totalCities+=f.cities;}
    if(totalCities>s.cities.length||!integer(r.neutralCities,0,s.cities.length)||totalCities+r.neutralCities!==s.cities.length)return false;
    if(r.reason==='unified'?(r.realms.length!==1||r.winnerId!==r.realms[0].id||r.realms[0].cities!==s.cities.length||r.neutralCities!==0):r.winnerId!==null)return false;
    if(r.reason==='limit'&&r.endDay-r.sourceDay!==LIMIT_DAYS||r.reason==='stalemate'&&r.endDay-r.sourceDay<STALEMATE_DAYS)return false;
    return r.events.every((e,i)=>record(e)&&integer(e.day,i?r.events[i-1].day:r.sourceDay,r.endDay)&&['capture','elimination','imperial','succession','peace'].includes(e.kind)&&text(e.text,300));
  }
  function create(E,source){
    const prepared=E.createAftermathWorld(source);if(!prepared.ok)throw new Error(prepared.message);
    const s=prepared.world,sourceDay=source.totalDays,sourcePlayer=source.player,sourceRng=source.rng,limitDay=sourceDay+LIMIT_DAYS;
    let winner=prepared.winnerId,result=null,lastChangeDay=sourceDay,battles=0,cityChanges=0,omitted=0,events=[],stepCount=0;
    let owners=s.cities.map(c=>c.owner).join('|');
    const eliminated=new Set(s.eliminations.map(e=>e.id)),empires=new Set(s.factions.filter(f=>f.imperial).map(f=>f.id)),successions=new Set((s.successionEvents||[]).map(e=>e.id)),truces=new Set((s.diplomacy?.truces||[]).map(t=>[t.a,t.b,t.startDay].join('|')));
    const name=id=>{const f=E.getFaction(s,id);return f?.imperial?'「'+f.imperial.name+'」':f?.name||'地方守军';};
    const add=(kind,day,message)=>{events.push({kind,day,text:message});if(events.length>48){events.splice(8,1);omitted++;}};
    function realms(){return s.factions.filter(f=>!E.isFactionEliminated(s,f.id)).map(f=>({id:f.id,name:f.name,leader:f.leader,empire:f.imperial?.name||'',cities:E.ownedCities(s,f.id).length,troops:s.cities.filter(c=>c.owner===f.id).reduce((n,c)=>n+c.troops,0)+s.armies.filter(a=>a.faction===f.id).reduce((n,a)=>n+a.troops,0),score:E.factionStrength(s,f.id).score})).sort((a,b)=>b.score-a.score||b.cities-a.cities||a.id.localeCompare(b.id));}
    function finish(reason){
      result={version:VERSION,sourceDay,sourcePlayer,sourceRng,endDay:s.totalDays,reason,winnerId:reason==='unified'?winner:null,realms:realms(),neutralCities:s.cities.filter(c=>c.owner==='neutral').length,battles,cityChanges,events:events.slice(),omitted};
      if(!validReport(result,source))throw new Error('后续战史校验失败，请重新推演。');
      return result;
    }
    function progress(){const list=realms();return {sourceDay,endDay:s.totalDays,limitDays:LIMIT_DAYS,realmCount:list.length,leader:list[0]||null,battles,cityChanges,events:events.slice(-6)};}
    function step(days=7){
      if(!integer(days,1,30))throw new Error('推演步长无效。');if(result)return {done:true,result};
      if(winner)return {done:true,result:finish('unified')};
      for(let i=0;i<days&&!result;i++){
        // A fixed one-day engine step makes pause/resume timing irrelevant to RNG.
        const r=E.advanceAftermathWorld(s,1);if(!r.ok||r.daysAdvanced!==1&&!(r.daysAdvanced===0&&r.winnerId))throw new Error(r.message||'推演未能继续。');winner=r.winnerId;stepCount++;
        for(const b of r.battles||[]){if(!b.result.unopposed)battles++;if(b.result.captured){cityChanges++;add('capture',s.totalDays,name(b.battle.attackerFaction)+'攻取'+E.getCity(s,b.battle.toId).name+'。');}}
        for(const e of s.eliminations)if(!eliminated.has(e.id)){eliminated.add(e.id);add('elimination',e.totalDays,name(e.faction)+(e.type==='submission'?'归顺':'败亡')+(e.byFaction?'，归于'+name(e.byFaction):'')+'。');}
        for(const f of s.factions)if(f.imperial&&!empires.has(f.id)){empires.add(f.id);add('imperial',f.imperial.declaredDay,f.leader+'称帝，国号「'+f.imperial.name+'」。');}
        for(const e of s.successionEvents||[])if(!successions.has(e.id)){successions.add(e.id);if(e.type==='succession')add('succession',e.totalDays,e.message);}
        for(const t of s.diplomacy?.truces||[]){const key=[t.a,t.b,t.startDay].join('|');if(!truces.has(key)){truces.add(key);add('peace',t.startDay,name(t.a)+'与'+name(t.b)+'议和休兵。');}}
        events.sort((a,b)=>a.day-b.day);
        const next=s.cities.map(c=>c.owner).join('|');if(next!==owners){lastChangeDay=s.totalDays;owners=next;}
        if(stepCount%90===0&&!E.validateState(s))throw new Error('推演状态校验失败，原征程未被改动。');
        if(winner)finish('unified');
        else if(s.totalDays>=limitDay)finish('limit');
        else if(s.totalDays-lastChangeDay>=STALEMATE_DAYS&&!s.armies.some(a=>a.kind==='attack'))finish('stalemate');
      }
      return result?{done:true,result}:{done:false,progress:progress()};
    }
    return {step,progress};
  }
  return {VERSION,LIMIT_DAYS,STALEMATE_DAYS,validReport,create};
});
