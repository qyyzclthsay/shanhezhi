(function(root,factory){
  'use strict';
  const api=factory(root,typeof module==='object'&&module.exports?require('./personalities.js'):root.TKPersonalities);
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.TKAtmosphere=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root,personalities){
  'use strict';
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const opening={
    曹操:'天下未定，先立根基，再图四方。',
    刘备:'愿与诸君同心，让百姓有安身之地。',
    孙策:'江东虽小，足以起家。诸君，随我开路！',
    袁绍:'兵粮既备，当与诸君共定大局。',
    吕布:'兵锋所指，谁敢拦我？',
    袁术:'先丰府库，再聚雄兵。',
    公孙瓒:'守好北地，莫让百姓再受兵灾。',
    马腾:'西凉儿郎，先养战马，再试锋芒。',
    李傕:'守住关中，方有立足之本。',
    刘表:'荆襄之地，当先安民、足食。',
    刘璋:'蜀道有险，更要有人守、有粮用。',
    张鲁:'汉中虽小，亦能护一方安宁。',
    刘繇:'立足江东，今日便从这里开始。',
    王朗:'城有良治，民有余粮，才可久守。',
    陶谦:'徐州百姓，还望诸君一同照拂。',
    孔融:'聚贤养民，城小亦可有所作为。'
  };
  // Original game dialogue, selected from the officers actually in this army.
  const voices={
    曹操:['看清虚实，再破其阵。','阵脚未乱，何必惧他？','莫急，胜机就在下一合。'],
    刘备:['诸军随我，勿伤无辜！','城中百姓在后，此阵不可失。','稳住阵脚，我与诸君同在！'],
    孙策:['随我冲阵，打开一条路！','江东子弟，列阵迎敌！','再进一阵，莫让敌军喘息！'],
    关羽:['关某在此，请来接战！','且看你如何过我这一关。','收拢阵形，随关某再战！'],
    张飞:['前面的，来与我较量！','想过此阵，先问过俺！','跟紧俺，一鼓作气！'],
    赵云:['诸军跟紧，莫乱阵形！','有我在，此路不会失守。','护住两翼，随我向前！'],
    吕布:['谁敢挡我兵锋？','放马过来，吕布在此！','随我再冲，打穿此阵！'],
    周瑜:['先断其势，再破其阵。','敌军虽众，未必无隙。','稳住中军，待其阵形松动。'],
    诸葛亮:['依计进军，切勿贪功。','各守其位，静候敌变。','阵势尚在，勿自乱方寸。'],
    陆逊:['先察虚实，莫被声势所惑。','守稳阵脚，等他露出破绽。','敌势渐缓，正可从容应对。'],
    马超:['西凉铁骑，随我向前！','此路有我，休想轻过！','策马再进，冲开敌阵！'],
    黄忠:['老夫这张弓，还拉得开！','来得正好，且试老夫弓力！','稳住，老夫尚有余力！'],
    太史慈:['阵前较量，各凭本事！','想破此阵，先胜过我！','随我再战，莫负此身胆气！'],
    夏侯惇:['随我进军，不可迟疑！','守住阵线，迎敌！','伤亡各有，阵脚不可乱！'],
    张辽:['看准敌隙，随我突进！','列阵待敌，勿失号令。','集中兵力，再破一路！'],
    甘宁:['健儿们，随我抢下此阵！','此处有我，休想讨巧！','趁势向前，别给他整阵的机会！']
  };
  const specialPairs=[
    ['刘备','曹操','孟德，此战各为其志。','玄德，阵前便各尽所能。'],
    ['张飞','吕布','吕布，来与俺正面一战！','张翼德，且看你有几分本事！'],
    ['关羽','曹操','此阵既开，关某便不留手。','云长的本事，我自会领教。'],
    ['孙策','太史慈','子义，今日便较量一场！','伯符，请出招！'],
    ['周瑜','曹操','兵多未必阵稳，请君细看。','公瑾，妙计还要阵前见分晓。']
  ];
  const choose=(lines,key)=>{
    let hash=0;for(const c of String(key))hash=(Math.imul(hash,31)+c.charCodeAt(0))>>>0;
    return lines[hash%lines.length];
  };
  function actionLine(g,event,city,context={}){
    if(!g)return null;
    const place=city?.name||'此地',martial=Number(g.force)>=Number(g.intellect);
    const person=personalities?.voiceFor(g),partners=context.partner?[context.partner]:context.companions||[];
    for(const partner of partners){
      if(event!=='surrender'&&g.faction&&partner?.faction&&g.faction!==partner.faction)continue;
      const paired=personalities?.pairLine(g,partner,event,context);
      if(paired)return paired;
    }
    if(event==='surrender'||event==='hire')return person?.[context.success===true?'accept':'refuse']||(context.success===true?'既蒙诚意相待，愿尽一份力。':'去就尚未想定，请容我再思。');
    if(person){
      if(['march','transfer','occupy'].includes(event))return person.march.replaceAll('{city}',place);
      const tasks={governor:'掌理政务',farming:'经营农田',commerce:'疏通商市',training:'整饬城防',search:'寻访人才'};
      if(tasks[event])return place+'，'+tasks[event]+'。'+person.assignment;
    }
    const named={
      关羽:{governor:'既领此任，关某自当安民守土。',training:'整顿城防，勿使敌军有隙可乘。',march:'诸军听令，随关某向'+place+'进军！'},
      张飞:{governor:'这座城交给俺，定当尽心守好！',training:'都打起精神，城防容不得马虎！',march:'目标'+place+'，都跟紧俺！'},
      刘备:{governor:'先安百姓，再足府库，不负这一城所托。',farming:'农事关乎百姓生计，务必用心。',march:'诸军随我前往'+place+'，沿途勿扰百姓。'},
      曹操:{governor:'理清钱粮，安定民心，城中诸务不可废。',commerce:'通商足用，府库充实方可图远。',march:'整军前往'+place+'，各部依令而行。'},
      孙策:{governor:'城中有粮，军中有志，便可再图大业。',march:'将士们，随我向'+place+'开路！'}
    };
    const lines={
      governor:['既受此任，当理好钱粮，安定一城。','城中诸务交给我，先安民，再足食。'],
      farming:['察看田亩，安排农事，务使仓廪充实。','农时不可误，我这便去安排。'],
      commerce:['整顿市肆，疏通商路，让城中财货流通。','税赋贵在有度，市井兴旺方能长久。'],
      training:['巡查城垣，修备守具，防务不可松懈。','城防交给我，各处要隘逐一查验。'],
      search:['此行访贤问能，愿为主公寻得良才。','我去探访乡里，看看可有未仕之才。'],
      transfer:['奉命前往'+place+'，沿途谨慎行军。','这便启程赴'+place+'，到城后听候调遣。'],
      occupy:['进驻'+place+'，先安民、再整备守军。','入驻'+place+'，严明军纪，不扰百姓。'],
      march:martial?['诸军整队，向'+place+'进军！','兵锋指向'+place+'，随我出发！']:['目标'+place+'，依计进军，莫乱阵形。','前往'+place+'，先察敌情，再寻战机。']
    };
    if(!lines[event])return null;
    return named[g.name]?.[event]||choose(lines[event],g.id+event+place);
  }
  function lineFor(g,side,phase,key){
    const personal=personalities?.voiceFor(g);
    if(personal)return personal[phase==='rally'?'rally':side==='attacker'?'attack':'defend'];
    const voice=voices[g.name];if(voice)return voice[phase==='rally'?2:side==='attacker'?0:1];
    const clever=Number(g.intellect)>Number(g.force);
    const lines=phase==='rally'
      ?clever?['先稳阵脚，胜负尚未可知。','敌阵有隙，各部依令而动。']:['诸军莫散，跟紧旗号！','相互策应，合力再战！']
      :side==='attacker'
        ?clever?['敌阵未固，依计而进。','先试其虚实，再定进退。']:['诸军听令，随我破阵！','旗号向前，全军进击！']
        :clever?['不必急战，先看敌军动向。','据阵相守，勿让敌军得隙。']:['守住阵线，迎敌！','此阵在前，岂容轻过！'];
    return choose(lines,key+g.id+phase);
  }
  function battleExchange(battle,frame=null,phase='opening'){
    const alive=side=>(battle[side+'Generals']||[]).slice(0,5).filter((g,i)=>{
      const cards=Array.isArray(frame?.[side])?frame[side]:frame?.[side]?.cards;
      return !frame||Number(cards?.[i]?.troops)>0;
    });
    const armies={attacker:alive('attacker'),defender:alive('defender')};
    if(phase==='opening'){
      const pair=personalities?.encounter(armies.attacker,armies.defender,'battle');
      if(pair)return [{side:'attacker',general:pair.one,text:pair.lineOne},{side:'defender',general:pair.two,text:pair.lineTwo}];
    }
    const entries=['attacker','defender'].map(side=>{
      const general=armies[side][0];if(!general)return null;
      return {side,general,text:lineFor(general,side,phase,battle.id||battle.seed||'')};
    }).filter(Boolean);
    if(phase==='opening'&&entries.length===2){
      const a=entries[0],d=entries[1];
      for(const [one,two,lineOne,lineTwo] of specialPairs){
        if(a.general.name===one&&d.general.name===two){a.text=lineOne;d.text=lineTwo;break;}
        if(a.general.name===two&&d.general.name===one){a.text=lineTwo;d.text=lineOne;break;}
      }
    }
    return entries;
  }
  function victoryLine(battle,result){
    const side=result.winner;if(!['attacker','defender'].includes(side))return null;
    const last=result.simulation?.frames?.at(-1)?.[side];
    const cards=Array.isArray(last)?last:last?.cards;
    const general=(battle[side+'Generals']||[]).slice(0,5).find((g,i)=>!last||cards?.[i]?.troops>0);
    if(!general)return null;
    const person=personalities?.voiceFor(general),conclusion=side==='defender'?'此阵守住了，先救治伤兵。':result.remainingDefenseTeams>0?'此阵已破，整军再定进退。':'收拢各部，照看伤兵。';
    return {side,general,text:person?.victory?conclusion+' '+person.victory:conclusion};
  }
  function exchangeMarkup(entries,left){
    if(!entries.length)return '';
    const order=[left,left==='attacker'?'defender':'attacker'];
    return order.map(side=>{
      const entry=entries.find(x=>x.side===side);
      return `<div class="battle-voice ${side===left?'is-ours':'is-theirs'}">${entry?`<strong>${esc(entry.general.name)}</strong><p>“${esc(entry.text)}”</p>`:''}</div>`;
    }).join('');
  }
  function mountBattle(host,battle,left){
    if(!host)return null;
    let stage='';
    return {update(frame,progress,elapsed){
      // Fast playback retains the opening exchange instead of flashing text.
      const next=progress>=.42&&elapsed>=5000?'rally':'opening';
      if(progress>=1||next===stage)return;
      stage=next;
      const entries=battleExchange(battle,frame,stage);
      host.hidden=!entries.length;host.innerHTML=exchangeMarkup(entries,left);
    }};
  }
  let entryScene=null,greeting=null,greetingTimer=null;
  function dismissGreeting(){
    root.clearTimeout(greetingTimer);greetingTimer=null;
    greeting?.remove();greeting=null;
  }
  function showSpeech(leader,faction,text,{host,action=false,label=''}={}){
    dismissGreeting();if(!host||!leader||!text)return false;
    greeting=root.document.createElement('aside');greeting.className='campaign-greeting';
    if(action)greeting.classList.add('action-speech');
    if(host.classList?.contains('dialog-header'))greeting.classList.add('dialog-speech');
    greeting.setAttribute('role','status');greeting.setAttribute('aria-live','polite');
    if(/^#[\da-f]{6}$/i.test(faction?.color||''))greeting.style.setProperty('--voice-color',faction.color);
    greeting.innerHTML=`<span class="greeting-portrait" aria-hidden="true">${root.TKPortraits?.render(leader,{size:'small'})||''}</span><div><strong>${esc(leader.name)}</strong>${label?`<small class="speech-context">${esc(label)}</small>`:''}<p>${esc(text)}</p></div><button type="button" aria-label="收起人物对话">×</button>`;
    greeting.querySelector('button').onclick=dismissGreeting;host.append(greeting);
    greetingTimer=root.setTimeout(dismissGreeting,5500);
    return true;
  }
  function greet(leader,faction){
    const profile=personalities?.profileFor(faction,leader);
    return showSpeech(leader,faction,profile?.opening||opening[leader?.name]||'先安一城，再谋天下。诸君，与我同行。',{host:root.document?.querySelector('.map-stage'),label:profile?.label||''});
  }
  function speak({general,faction,event,city,label,companions=[],partner,success}={}){
    const text=actionLine(general,event,city,{companions,partner,success});if(!text)return false;
    const roles={governor:'任太守',farming:'掌农田',commerce:'理集市',training:'督城防',search:'出城寻访',march:'出征',occupy:'进驻',transfer:'调任',surrender:success===true?'应允归顺':'暂拒归顺'};
    const host=root.document?.querySelector('#main-dialog[open] .dialog-header')||root.document?.querySelector('.app-shell');
    return showSpeech(general,faction,text,{host,action:true,label:label||[city?.name,roles[event]].filter(Boolean).join(' · ')});
  }
  function enter({faction,location,onReveal,onFinish}){
    if(entryScene)return false;
    dismissGreeting();
    if(root.matchMedia?.('(prefers-reduced-motion: reduce)').matches){onReveal();onFinish?.();return true;}
    const doc=root.document,overlay=doc.createElement('div');
    overlay.className='entry-scene';overlay.setAttribute('role','status');
    overlay.setAttribute('aria-label','云雾散开，进入游戏');
    const billows='<i class="fog-billow fog-billow-high"></i><i class="fog-billow fog-billow-mid"></i><i class="fog-billow fog-billow-low"></i>';
    overlay.innerHTML=`<div class="entry-fog entry-fog-left" aria-hidden="true">${billows}</div><div class="entry-fog entry-fog-right" aria-hidden="true">${billows}</div><div class="entry-inscription" aria-hidden="true"><span>群雄割据</span><strong>${esc(location||'山河')}</strong><i></i><small>${esc(faction?.leader||faction?.name||'')} · 征程初启</small></div>`;
    const targets=[doc.querySelector('.app-shell'),doc.getElementById('start-screen')].filter(Boolean);
    const inert=targets.map(el=>el.inert);targets.forEach(el=>el.inert=true);
    let timer=null,raf=null,revealed=false,finished=false;
    const finish=(notify=true)=>{
      if(finished)return;finished=true;
      root.clearTimeout(timer);root.cancelAnimationFrame(raf);doc.removeEventListener('keydown',onKey);
      overlay.remove();targets.forEach((el,i)=>el.inert=inert[i]);entryScene=null;
      if(notify&&revealed)onFinish?.();
    };
    const onKey=event=>{if(event.key==='Escape'&&revealed){event.preventDefault();finish();}};
    entryScene={cancel:()=>finish(false)};
    doc.body.append(overlay);doc.addEventListener('keydown',onKey);
    raf=root.requestAnimationFrame(()=>{
      try{
        onReveal();revealed=true;overlay.classList.add('is-opening');
        timer=root.setTimeout(()=>finish(),2700);
      }catch(error){finish(false);throw error;}
    });
    return true;
  }
  function clear(){entryScene?.cancel();dismissGreeting();}
  return {enter,clear,dismissSpeech:dismissGreeting,greet,speak,actionLine,battleExchange,victoryLine,exchangeMarkup,mountBattle,get entering(){return !!entryScene;}};
});
