(function(root,factory){
  'use strict';
  const api=factory(root);
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.TKAtmosphere=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  'use strict';
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const opening={
    曹操:'天下未定，先立根基，再图四方。',
    刘备:'愿与诸君同心，让百姓有安身之地。',
    孙策:'江东虽小，足以起家。诸君，随我开路！',
    袁绍:'兵粮既备，当与诸君共定大局。',
    吕布:'兵锋所指，谁敢拦我？',
    袁术:'先丰府库，再聚雄兵。',
    公孙瓒:'守好北地，莫让百姓再受兵灾。',
    马腾:'西凉儿郎，先养战马，再试锋芒。',
    李傕:'守住关中，方有立足之本。',
    刘表:'荆襄之地，当先安民、足食。',
    刘璋:'蜀道有险，更要有人守、有粮用。',
    张鲁:'汉中虽小，亦能护一方安宁。',
    刘繇:'立足江东，今日便从这里开始。',
    王朗:'城有良治，民有余粮，才可久守。',
    陶谦:'徐州百姓，还望诸君一同照拂。',
    孔融:'聚贤养民，城小亦可有所作为。'
  };
  // Original game dialogue, selected from the officers actually in this army.
  const voices={
    曹操:['看清虚实，再破其阵。','阵脚未乱，何必惧他？','莫急，胜机就在下一合。'],
    刘备:['诸军随我，勿伤无辜！','城中百姓在后，此阵不可失。','稳住阵脚，我与诸君同在！'],
    孙策:['随我冲阵，打开一条路！','江东子弟，列阵迎敌！','再进一阵，莫让敌军喘息！'],
    关羽:['关某在此，请来接战！','且看你如何过我这一关。','收拢阵形，随关某再战！'],
    张飞:['前面的，来与我较量！','想过此阵，先问过俺！','跟紧俺，一鼓作气！'],
    赵云:['诸军跟紧，莫乱阵形！','有我在，此路不会失守。','护住两翼，随我向前！'],
    吕布:['谁敢挡我兵锋？','放马过来，吕布在此！','随我再冲，打穿此阵！'],
    周瑜:['先断其势，再破其阵。','敌军虽众，未必无隙。','稳住中军，待其阵形松动。'],
    诸葛亮:['依计进军，切勿贪功。','各守其位，静候敌变。','阵势尚在，勿自乱方寸。'],
    陆逊:['先察虚实，莫被声势所惑。','守稳阵脚，等他露出破绽。','敌势渐缓，正可从容应对。'],
    马超:['西凉铁骑，随我向前！','此路有我，休想轻过！','策马再进，冲开敌阵！'],
    黄忠:['老夫这张弓，还拉得开！','来得正好，且试老夫弓力！','稳住，老夫尚有余力！'],
    太史慈:['阵前较量，各凭本事！','想破此阵，先胜过我！','随我再战，莫负此身胆气！'],
    夏侯惇:['随我进军，不可迟疑！','守住阵线，迎敌！','伤亡各有，阵脚不可乱！'],
    张辽:['看准敌隙，随我突进！','列阵待敌，勿失号令。','集中兵力，再破一路！'],
    甘宁:['健儿们，随我抢下此阵！','此处有我，休想讨巧！','趁势向前，别给他整阵的机会！']
  };
  const specialPairs=[
    ['刘备','曹操','孟德，此战各为其志。','玄德，阵前便各尽所能。'],
    ['张飞','吕布','吕布，来与俺正面一战！','张翼德，且看你有几分本事！'],
    ['关羽','曹操','此阵既开，关某便不留手。','云长的本事，我自会领教。'],
    ['孙策','太史慈','子义，今日便较量一场！','伯符，请出招！'],
    ['周瑜','曹操','兵多未必阵稳，请君细看。','公瑾，妙计还要阵前见分晓。']
  ];
  const choose=(lines,key)=>{
    let hash=0;for(const c of String(key))hash=(Math.imul(hash,31)+c.charCodeAt(0))>>>0;
    return lines[hash%lines.length];
  };
  function lineFor(g,side,phase,key){
    const voice=voices[g.name];if(voice)return voice[phase==='rally'?2:side==='attacker'?0:1];
    const clever=Number(g.intellect)>Number(g.force);
    const lines=phase==='rally'
      ?clever?['先稳阵脚，胜负尚未可知。','敌阵有隙，各部依令而动。']:['诸军莫散，跟紧旗号！','相互策应，合力再战！']
      :side==='attacker'
        ?clever?['敌阵未固，依计而进。','先试其虚实，再定进退。']:['诸军听令，随我破阵！','旗号向前，全军进击！']
        :clever?['不必急战，先看敌军动向。','据阵相守，勿让敌军得隙。']:['守住阵线，迎敌！','此阵在前，岂容轻过！'];
    return choose(lines,key+g.id+phase);
  }
  function battleExchange(battle,frame=null,phase='opening'){
    const entries=['attacker','defender'].map(side=>{
      const list=(battle[side+'Generals']||[]).slice(0,5);
      const index=list.findIndex((g,i)=>!frame||Number(frame[side]?.cards?.[i]?.troops)>0);
      if(index<0)return null;
      const general=list[index];
      return {side,general,text:lineFor(general,side,phase,battle.id||battle.seed||'')};
    }).filter(Boolean);
    if(phase==='opening'&&entries.length===2){
      const a=entries[0],d=entries[1];
      for(const [one,two,lineOne,lineTwo] of specialPairs){
        if(a.general.name===one&&d.general.name===two){a.text=lineOne;d.text=lineTwo;break;}
        if(a.general.name===two&&d.general.name===one){a.text=lineTwo;d.text=lineOne;break;}
      }
    }
    return entries;
  }
  function victoryLine(battle,result){
    const side=result.winner;if(!['attacker','defender'].includes(side))return null;
    const last=result.simulation?.frames?.at(-1)?.[side];
    const general=(battle[side+'Generals']||[]).slice(0,5).find((g,i)=>!last||last[i]?.troops>0);
    if(!general)return null;
    return {side,general,text:side==='defender'?'此阵守住了，先救治伤兵。':result.remainingDefenseTeams>0?'此阵已破，整军再定进退。':'收拢各部，照看伤兵。'};
  }
  function exchangeMarkup(entries,left){
    if(!entries.length)return '';
    const order=[left,left==='attacker'?'defender':'attacker'];
    return order.map(side=>{
      const entry=entries.find(x=>x.side===side);
      return `<div class="battle-voice ${side===left?'is-ours':'is-theirs'}">${entry?`<strong>${esc(entry.general.name)}</strong><p>“${esc(entry.text)}”</p>`:''}</div>`;
    }).join('');
  }
  function mountBattle(host,battle,left){
    if(!host)return null;
    let stage='';
    return {update(frame,progress,elapsed){
      // Fast playback retains the opening exchange instead of flashing text.
      const next=progress>=.42&&elapsed>=5000?'rally':'opening';
      if(progress>=1||next===stage)return;
      stage=next;
      const entries=battleExchange(battle,frame,stage);
      host.hidden=!entries.length;host.innerHTML=exchangeMarkup(entries,left);
    }};
  }
  let entryScene=null,greeting=null,greetingTimer=null;
  function dismissGreeting(){
    root.clearTimeout(greetingTimer);greetingTimer=null;
    greeting?.remove();greeting=null;
  }
  function greet(leader,faction){
    dismissGreeting();const map=root.document?.querySelector('.map-stage');if(!map||!leader)return;
    greeting=root.document.createElement('aside');greeting.className='campaign-greeting';
    greeting.setAttribute('role','status');greeting.setAttribute('aria-live','polite');
    if(/^#[\da-f]{6}$/i.test(faction?.color||''))greeting.style.setProperty('--voice-color',faction.color);
    greeting.innerHTML=`<span class="greeting-portrait" aria-hidden="true">${root.TKPortraits?.render(leader,{size:'small'})||''}</span><div><strong>${esc(leader.name)}</strong><p>${esc(opening[leader.name]||'先安一城，再谋天下。诸君，与我同行。')}</p></div><button type="button" aria-label="收起人物对话">×</button>`;
    greeting.querySelector('button').onclick=dismissGreeting;map.append(greeting);
    greetingTimer=root.setTimeout(dismissGreeting,5500);
  }
  function enter({faction,location,onReveal,onFinish}){
    if(entryScene)return false;
    dismissGreeting();
    if(root.matchMedia?.('(prefers-reduced-motion: reduce)').matches){onReveal();onFinish?.();return true;}
    const doc=root.document,overlay=doc.createElement('div');
    overlay.className='entry-scene';overlay.setAttribute('role','status');
    overlay.setAttribute('aria-label','云雾散开，进入游戏');
    overlay.innerHTML=`<div class="entry-fog entry-fog-left" aria-hidden="true"></div><div class="entry-fog entry-fog-right" aria-hidden="true"></div><div class="entry-inscription" aria-hidden="true"><span>群雄割据</span><strong>${esc(location||'山河')}</strong><i></i><small>${esc(faction?.leader||faction?.name||'')} · 征程初启</small></div>`;
    const targets=[doc.querySelector('.app-shell'),doc.getElementById('start-screen')].filter(Boolean);
    const inert=targets.map(el=>el.inert);targets.forEach(el=>el.inert=true);
    let timer=null,raf=null,revealed=false,finished=false;
    const finish=(notify=true)=>{
      if(finished)return;finished=true;
      root.clearTimeout(timer);root.cancelAnimationFrame(raf);doc.removeEventListener('keydown',onKey);
      overlay.remove();targets.forEach((el,i)=>el.inert=inert[i]);entryScene=null;
      if(notify&&revealed)onFinish?.();
    };
    const onKey=event=>{if(event.key==='Escape'&&revealed){event.preventDefault();finish();}};
    entryScene={cancel:()=>finish(false)};
    doc.body.append(overlay);doc.addEventListener('keydown',onKey);
    raf=root.requestAnimationFrame(()=>{
      try{
        onReveal();revealed=true;overlay.classList.add('is-opening');
        timer=root.setTimeout(()=>finish(),2200);
      }catch(error){finish(false);throw error;}
    });
    return true;
  }
  function clear(){entryScene?.cancel();dismissGreeting();}
  return {enter,clear,greet,battleExchange,victoryLine,exchangeMarkup,mountBattle,get entering(){return !!entryScene;}};
});
