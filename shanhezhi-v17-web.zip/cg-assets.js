/* User-supplied CG artwork. Full images preserve their original pixel dimensions. */
(function(root,factory){'use strict';if(typeof module==='object'&&module.exports)module.exports=factory();else root.TKCGAssets=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';return {
  "opening": [
    {
      "id": "opening-1",
      "title": "乱世初起",
      "thumb": "assets/cg/opening-1-thumb-871b8334dc3a.webp",
      "full": "assets/cg/opening-1-full-63967fcaf4fa.webp",
      "width": 941,
      "height": 1672
    }
  ],
  "capture": [
    {
      "id": "capture-1",
      "title": "旌旗入城",
      "thumb": "assets/cg/capture-1-thumb-bb629aab0126.webp",
      "full": "assets/cg/capture-1-full-ec7c013854d3.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "capture-2",
      "title": "入主城府",
      "thumb": "assets/cg/capture-2-thumb-b749a8fba68c.webp",
      "full": "assets/cg/capture-2-full-21505b1af189.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "capture-3",
      "title": "新旗映阙",
      "thumb": "assets/cg/capture-3-thumb-c569b5d1e650.webp",
      "full": "assets/cg/capture-3-full-4282a24caf94.webp",
      "width": 941,
      "height": 1672
    }
  ],
  "loss": [
    {
      "id": "loss-1",
      "title": "孤舟暮渡",
      "thumb": "assets/cg/loss-1-thumb-9dbcd104102f.webp",
      "full": "assets/cg/loss-1-full-f951b2e0f2ba.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "loss-2",
      "title": "残垒暮色",
      "thumb": "assets/cg/loss-2-thumb-c74722e1eefc.webp",
      "full": "assets/cg/loss-2-full-6bd138572791.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "loss-3",
      "title": "烽火城破",
      "thumb": "assets/cg/loss-3-thumb-102eccf402bf.webp",
      "full": "assets/cg/loss-3-full-95d1b78f2aa0.webp",
      "width": 941,
      "height": 1672
    }
  ],
  "empire": [
    {
      "id": "empire-1",
      "title": "百官奉诏",
      "thumb": "assets/cg/empire-1-thumb-b9006edb855a.webp",
      "full": "assets/cg/empire-1-full-727d99e7edf2.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "empire-2",
      "title": "临轩建国",
      "thumb": "assets/cg/empire-2-thumb-e4f2378b60e3.webp",
      "full": "assets/cg/empire-2-full-63fcb80cf45b.webp",
      "width": 940,
      "height": 1672
    }
  ],
  "victory": [
    {
      "id": "victory-1",
      "title": "四海归心",
      "thumb": "assets/cg/victory-1-thumb-08f10e3339cd.webp",
      "full": "assets/cg/victory-1-full-875ecd848ac1.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "victory-2",
      "title": "天下归一",
      "thumb": "assets/cg/victory-2-thumb-4bc812202d06.webp",
      "full": "assets/cg/victory-2-full-cd1ba8903819.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "victory-3",
      "title": "凯歌入阙",
      "thumb": "assets/cg/victory-3-thumb-b3046d64aa08.webp",
      "full": "assets/cg/victory-3-full-70227db06a10.webp",
      "width": 941,
      "height": 1672
    }
  ],
  "defeat": [
    {
      "id": "defeat-1",
      "title": "城门辞印",
      "thumb": "assets/cg/defeat-1-thumb-2ad4a3e83f3c.webp",
      "full": "assets/cg/defeat-1-full-20f1ce383468.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "defeat-2",
      "title": "残旗余晖",
      "thumb": "assets/cg/defeat-2-thumb-1ec91d2eef4e.webp",
      "full": "assets/cg/defeat-2-full-12253d6ff43c.webp",
      "width": 941,
      "height": 1672
    },
    {
      "id": "defeat-3",
      "title": "囹圄余光",
      "thumb": "assets/cg/defeat-3-thumb-95d72b6eda47.webp",
      "full": "assets/cg/defeat-3-full-efa828fbd418.webp",
      "width": 941,
      "height": 1672
    }
  ]
};});
