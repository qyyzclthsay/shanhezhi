(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.TKOfficeTitles=api;})(globalThis,function(){
  'use strict';
  // Game progression offices, not a reconstruction of one historical bureaucracy.
  // Offices recognize the campaign record; they never alter command or combat.
  const pools={
    military:[['队率','屯长','军吏'],['军侯','别部军侯','督战军侯'],['司马','别部司马','行军司马'],['都尉','骑都尉','奉车都尉'],['校尉','奋威校尉','讨逆校尉','护军校尉'],['裨将军','牙门将军','偏裨将军'],['偏将军','讨虏将军','破虏将军','荡寇将军'],['中郎将','前将军','后将军','左将军','右将军'],['征东将军','征西将军','征南将军','征北将军','镇军将军'],['大将军','骠骑将军','车骑将军','卫将军']],
    civil:[['书佐','令史','掾史'],['主簿','功曹史','记室'],['功曹','治中从事','别驾从事'],['县令','县长','长史'],['郡丞','司直','参军'],['治中','谏议大夫','议郎'],['别驾','侍中','给事中'],['尚书','光禄大夫','太常'],['尚书令','中书令','御史大夫','少府'],['丞相','太尉','司徒','司空']]
  };
  const safe={military:['队率','军侯','司马','都尉','校尉','裨将军','偏将军','中郎将','镇军将军','领军将军'],civil:['书佐','主簿','功曹','县令','郡丞','治中','别驾','尚书','少府','议政大臣']};
  const rank=g=>Math.max(1,Math.min(10,Math.floor(g?.officialRank||(g?.role==='ruler'?2:1))));
  const track=g=>g?.role==='civil'||g?.role==='ruler'&&(g.intellect||0)>(g.force||0)+10?'civil':'military';
  const fallback=(level,kind)=>safe[kind==='civil'?'civil':'military'][Math.max(1,Math.min(10,Math.floor(level)||1))-1];
  const merit=g=>Object.fromEntries(['wins','captures','defenses','defeats'].map(k=>[k,Math.max(0,Math.floor(Number(g?.merit?.[k])||0))]));
  const score=g=>{const m=merit(g);return m.wins+m.captures*2+m.defenses-m.defeats;};
  function compare(a,b){const x=merit(a),y=merit(b);return score(b)-score(a)||y.captures-x.captures||y.defenses-x.defenses||y.wins-x.wins||x.defeats-y.defeats||String(a.id).localeCompare(String(b.id));}
  function valid(g,level=rank(g),kind=track(g)){
    return g?.officeRank===level&&g.officeFaction===g.faction&&(pools[kind][level-1].includes(g.officeTitle)||g.officeTitle===fallback(level,kind));
  }
  function assign(generals,factions){
    const eligibleFactions=new Set((factions||[]).map(f=>typeof f==='string'?f:f.id)),groups=new Map();
    for(const g of generals||[]){
      if(!eligibleFactions.has(g.faction)||!['serving','marching'].includes(g.status)||g.garrison){delete g.officeTitle;delete g.officeRank;delete g.officeFaction;continue;}
      const key=g.faction+'|'+track(g)+'|'+rank(g);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(g);
    }
    for(const group of groups.values())group.sort(compare).forEach((g,i)=>{const level=rank(g),kind=track(g);g.officeTitle=pools[kind][level-1][i]||fallback(level,kind);g.officeRank=level;g.officeFaction=g.faction;});
    return generals;
  }
  return {assign,track,fallback,valid,pools,score};
});
