(function(root){
  'use strict';let api;
  const node=id=>document.getElementById(id),esc=v=>api.esc(String(v??'')),fmt=v=>api.fmt(v);
  function entry(city){
    if(!api)return '';const s=api.getState(),q=api.E.cityPlanningStatus(s,city.id),own=city.owner===s.player;
    return `<div class="city-planning-entry"><span><b>${esc(api.E.cityFocuses[q.focus].name)}</b>${q.pending?' · 下季 '+esc(api.E.cityFocuses[q.pending.kind].name):''}${own?' · '+esc(q.automation.goal==='off'?'手动经营':q.pause||api.E.stewardshipGoals[q.automation.goal]):''}</span>${own?`<button type="button" data-city-planning="${esc(city.id)}">城务规划 ›</button>`:''}</div>`;
  }
  function bind(scope){scope.querySelectorAll('[data-city-planning]').forEach(b=>b.onclick=()=>show(b.dataset.cityPlanning));}
  function show(cityId,message=''){
    if(!api)return;root.TKCampaign?.pause?.();const s=api.getState(),E=api.E,c=E.getCity(s,cityId);if(!c||c.owner!==s.player)return;
    const q=E.cityPlanningStatus(s,cityId),focus=q.pending?.kind||q.focus;
    const field=(id,label,value,max)=>`<label>${label}<input type="number" inputmode="numeric" id="planning-${id}" min="0" max="${max}" step="1" value="${value}" required></label>`;
    const body=`<div class="city-planning-panel"><p class="planning-status" id="planning-status" role="status">${esc(message||'保存设置不扣费；发展方向下季生效，托管在推进时间后执行。')}</p><fieldset class="planning-focus"><legend>本城发展方向</legend><div>${Object.entries(E.cityFocuses).filter(([key])=>c.kind!=='pass'||['balanced','military'].includes(key)).map(([key,v])=>`<label><input type="radio" name="city-focus" value="${key}"${key===focus?' checked':''}><span><strong>${esc(v.name)}</strong><small>${esc(v.description)}</small></span></label>`).join('')}</div></fieldset><p class="planning-income" id="planning-income"></p><p class="city-planning-note">当前为${esc(E.cityFocuses[q.focus].name)}。每城一个方向，可在生效前调整或选回原方向取消；关口仅可均衡或军镇。</p><fieldset><legend>本城后方托管</legend><div class="planning-fields"><label>经营目标<select id="planning-goal">${Object.entries(E.stewardshipGoals).filter(([key])=>c.kind!=='pass'||key!=='farming').map(([key,label])=>`<option value="${key}"${q.automation.goal===key?' selected':''}>${esc(label)}</option>`).join('')}</select></label><label>驻军目标<input type="number" inputmode="numeric" id="planning-garrison" min="1" max="${E.getTroopCapacity(s,c)}" step="1" value="${q.automation.garrison}" required></label></div><p class="city-planning-note">先按目标补员，再屯田或练兵（训练达到70即停）；维持现状仅补员、补训至50，收支为负时补建。每次至少募100兵，不超目标；在途援军计入。托管不调兵、不出征。</p><p class="planning-safety">${q.pause==='手动经营'?'当前未开启托管':q.pause?esc(q.pause):'后方安全，可在预算内执行'} · 邻接敌境或遭到来袭时自动暂停。</p></fieldset><fieldset><legend>全境共用 · 每季托管预算</legend><div class="planning-fields">${field('commands','最多使用军令',q.budget.commands,10)}${field('reserveCommands','为手动操作保留军令',q.budget.reserveCommands,10)}${field('gold','最多支出金钱',q.budget.gold,1000000)}${field('grain','最多支出粮草',q.budget.grain,1000000)}${field('reserveGold','府库保留金钱',q.budget.reserveGold,1000000)}${field('reserveGrain','府库保留粮草',q.budget.reserveGrain,1000000)}</div><p class="planning-budget-used">本季托管已用 <b>${fmt(q.spent.commands)}令 · ${fmt(q.spent.gold)}金 · ${fmt(q.spent.grain)}粮</b></p><p class="city-planning-note">所有托管城池共用以上额度，修改或开关托管不会清零已用量。实际还会保留至少两个月军饷军粮，并检查未来三次月结，预计缺粮时暂停支出。当前保护线：${fmt(q.floor.gold)}金、${fmt(q.floor.grain)}粮。</p></fieldset><details class="planning-receipts"><summary>托管执行记录${q.lastReport?' · 上季 '+q.lastReport.commands+' 项':''}</summary>${q.receipts.slice(0,8).map(r=>`<p><strong>${esc(E.getCity(s,r.cityId)?.name)} · ${esc(r.label)}</strong><span>第${r.day+1}日 · ${r.commands}令 / ${fmt(r.gold)}金 / ${fmt(r.grain)}粮</span></p>`).join('')||'<p>尚未执行托管命令，换季后军报会汇总支出。</p>'}</details></div>`;
    api.dialog(esc(c.name)+' · 城务规划','发展方向与有限托管',body,'<button class="secondary-button" data-close>返回城池</button><button class="primary-button" id="planning-save">保存规划</button>','medium');
    const panel=node('dialog-content'),selected=()=>panel.querySelector('input[name="city-focus"]:checked').value;
    const update=()=>{
      const sample={...s,cities:s.cities.map(city=>city.id===cityId?{...city,developmentFocus:selected()}:city)},income=E.cityIncomePreview(sample,cityId);
      node('planning-income').textContent='按当前季节估算：'+E.cityFocuses[selected()].name+'方向月产 '+fmt(income.gold)+' 金 / '+fmt(income.grain)+' 粮（未扣军费）。';
      const invalid=[...panel.querySelectorAll('.city-planning-panel input[type="number"]')].some(input=>!input.validity.valid);
      node('planning-save').disabled=!api.canAct()||invalid;
    };
    panel.querySelectorAll('input,select').forEach(input=>input.addEventListener('input',update));update();
    node('planning-save').onclick=()=>{
      if(!api.canAct())return;if(api.getState()!==s){show(cityId);return;}
      const budget=Object.fromEntries(Object.keys(E.stewardshipDefaults).map(key=>[key,Number(node('planning-'+key).value)]));
      const r=E.configureCityPlanning(s,cityId,{focus:selected(),automation:{goal:node('planning-goal').value,garrison:Number(node('planning-garrison').value)},budget});
      if(!r.ok){node('planning-status').textContent=r.message;return;}
      api.save();api.render();show(cityId,r.message);
    };
  }
  root.TKCityPlanning={mount(context){api=context;},entry,bind,show};
})(globalThis);
