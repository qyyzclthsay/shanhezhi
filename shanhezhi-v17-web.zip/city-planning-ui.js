(function(root){
  'use strict';let api;
  const node=id=>document.getElementById(id),esc=v=>api.esc(String(v??'')),fmt=v=>api.fmt(v);
  function entry(city){
    if(!api)return '';const s=api.getState(),q=api.E.cityPlanningStatus(s,city.id),own=city.owner===s.player;
    return `<div class="city-planning-entry"><span><b>${esc(api.E.cityFocuses[q.focus].name)}</b>${q.pending?' · 下季 '+esc(api.E.cityFocuses[q.pending.kind].name):''}</span>${own?`<button type="button" data-city-planning="${esc(city.id)}">城务规划 ›</button>`:''}</div>`;
  }
  function bind(scope){scope.querySelectorAll('[data-city-planning]').forEach(b=>b.onclick=()=>show(b.dataset.cityPlanning));}
  function show(cityId,message=''){
    if(!api)return;root.TKCampaign?.pause?.();const s=api.getState(),E=api.E,c=E.getCity(s,cityId);if(!c||c.owner!==s.player)return;
    const q=E.cityPlanningStatus(s,cityId),focus=q.pending?.kind||q.focus;
    const body=`<div class="city-planning-panel"><p class="planning-status" id="planning-status" role="status">${esc(message||'保存设置不扣费，发展方向下季度生效。')}</p><fieldset class="planning-focus"><legend>本城发展方向</legend><div>${Object.entries(E.cityFocuses).filter(([key])=>c.kind!=='pass'||['balanced','military'].includes(key)).map(([key,v])=>`<label><input type="radio" name="city-focus" value="${key}"${key===focus?' checked':''}><span><strong>${esc(v.name)}</strong><small>${esc(v.description)}</small></span></label>`).join('')}</div></fieldset><p class="planning-income" id="planning-income"></p><p class="city-planning-note">当前为${esc(E.cityFocuses[q.focus].name)}。每城一个方向，可在生效前调整或选回原方向取消；关口仅可均衡或军镇。</p></div>`;
    api.dialog(esc(c.name)+' · 城务规划','本城发展方向',body,'<button class="secondary-button" data-close>返回城池</button><button class="primary-button" id="planning-save">保存规划</button>','medium');
    const panel=node('dialog-content'),selected=()=>panel.querySelector('input[name="city-focus"]:checked').value;
    const update=()=>{
      const sample={...s,cities:s.cities.map(city=>city.id===cityId?{...city,developmentFocus:selected()}:city)},income=E.cityIncomePreview(sample,cityId);
      node('planning-income').textContent='按当前季节估算：'+E.cityFocuses[selected()].name+'方向月产 '+fmt(income.gold)+' 金 / '+fmt(income.grain)+' 粮（未扣军费）。';
      node('planning-save').disabled=!api.canAct();
    };
    panel.querySelectorAll('input,select').forEach(input=>input.addEventListener('input',update));update();
    node('planning-save').onclick=()=>{
      if(!api.canAct())return;if(api.getState()!==s){show(cityId);return;}
      const r=E.setCityFocus(s,cityId,selected());
      if(!r.ok){node('planning-status').textContent=r.message;return;}
      api.save();api.render();show(cityId,r.message);
    };
  }
  root.TKCityPlanning={mount(context){api=context;},entry,bind,show};
})(globalThis);
