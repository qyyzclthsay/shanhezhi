(function(){
  'use strict';
  // Cache only immutable artwork. HTML, scripts and campaign saves remain outside it.
  if('serviceWorker' in navigator&&window.isSecureContext){
    window.addEventListener('load',()=>navigator.serviceWorker.register('./asset-sw.js',{scope:'./',updateViaCache:'none'}).catch(()=>{}));
  }
})();
