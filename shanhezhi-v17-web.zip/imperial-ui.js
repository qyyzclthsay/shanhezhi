(function(root){
  'use strict';
  let api=null,session=null,notice='',draftName='',draftPolicy='farming',submitting=false;
  const node=id=>document.getElementById(id),state=()=>api.getState(),esc=value=>api.esc(String(value??''));
  const fmt=value=>api.fmt?api.fmt(value):Number(value||0).toLocaleString('zh-CN');
  const faction=id=>api.E.getFaction(state(),id);
  const canAct=()=>api.canAct?.()!==false;
  function nameIssue(value,s){
    if(!value)return '请定下国号。';
    if(!/^\p{Script=Han}{1,2}$/u.test(value))return '国号须为一至两个汉字。';
    if(s.factions.some(f=>f.id!==s.player&&f.imperial?.name===value))return '此国号已有势力使用。';
    return '';
  }
  function coalitionList(offer,s){
    const coalitions=(offer.coalitions||[]).filter(c=>c.endDay>s.totalDays);
    if(!coalitions.length)return '';
    return `<details class="imperial-coalitions"><summary>讨逆联盟 · ${coalitions.length} 支</summary><ul>${coalitions.map(c=>{
      const target=faction(c.target),title=target?.imperial?.name?`「${target.imperial.name}」`:(target?.name||c.target);
      const members=(c.members||[]).map(id=>faction(id)?.name||id).join('、');
      return `<li><strong>讨伐${esc(title)}</strong><span>${esc(members||'暂无成员')} · 余 ${Math.max(0,c.endDay-s.totalDays)} 日</span></li>`;
    }).join('')}</ul></details>`;
  }
  function otherEmperors(s){
    const others=s.factions.filter(f=>f.id!==s.player&&f.imperial&&!api.E.isFactionEliminated?.(s,f.id));
    return others.length?`<div class="imperial-others"><span>已称帝势力</span>${others.map(f=>`<span style="--realm-color:${esc(f.color)}"><b>${esc(f.imperial.name)}</b> · 君主 ${esc(f.name)}</span>`).join('')}</div>`:'';
  }
  function show(){
    if(!api||!api.E.imperialOffer||node('battle-dialog')?.open)return false;
    root.TKCampaign?.pause?.();
    const s=state(),E=api.E,offer=E.imperialOffer(s),imperial=offer.imperial,policies=E.imperialPolicies||{},keys=Object.keys(policies),me=faction(s.player);
    if(session!==s){session=s;notice='';draftName='';draftPolicy=imperial?.policy||keys[0]||'farming';}
    if(!keys.includes(draftPolicy))draftPolicy=imperial?.policy||keys[0];
    if(imperial&&!offer.canChangePolicy)draftPolicy=imperial.policy;
    const cities=Array.isArray(offer.cities)?offer.cities.length:offer.cities,required=offer.requiredCities||6,cost=offer.cost||{},rank=Number(offer.powerRank)||0;
    const conditions=imperial?`<div class="imperial-reign" style="--realm-color:${esc(me?.color)}"><strong>${esc(imperial.name)}</strong><span>君主 ${esc(me?.name)}<small>国号已定，沿用不改</small></span></div>`:`<div class="imperial-conditions"><div class="${cities>=required?'is-met':''}"><strong>${fmt(cities)} / ${required}</strong><span>城池 · 关口不计</span></div><div class="${rank>0&&rank<=3?'is-met':''}"><strong>${rank?'第 '+rank+' 名':'待定'}</strong><span>综合实力须居前三</span></div></div><p class="imperial-cost">称帝消耗 <b>${fmt(cost.actions)} 令 · ${fmt(cost.gold)} 金 · ${fmt(cost.grain)} 粮</b></p><p class="imperial-risk">称帝会恶化关系，非盟邻国可能联合讨伐，讨逆同盟持续一年；现有盟约保留。</p><label class="imperial-name-label" for="imperial-name">国号 <input id="imperial-name" type="text" maxlength="2" autocomplete="off" placeholder="一至两个汉字" value="${esc(draftName)}" aria-describedby="imperial-name-hint"></label><p id="imperial-name-hint" class="imperial-hint">确定后不可更改，且不得与已有国号重复。</p>`;
    const policyHint=imperial?(offer.policyMessage||(offer.canChangePolicy?'本季可调整一次；不调整则沿用当前国策。':'本季国策已定，下季可再调整。')):'称帝时定下首项国策，此后每季可调整一次；不调整则沿用。';
    const body=`<section class="imperial-panel">${conditions}<fieldset class="imperial-policies"${imperial&&!offer.canChangePolicy?' disabled':''}><legend>${imperial?'治国之策':'选择国策'}</legend>${keys.map(key=>`<label class="imperial-policy${key===imperial?.policy?' is-current':''}"><input type="radio" name="imperial-policy" value="${esc(key)}"${key===draftPolicy?' checked':''}><span><strong>${esc(policies[key].name)}${key===imperial?.policy?'<em>现行</em>':''}</strong><small>${esc(policies[key].description)}</small></span></label>`).join('')}</fieldset><p class="imperial-policy-hint">${esc(policyHint)}</p><p id="imperial-status" class="imperial-status" role="status">${esc(notice||(!imperial&&!offer.ok?offer.message:''))}</p>${otherEmperors(s)}${coalitionList(offer,s)}</section>`;
    api.dialog(imperial?`${esc(imperial.name)} · 国策`:'称帝与国策',imperial?'朝廷定策':'自立国号 · 审势而行',body,'<button type="button" class="secondary-button" id="imperial-back">返回外交</button><button type="button" class="primary-button" id="imperial-submit"></button>','medium');
    node('imperial-back').onclick=()=>root.TKDiplomacy?.show?root.TKDiplomacy.show():api.closeDialog?.();
    const submit=node('imperial-submit'),name=node('imperial-name');
    const update=()=>{
      const issue=imperial?'':nameIssue(draftName,s);
      submit.disabled=submitting||!canAct()||(imperial?(!offer.canChangePolicy||draftPolicy===imperial.policy):(!offer.ok||!!issue))||!keys.includes(draftPolicy);
      submit.textContent=imperial?(!offer.canChangePolicy?'本季国策已定':draftPolicy===imperial.policy?'当前国策已在施行':`改行${policies[draftPolicy]?.name||'所选国策'}`):(draftName&&!issue?`以「${draftName}」称帝`:'定国号后称帝');
      if(name){name.setAttribute('aria-invalid',String(!!draftName&&!!issue));node('imperial-name-hint').textContent=draftName&&issue?issue:'确定后不可更改，且不得与已有国号重复。';}
    };
    if(name)name.oninput=()=>{draftName=name.value.trim();update();};
    node('dialog-content').querySelectorAll('input[name="imperial-policy"]').forEach(input=>input.onchange=()=>{draftPolicy=input.value;update();});
    submit.onclick=()=>{
      if(submitting||!canAct())return;
      if(state()!==s){show();return;}
      const current=E.imperialOffer(s);
      if(!!current.imperial!==!!imperial||(current.imperial&&current.imperial.name!==imperial.name)){show();return;}
      const issue=current.imperial?'':nameIssue(draftName,s);
      if(issue||(!current.imperial&&!current.ok)||(current.imperial&&!current.canChangePolicy)){notice=issue||(current.imperial?current.policyMessage:current.message);show();return;}
      if(current.imperial?.policy===draftPolicy)return;
      submitting=true;update();
      try{
        const result=current.imperial?E.setImperialPolicy(s,draftPolicy):E.proclaimEmpire(s,draftName,draftPolicy);
        notice=result?.message||'当前无法执行。';
        if(result?.ok){api.save();api.render();}
      }finally{submitting=false;}
      show();
    };
    update();return true;
  }
  function mount(context){api=context;session=null;notice='';}
  root.TKImperial={mount,show};
})(globalThis);
