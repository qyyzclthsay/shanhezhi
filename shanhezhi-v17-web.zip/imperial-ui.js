(function(root){
  'use strict';
  let api=null,session=null,notice='',draftName='',draftPolicy='farming',tributeTarget='',submitting=false;
  const node=id=>document.getElementById(id),state=()=>api.getState(),esc=value=>api.esc(String(value??''));
  const fmt=value=>api.fmt?api.fmt(value):Number(value||0).toLocaleString('zh-CN');
  const faction=id=>api.E.getFaction(state(),id);
  const canAct=()=>api.canAct?.()!==false;
  function nameIssue(value,s){
    if(!value)return '请定下国号。';
    if(!/^\p{Script=Han}{1,2}$/u.test(value))return '国号须为一至两个汉字。';
    if(s.factions.some(f=>f.id!==s.player&&f.imperial?.name===value))return '此国号已有势力使用。';
    return '';
  }
  function coalitionList(offer,s){
    const coalitions=(offer.coalitions||[]).filter(c=>c.endDay>s.totalDays);
    if(!coalitions.length)return '';
    return `<details class="imperial-coalitions"><summary>讨逆联盟 · ${coalitions.length} 支</summary><ul>${coalitions.map(c=>{
      const target=faction(c.target),title=target?.imperial?.name?`「${target.imperial.name}」`:(target?.name||c.target);
      const members=(c.members||[]).map(id=>faction(id)?.name||id).join('、');
      return `<li><strong>讨伐${esc(title)}</strong><span>${esc(members||'暂无成员')} · 余 ${Math.max(0,c.endDay-s.totalDays)} 日</span></li>`;
    }).join('')}</ul></details>`;
  }
  function otherEmperors(s){
    const others=s.factions.filter(f=>f.id!==s.player&&f.imperial&&!api.E.isFactionEliminated?.(s,f.id));
    return others.length?`<div class="imperial-others"><span>已称帝势力</span>${others.map(f=>`<span style="--realm-color:${esc(f.color)}"><b>${esc(f.imperial.name)}</b> · 君主 ${esc(f.name)}</span>`).join('')}</div>`:'';
  }
  function tributePanel(status){
    if(!status)return '';
    const targets=status.targets||[],locked=status.usedThisYear||!status.available;
    if(!targets.some(target=>target.targetId===tributeTarget))tributeTarget='';
    return `<section class="imperial-tribute" aria-labelledby="imperial-tribute-title"><div class="imperial-section-heading"><h3 id="imperial-tribute-title">征收岁贡</h3><span class="imperial-year${status.usedThisYear?' is-used':''}">${fmt(status.year)} 年 · ${status.usedThisYear?'本年已征':'本年可征一次'}</span></div><p class="imperial-tribute-rule">每年仅选一个未称帝势力 · 不耗军令</p><label class="imperial-target-label" for="imperial-tribute-target">征贡对象<select id="imperial-tribute-target"${locked?' disabled':''}><option value="">${targets.length?'选择一个势力':'暂无可征贡势力'}</option>${targets.map(target=>`<option value="${esc(target.targetId)}"${target.targetId===tributeTarget?' selected':''}${!target.ok?' disabled':''}>${esc(target.targetName||faction(target.targetId)?.name||target.targetId)} · ${fmt(target.gold)} 金 / ${fmt(target.grain)} 粮</option>`).join('')}</select></label><div id="imperial-tribute-preview" class="imperial-tribute-preview" aria-live="polite"></div><div class="imperial-tribute-action"><button type="button" class="primary-button" id="imperial-tribute-submit" aria-describedby="imperial-tribute-hint"></button><span id="imperial-tribute-hint">关系 −12 · 不耗军令</span></div><p class="imperial-tribute-rule imperial-tribute-limits">取目标现有金粮各 12%，至多 1,000 金 / 1,500 粮。</p></section>`;
  }
  function show(){
    if(!api||!api.E.imperialOffer||node('battle-dialog')?.open||root.TKCG?.active||root.TKOpening?.active)return false;
    root.TKCampaign?.pause?.();
    const s=state(),E=api.E,offer=E.imperialOffer(s),imperial=offer.imperial,policies=E.imperialPolicies||{},keys=Object.keys(policies),me=faction(s.player);
    if(session!==s){session=s;notice='';draftName='';tributeTarget='';draftPolicy=imperial?.policy||keys[0]||'farming';}
    if(!keys.includes(draftPolicy))draftPolicy=imperial?.policy||keys[0];
    if(imperial&&!offer.canChangePolicy)draftPolicy=imperial.policy;
    const cities=Array.isArray(offer.cities)?offer.cities.length:offer.cities,required=offer.requiredCities??6,requiredRank=offer.requiredRank??4,cost=offer.cost||{},rank=Number(offer.powerRank)||0;
    const tribute=imperial?E.imperialTributeStatus?.(s):null;
    const conditions=imperial?`<div class="imperial-reign" style="--realm-color:${esc(me?.color)}"><strong>${esc(imperial.name)}</strong><span>君主 ${esc(me?.name)}<small>国号已定，沿用不改</small></span></div>`:`<div class="imperial-conditions"><div class="${cities>=required?'is-met':''}"><strong>${fmt(cities)} / ${fmt(required)}</strong><span>大小城池 · 关口不计</span></div><div class="${rank>0&&rank<=requiredRank?'is-met':''}"><strong>${rank?'第 '+fmt(rank)+' 名':'待定'}</strong><span>综合实力须居前 ${fmt(requiredRank)}</span></div></div><p class="imperial-cost">称帝消耗 <b>${fmt(cost.actions)} 令 · ${fmt(cost.gold)} 金 · ${fmt(cost.grain)} 粮</b></p><label class="imperial-name-label" for="imperial-name">国号 <input id="imperial-name" type="text" maxlength="2" autocomplete="off" placeholder="一至两个汉字" value="${esc(draftName)}" aria-describedby="imperial-name-hint"></label><p id="imperial-name-hint" class="imperial-hint">确定后不可更改，且不得与已有国号重复。</p>`;
    const policyHint=imperial?(offer.policyMessage||(offer.canChangePolicy?'本季可调整一次；不调整则沿用当前国策。':'本季国策已定，下季可再调整。')):'称帝时定下首项国策，此后每季可调整一次；不调整则沿用。';
    const body=`<section class="imperial-panel">${conditions}<p id="imperial-status" class="imperial-status" role="status">${esc(notice||(!imperial&&!offer.ok?offer.message:''))}</p>${tributePanel(tribute)}<fieldset class="imperial-policies"${imperial&&!offer.canChangePolicy?' disabled':''}><legend><span class="imperial-effect-tag is-benefit">增益</span> 国策 · 三选一</legend>${keys.map(key=>`<label class="imperial-policy${key===imperial?.policy?' is-current':''}"><input type="radio" name="imperial-policy" value="${esc(key)}"${key===draftPolicy?' checked':''}><span><strong>${esc(policies[key].name)}${key===imperial?.policy?'<em>现行</em>':''}</strong><small>${esc(policies[key].description)}</small></span></label>`).join('')}</fieldset><p class="imperial-policy-hint">${esc(policyHint)}</p>${!imperial?'<p class="imperial-benefit-note">称帝后，每年还可向一个未称帝势力征收岁贡。</p>':''}<div class="imperial-risk"><span class="imperial-effect-tag is-risk">代价</span><span>各国关系下降，更易遭到攻击。非盟邻国可能结成一年讨逆联盟；现有盟约保留。</span></div>${otherEmperors(s)}${coalitionList(offer,s)}</section>`;
    api.dialog(imperial?`${esc(imperial.name)} · 朝廷`:'称帝立国',imperial?'国策与岁贡':'自立国号 · 审势而行',body,'<button type="button" class="secondary-button" id="imperial-back">返回地图</button><button type="button" class="primary-button" id="imperial-submit"></button>','medium');
    node('imperial-back').onclick=()=>api.closeDialog?.();
    const submit=node('imperial-submit'),name=node('imperial-name');
    const update=()=>{
      const issue=imperial?'':nameIssue(draftName,s);
      submit.disabled=submitting||!canAct()||(imperial?(!offer.canChangePolicy||draftPolicy===imperial.policy):(!offer.ok||!!issue))||!keys.includes(draftPolicy);
      submit.textContent=imperial?(!offer.canChangePolicy?'本季国策已定':draftPolicy===imperial.policy?'当前国策已在施行':`改行${policies[draftPolicy]?.name||'所选国策'}`):(draftName&&!issue?`以「${draftName}」称帝`:'定国号后称帝');
      if(name){name.setAttribute('aria-invalid',String(!!draftName&&!!issue));node('imperial-name-hint').textContent=draftName&&issue?issue:'确定后不可更改，且不得与已有国号重复。';}
    };
    if(name)name.oninput=()=>{draftName=name.value.trim();update();};
    node('dialog-content').querySelectorAll('input[name="imperial-policy"]').forEach(input=>input.onchange=()=>{draftPolicy=input.value;update();});
    if(tribute){
      const targetSelect=node('imperial-tribute-target'),tributeButton=node('imperial-tribute-submit'),preview=node('imperial-tribute-preview');
      const updateTribute=()=>{
        const current=E.imperialTributeStatus(s),selected=tributeTarget?E.imperialTributeOffer(s,tributeTarget):null;
        targetSelect.disabled=submitting||current.usedThisYear||!current.available;
        tributeButton.disabled=submitting||!canAct()||!current.available||!selected?.ok;
        tributeButton.textContent=current.usedThisYear?'本年已征 · 明年可用':!current.available?'暂不可征贡':'征收岁贡';
        tributeButton.title=current.usedThisYear?`${fmt(current.nextYear)} 年可再次征贡`:!current.available?current.message:!selected?'先选择一个势力':!selected.ok?selected.message:'本年仅此一次，收取后双方关系下降 12';
        preview.innerHTML=current.usedThisYear?`<span>本年额度已用，下次可用：${fmt(current.nextYear)} 年。</span>`:selected?.ok?`<span>向 <b>${esc(selected.targetName||faction(tributeTarget)?.name||tributeTarget)}</b> 征收</span><strong>${fmt(selected.gold)} 金 <i>／</i> ${fmt(selected.grain)} 粮</strong>`:`<span>${esc(!current.available?current.message:selected?.message||'选定后可查看本次征收数额。')}</span>`;
      };
      targetSelect.onchange=()=>{tributeTarget=targetSelect.value;updateTribute();};
      tributeButton.onclick=()=>{
        if(submitting||!canAct())return;
        if(state()!==s){show();return;}
        const current=E.imperialTributeOffer(s,tributeTarget);
        if(!current.ok){notice=current.message;show();return;}
        submitting=true;update();updateTribute();
        try{
          const result=E.collectImperialTribute(s,tributeTarget);
          notice=result?.message||'当前无法征贡。';
          if(result?.ok){api.save();api.render();}
        }finally{submitting=false;}
        show();
      };
      updateTribute();
    }
    submit.onclick=()=>{
      if(submitting||!canAct())return;
      if(state()!==s){show();return;}
      const current=E.imperialOffer(s);
      if(!!current.imperial!==!!imperial||(current.imperial&&current.imperial.name!==imperial.name)){show();return;}
      const issue=current.imperial?'':nameIssue(draftName,s);
      if(issue||(!current.imperial&&!current.ok)||(current.imperial&&!current.canChangePolicy)){notice=issue||(current.imperial?current.policyMessage:current.message);show();return;}
      if(current.imperial?.policy===draftPolicy)return;
      submitting=true;update();let proclaimed=false;
      try{
        const result=current.imperial?E.setImperialPolicy(s,draftPolicy):E.proclaimEmpire(s,draftName,draftPolicy);
        notice=result?.message||'当前无法执行。';
        if(result?.ok){proclaimed=!current.imperial;api.save();api.render();}
      }finally{submitting=false;}
      if(proclaimed){
        api.closeDialog();
        const realm=faction(s.player).imperial.name,onContinue=()=>{if(state()===s)show();};
        if(!root.TKCG?.showEvent('empire',{eventKey:`${api.getCGCampaignId()}:empire`,title:'定鼎立国',text:`告祭天地，昭告四方。你定国号为「${realm}」，自此立旗建制，与群臣共开新章。愿此国号，终与安定山河同载青史。`,gold:true,onContinue}))onContinue();
        return;
      }
      show();
    };
    update();return true;
  }
  function mount(context){api=context;session=null;notice='';tributeTarget='';}
  root.TKImperial={mount,show};
})(globalThis);
