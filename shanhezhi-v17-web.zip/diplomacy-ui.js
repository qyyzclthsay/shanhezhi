(function(root){
  'use strict';
  let api,result='',proposalSession=null,shownProposals=new Set();
  const $=s=>document.querySelector(s),state=()=>api.getState(),esc=s=>api.esc(s);
  const faction=id=>api.E.getFaction(state(),id),date=day=>{const d=root.TKCalendar.fromTotalDays(day);return `${d.year}年${d.month}月${d.day}日`;};
  const attitudes={至交:'互信深厚 · 谈盟优势明显',友善:'保持善意 · AI 不主动进攻',中立:'谨慎扩张 · 按实力判断',敌视:'警惕来袭 · 更积极寻找战机',死敌:'高度敌对 · 优先报复进攻'};
  const pendingProposal=()=>api?.E.getDiplomaticProposal?.(state());
  function proposalBanner(){
    const p=pendingProposal();return p?`<div class="diplomatic-arrival"><span><b>${esc(p.fromName||faction(p.fromId)?.name)}来使</b> · ${p.kind==='alliance'?'提议结盟':'备礼修好'}</span><button class="secondary-button" data-diplomatic-proposal>查看来意</button></div>`:'';
  }
  function showProposal(){
    const p=pendingProposal();if(!p||!api.canAct()||root.TKCG?.active||root.TKOpening?.active||$('#battle-dialog')?.open)return false;
    const expected=state(),sender=faction(p.fromId),leader=expected.generals.find(g=>g.id===sender?.leaderId);
    root.TKCampaign?.pause?.();shownProposals.add(p.id);
    const terms=p.kind==='alliance'?'同意后缔结两年盟约，互不侵犯、允许借道。不耗军令，无需支付金粮。':`同意后收下 ${api.fmt(p.gold)} 金、${api.fmt(p.grain)} 粮，改善双方关系；不耗军令，也不会自动结盟。`;
    const body=`<section class="diplomatic-letter"><div class="diplomatic-letter-head">${root.TKPeople?.portrait(leader)||''}<div><h3>${esc(sender?.name||p.fromName)}来使</h3><small>${sender?.imperial?'帝王 · '+esc(sender.imperial.name):'诸侯修书'} · 余 ${p.remainingDays} 日</small></div></div><blockquote>${esc(p.message)}</blockquote><p class="diplomatic-terms">${terms}</p></section>`;
    api.dialog(p.kind==='alliance'?'盟约来书':'诸侯赠礼','由你决定，同意后才生效',body,'<button class="secondary-button" id="diplomatic-later">稍后答复</button><button class="secondary-button" id="diplomatic-refuse">拒绝</button><button class="primary-button" id="diplomatic-accept">'+(p.kind==='alliance'?'同意结盟':'接受赠礼')+'</button>','medium');
    $('#diplomatic-later').onclick=()=>api.closeDialog();
    const respond=accepted=>{
      if(state()!==expected||!api.canAct())return;
      const r=api.E.respondDiplomaticProposal(expected,p.id,accepted);result=r.message;
      if(r.ok){api.save();api.render();}
      const agreed=r.ok&&r.accepted;
      api.dialog('来使复命','外交答复',`<section class="diplomatic-reply${agreed?'':' is-refused'}" role="status"><h3>${agreed?'✓ '+(p.kind==='alliance'?'盟约已成':'赠礼已收'):r.ok?'× 已拒绝':'来书已变更'}</h3><p>${esc(r.message)}</p></section>`,'<button class="primary-button" data-close>返回天下</button>','medium');
    };
    $('#diplomatic-refuse').onclick=()=>respond(false);$('#diplomatic-accept').onclick=()=>respond(true);return true;
  }
  function maybeShowProposal(){
    if(!api)return false;
    if(proposalSession!==state()){proposalSession=state();shownProposals=new Set();}
    const p=pendingProposal();
    if(!p||shownProposals.has(p.id)||!api.hasCampaign()||!api.isGameVisible()||document.querySelector('dialog[open]'))return false;
    return showProposal();
  }
  function personalityDetail(leader,profile){
    if(!profile?.description)return '';
    const tags=(profile.tags||[]).filter(tag=>tag!==profile.label).slice(0,3);
    return `<details class="diplomacy-personality"><summary>${esc(leader?.name||'现任君主')} · 性格与偏好</summary>${tags.length?`<div class="personality-tags">${tags.map(tag=>`<span>${esc(tag)}</span>`).join('')}</div>`:''}<p>${esc(profile.description)}</p></details>`;
  }
  function relationMeter(rel){const labels=['死敌','敌视','中立','友善','至交'];return '<div class="relation-scale" aria-label="关系 '+rel.label+' '+rel.score+'">'+labels.map(label=>'<span class="'+(label===rel.label?'active':'')+'" data-level="'+label+'">'+label+'</span>').join('')+'</div><p class="relation-behavior">'+attitudes[rel.label]+'</p>';}
  function render(){
    if(!api)return;
    const button=$('#diplomacy-btn'),proposal=pendingProposal();if(button){button.innerHTML=proposal?'外交 <span class="diplomatic-arrival-badge">来使</span>':'外交';button.title=proposal?'有新的外交来书，等待你的答复':'结盟与势力关系';}
  }
  function show(focusId,envoyId,giftId='none'){
    if(!api)return;root.TKCampaign?.pause?.();
    const s=state(),E=api.E,envoys=E.allianceEnvoys(s),envoy=envoys.find(g=>g.id===envoyId)||envoys[0],all=E.allies(s),treasury=faction(s.player);
    const ranks=s.factions.filter(f=>!E.isFactionEliminated(s,f.id)).map(f=>({id:f.id,...E.factionStrength(s,f.id)})).sort((a,b)=>b.score-a.score);
    const targets=s.factions.filter(f=>f.id!==s.player&&!E.isFactionEliminated(s,f.id)).sort((a,b)=>Number(b.id===focusId)-Number(a.id===focusId)||Number(E.areAllied(s,s.player,b.id))-Number(E.areAllied(s,s.player,a.id)));
    api.dialog('结盟与势力关系','常规盟友 '+all.filter(t=>t.origin!=='coalition').length+'/'+E.DIPLOMACY.maxAllies+' · 本季剩余 '+E.commandStatus(s).remaining+' 令',
      `<p class="diplomacy-rules"><b>1令谈两年盟约</b>。成功后五年才能再谈；失败关系−8，<b>下季可重试</b>。金粮只在谈成时交付，报价随对方实力变化。</p><div class="diplomacy-choices"><label class="field-label" for="alliance-envoy">出使文武<select id="alliance-envoy" aria-label="出使文武"${envoys.length?'':' disabled'}>${envoys.map(g=>`<option value="${g.id}"${g.id===envoy?.id?' selected':''}>${esc(g.name)} · 魅力 ${g.charisma}</option>`).join('')||'<option>暂无可出使文武</option>'}</select></label><label class="field-label" for="alliance-gift">结盟礼物档位<select id="alliance-gift" aria-label="结盟礼物档位">${E.ALLIANCE_GIFTS.map(g=>`<option value="${g.id}"${g.id===giftId?' selected':''}>${g.name}${g.bonus?' · 概率加'+g.bonus+'个百分点':''} · 各势力报价见下方</option>`).join('')}</select></label></div><p class="alliance-budget">现有府库 ${treasury.gold.toLocaleString('zh-CN')} 金 · ${treasury.grain.toLocaleString('zh-CN')} 粮</p>${result?`<p class="alliance-result" role="status">${esc(result)}</p>`:''}<div class="diplomacy-grid">${targets.map(f=>{
        const t=E.allianceBetween(s,s.player,f.id),q=E.allianceOffer(s,f.id,envoy?.id,giftId),peace=E.goodwillOffer(s,f.id,envoy?.id),submission=E.submissionOffer(s,f.id,envoy?.id),leader=s.generals.find(g=>g.id===f.leaderId),power=ranks.find(r=>r.id===f.id),rel=q.relation,rulerStyle={...root.TKPersonalities?.profileFor?.(f,leader),...E.aiPersonality(s,f.id)};
        return `<article class="diplomacy-card ${t?'is-ally':''}" style="--ally-color:${f.color}"><div class="diplomacy-heading">${root.TKPeople?.portrait(leader)||''}<div><h3>${f.imperial?`<span class="imperial-country-label">${esc(f.imperial.name)}</span> `:""}${esc(f.name)}</h3><small>${E.ownedCities(s,f.id).length} 座城关 · ${power.label} · ${esc(rulerStyle.label)} · 实力第${ranks.findIndex(r=>r.id===f.id)+1}</small></div><strong class="relation-tag" data-relation="${rel.label}">${rel.label} ${rel.score>0?'+':''}${rel.score}</strong></div>${personalityDetail(leader,rulerStyle)}${relationMeter(rel)}<p class="alliance-note">${esc(rel.reason)}${t?' · 盟约至'+date(t.endDay):''}</p><details class="diplomacy-power"><summary>综合实力 ${power.score} · 查看依据</summary><p>军力 ${power.military} · 城关 ${power.territory}<br>文武 ${power.talent} · 经济 ${power.economy}<br>军力计入兵数、训练与士气；随战局实时更新。</p></details><div class="diplomacy-action"><span>${q.ok?`成功率 <b>${q.chance}%</b><br>${q.gift.gold} 金 + ${q.gift.grain} 粮`:esc(q.message)}</span><button class="secondary-button" data-offer-alliance="${f.id}"${q.ok&&api.canAct()?'':' disabled'}>结盟 · 1令</button></div><div class="diplomacy-action diplomacy-secondary"><span>${peace.ok?`关系 +${peace.gain} · ${peace.cost.gold}金 / ${peace.cost.grain}粮`:esc(peace.message)}</span><button class="secondary-button" data-goodwill="${f.id}"${peace.ok&&api.canAct()?'':' disabled'}>${peace.label} · 1令</button></div>${power.cities===1?`<div class="diplomacy-action diplomacy-secondary"><span>${submission.ok?`<b>必定归顺</b> · 接纳整支势力`:esc(submission.message)}</span><button class="secondary-button" data-submission="${f.id}"${submission.ok&&api.canAct()?'':' disabled'}>接纳归顺 · 1令</button></div>`:''}</article>`;
      }).join('')}</div><details class="alliance-footnote"><summary>关系、报价与归顺规则</summary><p>关系：至交≥60、友善20～59、中立−19～19、敌视−59～−20、死敌≤−60。谈盟成功+12，失败−8，守约每季+3，出兵攻击−20；释放对方文武+10、处决−35，平静一季负面关系缓和2点。赠礼每季一次，消耗1令及显示的金粮，关系+12；对显著强于自己的势力显示“纳贡修好”，关系+18，不产生从属关系。敌视与死敌会提高AI进攻意愿，友善及至交AI不主动进攻。</p><p>盟约概率由魅力、礼物、关系与实力差决定，交战中再减20个百分点，最高90%。强方报价更高；金粮、城关、军队、文武都会影响实力，囤积资源的权重有上限。</p><p>我方称帝后，与我方关系友善或至交、且仅剩1座城池的势力可归顺（关口不计城数）。委派空闲使者、消耗1令即可接纳，必定成功；每季最多接纳一方。城、兵、将与府库直接并入，原外交不继承，第三方俘虏仍待解救。</p><p>盟约期间互不侵犯、允许借道；双方最多${E.DIPLOMACY.maxAllies}位常规盟友；讨逆同盟临时另计。不自动参战，也不能提前毁约。开局短期盟约保持原定期限，不算一次出使。</p></details>`,
      `<button class="secondary-button" data-close>返回地图</button><button class="primary-button" id="imperial-open">${treasury.imperial?'国策 · '+esc(treasury.imperial.name):'称帝'+(E.imperialOffer(s).ok?' · 时机已至':'')}</button>`,'wide');
    $('#imperial-open').onclick=()=>root.TKImperial.show();
    if(pendingProposal()){$('#dialog-content .dialog-body').insertAdjacentHTML('afterbegin',proposalBanner());$('[data-diplomatic-proposal]').onclick=showProposal;}
    $('#alliance-envoy').onchange=()=>show(focusId,$('#alliance-envoy').value,$('#alliance-gift').value);
    $('#alliance-gift').onchange=()=>show(focusId,$('#alliance-envoy').value,$('#alliance-gift').value);
    const execute=(kind,target)=>{if(!api.canAct())return;const selected=$('#alliance-envoy')?.value||envoy?.id,gift=$('#alliance-gift')?.value||giftId,r=kind==='alliance'?E.proposeAlliance(state(),target,selected,gift):kind==='goodwill'?E.sendGoodwill(state(),target,selected):E.proposeSubmission(state(),target,selected);result=r.message;if(r.ok){api.save();api.render();}show(target,selected,gift);};
    document.querySelectorAll('[data-offer-alliance]').forEach(b=>b.onclick=()=>execute('alliance',b.dataset.offerAlliance));
    document.querySelectorAll('[data-goodwill]').forEach(b=>b.onclick=()=>execute('goodwill',b.dataset.goodwill));
    document.querySelectorAll('[data-submission]').forEach(b=>b.onclick=()=>{
      if(!api.canAct())return;
      const target=b.dataset.submission,selected=$('#alliance-envoy').value,q=E.submissionOffer(state(),target,selected);
      if(!q.ok){result=q.message;show(target,selected,giftId);return;}
      api.dialog('接纳'+esc(faction(target).name)+'归顺','必定归顺 · 消耗1令','<p>对方已符合归顺条件。确认后，其城池、军队、文武与府库将并入我方，原有盟约不继承；本季不能再接纳其他势力。</p>','<button class="secondary-button" id="submission-back">返回外交</button><button class="primary-button" id="submission-confirm">确认接纳归顺</button>','medium');
      $('#submission-back').onclick=()=>show(target,selected,giftId);
      $('#submission-confirm').onclick=()=>{if(!api.canAct())return;const r=E.proposeSubmission(state(),target,selected);result=r.message;if(r.ok){api.save();api.render();}show(target,selected,giftId);};
    });
  }
  function mount(context){api=context;const button=$('#diplomacy-btn');if(button)button.onclick=()=>{result='';if(!pendingProposal()||!showProposal())show();};render();}
  root.TKDiplomacy={mount,render,show,showProposal,maybeShowProposal};
})(globalThis);
