(function(root,factory){'use strict';const moduleApi=factory();if(typeof module==='object'&&module.exports)module.exports=moduleApi;root.TKWarDiplomacy=moduleApi;})(globalThis,function(){
  'use strict';
  const DAYS=183,integer=(n,min,max)=>Number.isInteger(n)&&n>=min&&n<=max,record=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
  function create(E){
    const pair=(a,b)=>[a,b].sort().join('|');
    const existing=(s,a,b)=>(s.diplomacy?.truces||[]).find(t=>pair(t.a,t.b)===pair(a,b)&&t.endDay>s.totalDays&&!E.isFactionEliminated(s,a)&&!E.isFactionEliminated(s,b))||null;
    const war=(s,a,b)=>(s.diplomacy?.wars||[]).find(w=>pair(w.a,w.b)===pair(a,b)&&w.settledDay===null&&s.totalDays-w.lastBattleDay<=365)||null;
    function recordBattle(s,b,r){
      const a=b.attackerFaction,d=b.defenderFaction;
      if(!E.getFaction(s,a)||!E.getFaction(s,d)||a===d||r.unopposed||!s.diplomacy)return;
      s.diplomacy.wars??=[];let w=war(s,a,d);
      if(!w){
        s.diplomacy.wars=s.diplomacy.wars.filter(x=>pair(x.a,x.b)!==pair(a,d));
        w={a,b:d,startedDay:s.totalDays,lastBattleDay:s.totalDays,battles:0,losses:{[a]:0,[d]:0},captures:{[a]:0,[d]:0},objectives:{[a]:E.getFaction(s,a).aiObjective?.targetId||b.toId,[d]:b.toId},settledDay:null};
        s.diplomacy.wars.push(w);
      }
      w.lastBattleDay=s.totalDays;w.battles++;
      w.losses[a]+=Math.max(0,Math.floor(r.attackerLosses||0));w.losses[d]+=Math.max(0,Math.floor(r.defenderLosses||0));
      if(r.captured&&r.winner==='attacker')w.captures[a]++;
    }
    function disposition(s,id,other){
      const w=war(s,id,other),f=E.getFaction(s,id),target=E.getFaction(s,other);
      if(!w||!f||!target||existing(s,id,other)||E.areAllied(s,id,other)||E.isFactionEliminated(s,id)||E.isFactionEliminated(s,other))return {willing:false,reason:'双方近期尚无需要议和的战事。',war:w};
      const elapsed=s.totalDays-w.startedDay,ownLoss=w.losses[id],otherLoss=w.losses[other],objective=E.getCity(s,w.objectives[id]);
      const incoming=s.armies.filter(a=>a.kind==='attack'&&E.getCity(s,E.destination(a))?.owner===id&&a.faction!==id&&!E.areAllied(s,id,a.faction));
      const otherFront=incoming.find(a=>a.faction!==other),inc=E.incomePreview(s,id),power=E.factionStrength(s,id).score,opponent=E.factionStrength(s,other).score;
      const profile=E.aiPersonality(s,id),pressAdvantage=power>opponent*1.45&&(profile.aggression>=1.075||E.ownedCities(s,other).length<=1);
      const supplied=f.gold>=Math.max(300,inc.upkeepGold*2)&&f.grain>=Math.max(600,inc.upkeep*2),needsRest=ownLoss>=Math.max(600,(inc.garrisonTroops+inc.marchingTroops)*.15);
      if(pressAdvantage&&supplied&&!otherFront&&!needsRest)return {willing:false,purpose:'乘势进取',reason:'对方优势明显、军需尚足，准备继续推进此役。',war:w,objectiveId:objective?.id||null};
      let purpose='',reason='',threatId=null;
      if(w.captures[id]>0&&objective?.owner===id){purpose='战果已定';reason='已夺得'+objective.name+'，愿暂息兵戈，整顿新得之地。';}
      else if(otherFront&&elapsed>=15){purpose='转顾他线';threatId=otherFront.faction;reason=E.getFaction(s,threatId).name+'正从另一战线来袭，愿先与你议和，避免两面受敌。';}
      else if(ownLoss>=400&&(f.grain<inc.upkeep*2||f.gold<inc.upkeepGold*2)){purpose='休兵整军';reason='连续交锋已经消耗军需，希望停战整补。';}
      else if(elapsed>=30&&(w.captures[other]>w.captures[id]||ownLoss>=600&&ownLoss>otherLoss*1.35)&&opponent>=power*.85){purpose='止损议和';reason='战局不利，已损折兵力或失去城池，愿议定期限休兵。';}
      else if(elapsed>=60&&w.battles>=3&&ownLoss>=300&&otherLoss>=300){purpose='结束相持';reason='两军久战相持，双方都有损失，愿以停战换取整军之期。';}
      else if(elapsed>=30&&w.battles>=2&&w.captures[other]===0&&!incoming.length&&ownLoss>=200){purpose='守土整军';reason='本轮来犯已被挡住，愿保境休兵，重新整顿驻军。';}
      return {willing:!!purpose,purpose,reason:reason||'对方尚想继续此役，目前没有停战意愿。',threatId,war:w,objectiveId:objective?.id||null};
    }
    function intent(s,fromId,toId){
      const d=disposition(s,fromId,toId);if(!d.willing)return null;
      const from=E.getFaction(s,fromId);
      return {kind:'peace',fromId,toId,purpose:d.purpose,reason:d.reason,threatId:d.threatId,leaderId:from.leaderId,ownScore:E.factionStrength(s,fromId).score,targetScore:E.factionStrength(s,toId).score,ownCities:E.ownedCities(s,fromId).length,targetCities:E.ownedCities(s,toId).length};
    }
    function terms(s,a,b){
      const w=war(s,a,b);if(!w)return null;
      let payerId=null;
      if(w.captures[a]>w.captures[b])payerId=b;else if(w.captures[b]>w.captures[a])payerId=a;
      else if(w.losses[a]>w.losses[b]*1.5&&w.losses[a]-w.losses[b]>=400)payerId=a;
      else if(w.losses[b]>w.losses[a]*1.5&&w.losses[b]-w.losses[a]>=400)payerId=b;
      let gold=0;
      if(payerId){const f=E.getFaction(s,payerId),inc=E.incomePreview(s,payerId),available=Math.max(0,f.gold-Math.max(300,inc.upkeepGold*2));gold=Math.floor(Math.min(800,available*.08,50+E.factionStrength(s,payerId).score*.08)/10)*10;if(gold<50){gold=0;payerId=null;}}
      return {payerId,gold,days:DAYS,warStartedDay:w.startedDay};
    }
    function offer(s,target,envoyId,from=s.player){
      const d=disposition(s,target,from),t=existing(s,from,target),quote=terms(s,from,target);
      let error=E.liveError(s)||(!E.getFaction(s,target)||from===target||E.isFactionEliminated(s,target)?'请选择仍存续的其他势力。':'');
      if(!error&&t)error='停战生效中，尚余 '+(t.endDay-s.totalDays)+' 日。';
      if(!error&&E.areAllied(s,from,target))error='双方已有盟约，无需另议停战。';
      if(!error&&!E.allianceEnvoys(s,from).some(g=>g.id===envoyId))error='请委派一位空闲文武议和。';
      if(!error&&!d.willing)error=d.reason;
      if(!error&&E.commandStatus(s,from).remaining<1)error='议和需要 1 道军令。';
      return {ok:!error,message:error,reason:d.reason,purpose:d.purpose||'',terms:quote,truce:t,war:d.war,fromId:from,toId:target,cost:1};
    }
    function termsError(s,a,b,q){
      const w=war(s,a,b);if(!w||!q||q.warStartedDay!==w.startedDay||existing(s,a,b)||E.areAllied(s,a,b)||E.isFactionEliminated(s,a)||E.isFactionEliminated(s,b))return '战局已经变化，请重新商议停战。';
      if(q.payerId){const payer=E.getFaction(s,q.payerId),receiver=E.getFaction(s,q.payerId===a?b:a);if(payer.gold<q.gold)return '议定赔款已无力支付，请重新议价。';if(receiver.gold+q.gold>999999999)return '对方府库已满，无法接收赔款。';}
      return '';
    }
    function conclude(s,a,b,q,reason){
      const invalid=termsError(s,a,b,q);if(invalid)return {ok:false,message:invalid};
      if(q.payerId){E.getFaction(s,q.payerId).gold-=q.gold;E.getFaction(s,q.payerId===a?b:a).gold+=q.gold;}
      s.diplomacy.truces=(s.diplomacy.truces||[]).filter(t=>pair(t.a,t.b)!==pair(a,b));
      const t={a,b,startDay:s.totalDays,endDay:s.totalDays+DAYS,reason};s.diplomacy.truces.push(t);war(s,a,b).settledDay=s.totalDays;
      for(const id of [a,b]){const f=E.getFaction(s,id);if(f.aiObjective&&E.getCity(s,f.aiObjective.targetId)?.owner===(id===a?b:a))f.aiObjective=null;}
      E.changeRelationship(s,a,b,5,'议定停战 +5');E.recheckExpeditions(s);
      const message=E.getFaction(s,a).name+'与'+E.getFaction(s,b).name+'议和，停战 '+DAYS+' 日；'+(q.gold?E.getFaction(s,q.payerId).name+'支付 '+q.gold+' 金。':'互不赔款。')+'在途攻军撤回，停战不授予借道权。';
      E.addLog(s,message,{kind:'peace'});if([a,b].includes(E.realPlayer(s)))E.chronicle(s,'peace',message);
      return {ok:true,accepted:true,kind:'peace',message,truce:t};
    }
    function propose(s,target,envoyId,expected){
      const q=offer(s,target,envoyId);if(!q.ok)return q;
      if(expected&&JSON.stringify(q.terms)!==JSON.stringify(expected))return {ok:false,message:'议和条件已变化，请核对新报价后再确认。'};
      const invalid=termsError(s,s.player,target,q.terms);if(invalid)return {ok:false,message:invalid};
      const from=E.getFaction(s,s.player);from.commands.spent++;E.syncActions(s);
      const pending=s.diplomacy.playerProposal;
      if(pending&&pair(pending.fromId,pending.toId)===pair(s.player,target)){E.rememberDiplomaticReply(s,pending,'accepted');s.diplomacy.playerProposal=null;}
      return conclude(s,s.player,target,q.terms,q.reason);
    }
    function tryAI(s,f){
      if(E.commandStatus(s,f.id).remaining<1)return null;
      const wars=(s.diplomacy?.wars||[]).filter(w=>[w.a,w.b].includes(f.id)).sort((a,b)=>b.lastBattleDay-a.lastBattleDay);
      for(const w of wars){
        const other=w.a===f.id?w.b:w.a;if(!disposition(s,f.id,other).willing)continue;
        if(other===E.realPlayer(s)){const p=E.aiPlayerDiplomacy(s,f,E.ownedCities(s,f.id),E.aiPersonality(s,f.id));if(p?.ok)return p;continue;}
        const envoy=E.allianceEnvoys(s,f.id)[0],q=offer(s,other,envoy?.id,f.id);if(q.ok){const result=propose(s,other,envoy.id,q.terms);if(result.ok)return result;}
      }return null;
    }
    function tick(s,events){
      if(!s.diplomacy?.truces)return;
      const expired=s.diplomacy.truces.filter(t=>t.endDay<=s.totalDays||E.isFactionEliminated(s,t.a)||E.isFactionEliminated(s,t.b));
      for(const t of expired)if(t.endDay<=s.totalDays){const text=E.getFaction(s,t.a).name+'与'+E.getFaction(s,t.b).name+'的停战期已届满。';E.addLog(s,text);if([t.a,t.b].includes(s.player))events.push(text);}
      s.diplomacy.truces=s.diplomacy.truces.filter(t=>!expired.includes(t));
    }
    function valid(s){
      const d=s.diplomacy;if(!d)return true;
      for(const key of ['wars','truces']){const list=d[key];if(list===undefined)continue;if(!Array.isArray(list)||list.length>120)return false;const seen=new Set();
        for(const x of list){if(!record(x)||!E.getFaction(s,x.a)||!E.getFaction(s,x.b)||x.a===x.b||seen.has(pair(x.a,x.b)))return false;seen.add(pair(x.a,x.b));
          if(key==='truces'){if(!integer(x.startDay,0,s.totalDays)||x.endDay!==x.startDay+DAYS||typeof x.reason!=='string'||x.reason.length>200)return false;}
          else if(!integer(x.startedDay,0,s.totalDays)||!integer(x.lastBattleDay,x.startedDay,s.totalDays)||!integer(x.battles,1,1000000)||!record(x.losses)||!record(x.captures)||!record(x.objectives)||![x.a,x.b].every(id=>integer(x.losses[id],0,1000000000)&&integer(x.captures[id],0,1000000)&&E.getCity(s,x.objectives[id]))||x.settledDay!==null&&!integer(x.settledDay,x.startedDay,s.totalDays))return false;
        }
      }
      const p=d.playerProposal;if(p?.kind==='peace'){const q=p.peace;if(!record(q)||q.days!==DAYS||!integer(q.gold,0,800)||!integer(q.warStartedDay,0,s.totalDays)||q.payerId!==null&&![p.fromId,p.toId].includes(q.payerId)||!!q.payerId!==!!q.gold||p.gold!==0||p.grain!==0)return false;}
      return true;
    }
    return {existing,recordBattle,disposition,intent,terms,offer,termsError,conclude,propose,tryAI,tick,valid};
  }
  return {create};
});
