(function(root,factory){'use strict';const moduleApi=factory();if(typeof module==='object'&&module.exports)module.exports=moduleApi;root.TKRealmManagement=moduleApi;})(globalThis,function(){
  'use strict';
  const focuses=Object.freeze({
    balanced:Object.freeze({name:'均衡',description:'维持现有收益与练兵、募兵规则。',gold:1,grain:1,recruit:1,training:0}),
    granary:Object.freeze({name:'粮仓',description:'本城产粮 +12%，税金 −8%。',gold:.92,grain:1.12,recruit:1,training:0}),
    commerce:Object.freeze({name:'商埠',description:'本城税金 +10%，产粮 −8%。',gold:1.10,grain:.92,recruit:1,training:0}),
    military:Object.freeze({name:'军镇',description:'募兵人数上限 +15%，每次练兵额外 +4；税金、产粮各 −5%。募兵照常付费。',gold:.95,grain:.95,recruit:1.15,training:4})
  });
  const goals=Object.freeze({off:'手动经营',farming:'优先屯田',training:'优先练兵',maintain:'维持现状'});
  const defaultBudget=Object.freeze({commands:2,gold:600,grain:600,reserveCommands:2,reserveGold:300,reserveGrain:600});
  const integer=(v,min,max)=>Number.isInteger(v)&&v>=min&&v<=max;
  const record=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
  const budgetValid=b=>record(b)&&Object.keys(defaultBudget).every(k=>integer(b[k],0,k==='commands'||k==='reserveCommands'?10:1000000));
  const spent=()=>({commands:0,gold:0,grain:0});
  function create(E){
    const period=s=>E.calendarInfo(s).period;
    const effects=(c,s)=>focuses[s&&c?.focusChange&&c.focusChange.owner===c.owner&&c.focusChange.finishDay<=s.totalDays?c.focusChange.kind:c?.developmentFocus]||focuses.balanced;
    function normalize(s,c){
      if(c.focusChange&&c.focusChange.owner!==c.owner)delete c.focusChange;
      if(c.stewardship&&c.stewardship.owner!==c.owner)delete c.stewardship;
    }
    function setFocus(s,id,kind){
      const c=E.getCity(s,id),error=E.liveError(s)||(!c||c.owner!==s.player?'请选择我方城池。':'');
      if(error)return {ok:false,message:error};
      if(!Object.hasOwn(focuses,kind)||c.kind==='pass'&&!['balanced','military'].includes(kind))return {ok:false,message:'关口仅可选择均衡或军镇；请选择有效方向。'};
      if(kind===(c.developmentFocus||'balanced'))delete c.focusChange;
      else c.focusChange={kind,owner:c.owner,startedDay:s.totalDays,finishDay:E.calendarInfo(s).nextPeriodDay};
      return {ok:true,message:c.name+(c.focusChange?'下季度改为'+focuses[kind].name+'。':'继续采用'+focuses[kind].name+'方向。')};
    }
    function book(s,id=s.player){
      const data=E.getFaction(s,id)?.stewardship;
      return {budget:{...defaultBudget,...data?.budget},spent:{...(data?.period===period(s)?data.spent:spent())},receipts:data?.receipts||[],lastReport:data?.lastReport||null};
    }
    function safety(s,c){
      if(!c||c.owner!==s.player)return '请选择我方城池。';
      if(c.occupiedUntil>s.totalDays)return '新城整顿中';
      if(s.armies.some(a=>a.kind==='attack'&&a.faction!==c.owner&&E.destination(a)===c.id))return '敌军来袭，托管暂停';
      if(E.neighbors(s,c.id).some(n=>n.owner!==c.owner&&n.owner!=='neutral'&&!E.areAllied(s,c.owner,n.owner)&&!E.ceasefireBetween(s,c.owner,n.owner)&&E.relationship(s,c.owner,n.owner).score<20))return '邻接敌境，托管暂停';
      if(!E.availableProjectOfficers(s,c.id).length)return '暂无空闲驻将';
      return '';
    }
    function status(s,id){
      const c=E.getCity(s,id);if(!c)return null;
      const auto=c.stewardship?.owner===c.owner?c.stewardship:{goal:'off',garrison:400},ledger=book(s,c.owner),economy=E.incomePreview(s,c.owner);
      const floor={gold:Math.max(ledger.budget.reserveGold,economy.upkeepGold*2),grain:Math.max(ledger.budget.reserveGrain,economy.upkeep*2)};
      return {focus:c.developmentFocus||'balanced',pending:c.focusChange||null,automation:{goal:auto.goal,garrison:auto.garrison},...ledger,floor,pause:auto.goal==='off'?'手动经营':safety(s,c),remaining:Object.fromEntries(['commands','gold','grain'].map(k=>[k,Math.max(0,ledger.budget[k]-ledger.spent[k])]))};
    }
    function configure(s,id,options){
      const c=E.getCity(s,id),error=E.liveError(s)||(!c||c.owner!==s.player?'请选择我方城池。':'');if(error)return {ok:false,message:error};
      if(!record(options)||!Object.hasOwn(focuses,options.focus)||c.kind==='pass'&&!['balanced','military'].includes(options.focus))return {ok:false,message:'请选择有效的城池发展方向。'};
      const a=options.automation;
      if(!record(a)||!Object.hasOwn(goals,a.goal)||!integer(a.garrison,1,E.getTroopCapacity(s,c))||c.kind==='pass'&&a.goal==='farming')return {ok:false,message:'请检查托管目标与驻军目标；关口不能屯田。'};
      if(!budgetValid(options.budget))return {ok:false,message:'军令预算须为0—10的整数，金粮预算须为0—1,000,000的整数。'};
      const f=E.getFaction(s,s.player),current=book(s);
      // Editing or toggling settings must never reset this season's expenditure.
      f.stewardship={budget:{...options.budget},period:period(s),spent:current.spent,receipts:current.receipts,lastReport:current.lastReport};
      const changed=setFocus(s,id,options.focus);
      c.stewardship={owner:c.owner,goal:a.goal,garrison:a.garrison};
      return {ok:true,message:changed.message+' '+(a.goal==='off'?'已关闭本城托管。':'已保存托管，推进时间后按全境预算执行。')};
    }
    function settleFocuses(s,events){
      for(const c of s.cities){normalize(s,c);const p=c.focusChange;if(!p||p.finishDay>s.totalDays)continue;c.developmentFocus=p.kind;delete c.focusChange;
        const message=c.name+'的发展方向已改为「'+focuses[p.kind].name+'」。';E.addLog(s,message);if(c.owner===s.player)events.push(message);
      }
    }
    function planAI(s,f,fronts){
      const inc=E.incomePreview(s,f.id),frontIds=new Set(fronts.map(c=>c.id));
      for(const c of E.ownedCities(s,f.id)){
        if(c.focusReviewPeriod===period(s))continue;c.focusReviewPeriod=period(s);
        const kind=c.kind==='pass'?'military':inc.netGrain<0?'granary':frontIds.has(c.id)||f.aiObjective?.stagingId===c.id?'military':inc.netGold<0?'commerce':c.farm>=c.market?'granary':'commerce';
        setFocus(s,c.id,kind);
      }
    }
    function candidates(s,c){
      const a=c.stewardship,pool=E.availableProjectOfficers(s,c.id),result=[];
      const recruiter=pool.slice().sort((x,y)=>E.recruitmentProfile(s,y).capacity-E.recruitmentProfile(s,x).capacity)[0];
      if(recruiter){const room=Math.min(a.garrison-c.troops-E.reservedTroops(s,c.id),E.getTroopCapacity(s,c)-c.troops-E.reservedTroops(s,c.id),E.recruitmentProfile(s,recruiter).capacity);
        for(let amount=Math.floor(room/50)*50;amount>=100;amount-=50)result.push({kind:'recruit',options:{officerId:recruiter.id,type:'infantry',amount},label:'补足驻军'});
      }
      if(a.goal==='farming'&&c.kind!=='pass')result.push({kind:'develop',options:{target:'farm'},label:'开垦农田'});
      if(c.troops&&c.training<(a.goal==='training'?70:50))result.push({kind:'train',options:{},label:'练兵'});
      if(a.goal==='maintain'&&c.kind!=='pass'){
        const inc=E.incomePreview(s,c.owner);if(inc.netGrain<0)result.push({kind:'develop',options:{target:'farm'},label:'补充粮产'});else if(inc.netGold<0)result.push({kind:'develop',options:{target:'market'},label:'改善税收'});
      }
      return result;
    }
    function process(s,events){
      const f=E.getFaction(s,s.player),b=f?.stewardship;if(!b||E.liveError(s))return;
      if(b.period!==period(s)){
        if(b.spent.commands){b.lastReport={period:b.period,day:s.totalDays,...b.spent};const message='托管季报：上季执行 '+b.spent.commands+' 项，使用 '+b.spent.commands+' 令、'+b.spent.gold+' 金、'+b.spent.grain+' 粮。';E.addLog(s,message,{kind:'stewardship'});events.push(message);}
        b.period=period(s);b.spent=spent();
      }
      const own=E.ownedCities(s).filter(c=>c.stewardship?.owner===s.player&&c.stewardship.goal!=='off').sort((a,c)=>(a.stewardship.lastActionDay??-1)-(c.stewardship.lastActionDay??-1)||a.id.localeCompare(c.id));
      for(const c of own){
        if(safety(s,c)||b.spent.commands>=b.budget.commands||E.commandStatus(s).remaining<=b.budget.reserveCommands)continue;
        for(const action of candidates(s,c)){
          const q=E.actionOffer(s,c.id,action.kind,action.options);if(!q.ok)continue;
          const inc=E.incomePreview(s),extra=action.kind==='recruit'?action.options.amount:0;
          const grainFloor=Math.max(b.budget.reserveGrain,(inc.upkeep+E.grainUpkeep(s,extra))*2),goldFloor=Math.max(b.budget.reserveGold,(inc.upkeepGold+Math.ceil(extra*E.RULES.upkeepGold/100))*2);
          if(b.spent.gold+q.cost.gold>b.budget.gold||b.spent.grain+q.cost.grain>b.budget.grain||f.gold-q.cost.gold<goldFloor||f.grain-q.cost.grain<grainFloor)continue;
          // Don't create a foreseeable three-payment food deficit through automation.
          const forecast=E.grainForecast(s,s.player,{additionalGarrison:extra,spend:q.cost.grain});if(forecast.riskDay!==null&&forecast.riskDay!==undefined)continue;
          const before={gold:f.gold,grain:f.grain,commands:E.commandStatus(s).remaining};
          const result=action.kind==='recruit'?E.recruitTroops(s,c.id,'infantry',action.options.amount,q.officerId):action.kind==='train'?E.trainTroops(s,c.id,q.officerId):E.develop(s,c.id,action.options.target,q.officerId);
          if(!result.ok)continue;
          const used={gold:before.gold-f.gold,grain:before.grain-f.grain,commands:before.commands-E.commandStatus(s).remaining};for(const key of Object.keys(used))b.spent[key]+=used[key];
          c.stewardship.lastActionDay=s.totalDays;b.receipts.unshift({cityId:c.id,day:s.totalDays,label:action.label,...used});b.receipts=b.receipts.slice(0,24);break;
        }
      }
    }
    function valid(s){
      for(const c of s.cities){
        if(c.developmentFocus!==undefined&&(!Object.hasOwn(focuses,c.developmentFocus)||c.kind==='pass'&&!['balanced','military'].includes(c.developmentFocus)))return false;
        if(c.focusReviewPeriod!==undefined&&!integer(c.focusReviewPeriod,0,period(s)))return false;
        const p=c.focusChange;if(p!=null&&(!record(p)||!Object.hasOwn(focuses,p.kind)||p.owner!==c.owner||c.kind==='pass'&&!['balanced','military'].includes(p.kind)||!integer(p.startedDay,0,s.totalDays)||p.finishDay!==E.calendarInfo(p.startedDay).nextPeriodDay||p.finishDay<=s.totalDays))return false;
        const a=c.stewardship;if(a!=null&&(!record(a)||a.owner!==c.owner||!Object.hasOwn(goals,a.goal)||!integer(a.garrison,1,E.getTroopCapacity(s,c))||c.kind==='pass'&&a.goal==='farming'||a.lastActionDay!==undefined&&!integer(a.lastActionDay,0,s.totalDays)))return false;
      }
      for(const f of s.factions){const b=f.stewardship;if(b===undefined)continue;
        if(!record(b)||!budgetValid(b.budget)||!integer(b.period,0,period(s))||!record(b.spent)||!['commands','gold','grain'].every(k=>integer(b.spent[k],0,k==='commands'?10:10000000))||!Array.isArray(b.receipts)||b.receipts.length>24)return false;
        if(!b.receipts.every(r=>record(r)&&E.getCity(s,r.cityId)&&integer(r.day,0,s.totalDays)&&['补足驻军','开垦农田','练兵','补充粮产','改善税收'].includes(r.label)&&integer(r.commands,1,1)&&integer(r.gold,0,10000000)&&integer(r.grain,0,10000000)))return false;
        if(b.lastReport!=null&&(!record(b.lastReport)||!integer(b.lastReport.period,0,period(s))||!integer(b.lastReport.day,0,s.totalDays)||!integer(b.lastReport.commands,1,10)||!integer(b.lastReport.gold,0,10000000)||!integer(b.lastReport.grain,0,10000000)))return false;
      }return true;
    }
    return {focuses,goals,defaultBudget,effects,normalize,status,configure,setFocus,settleFocuses,planAI,process,valid};
  }
  return {create};
});
