(function(root,factory){'use strict';const moduleApi=factory();if(typeof module==='object'&&module.exports)module.exports=moduleApi;root.TKRealmManagement=moduleApi;})(globalThis,function(){
  'use strict';
  const focuses=Object.freeze({
    balanced:Object.freeze({name:'均衡',description:'维持现有收益与练兵、募兵规则。',gold:1,grain:1,recruit:1,training:0}),
    granary:Object.freeze({name:'粮仓',description:'本城产粮 +12%，税金 −8%。',gold:.92,grain:1.12,recruit:1,training:0}),
    commerce:Object.freeze({name:'商埠',description:'本城税金 +10%，产粮 −8%。',gold:1.10,grain:.92,recruit:1,training:0}),
    military:Object.freeze({name:'军镇',description:'募兵人数上限 +15%，每次练兵额外 +4；税金、产粮各 −5%。募兵照常付费。',gold:.95,grain:.95,recruit:1.15,training:4})
  });
  const integer=(v,min,max)=>Number.isInteger(v)&&v>=min&&v<=max;
  const record=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
  function create(E){
    const period=s=>E.calendarInfo(s).period;
    const effects=(c,s)=>focuses[s&&c?.focusChange&&c.focusChange.owner===c.owner&&c.focusChange.finishDay<=s.totalDays?c.focusChange.kind:c?.developmentFocus]||focuses.balanced;
    function normalize(s,c){
      if(c.focusChange&&c.focusChange.owner!==c.owner)delete c.focusChange;
      delete c.stewardship;
    }
    function setFocus(s,id,kind){
      const c=E.getCity(s,id),error=E.liveError(s)||(!c||c.owner!==s.player?'请选择我方城池。':'');
      if(error)return {ok:false,message:error};
      if(!Object.hasOwn(focuses,kind)||c.kind==='pass'&&!['balanced','military'].includes(kind))return {ok:false,message:'关口仅可选择均衡或军镇；请选择有效方向。'};
      if(kind===(c.developmentFocus||'balanced'))delete c.focusChange;
      else c.focusChange={kind,owner:c.owner,startedDay:s.totalDays,finishDay:E.calendarInfo(s).nextPeriodDay};
      return {ok:true,message:c.name+(c.focusChange?'下季度改为'+focuses[kind].name+'。':'继续采用'+focuses[kind].name+'方向。')};
    }
    function retireStewardship(s){for(const c of s.cities)delete c.stewardship;for(const f of s.factions)delete f.stewardship;}
    function status(s,id){const c=E.getCity(s,id);return c?{focus:c.developmentFocus||'balanced',pending:c.focusChange||null}:null;}
    function settleFocuses(s,events){
      for(const c of s.cities){normalize(s,c);const p=c.focusChange;if(!p||p.finishDay>s.totalDays)continue;c.developmentFocus=p.kind;delete c.focusChange;
        const message=c.name+'的发展方向已改为「'+focuses[p.kind].name+'」。';E.addLog(s,message);if(c.owner===s.player)events.push(message);
      }
    }
    function planAI(s,f,fronts){
      const inc=E.incomePreview(s,f.id),frontIds=new Set(fronts.map(c=>c.id));
      for(const c of E.ownedCities(s,f.id)){
        if(c.focusReviewPeriod===period(s))continue;c.focusReviewPeriod=period(s);
        const kind=c.kind==='pass'?'military':inc.netGrain<0?'granary':frontIds.has(c.id)||f.aiObjective?.stagingId===c.id?'military':inc.netGold<0?'commerce':c.farm>=c.market?'granary':'commerce';
        setFocus(s,c.id,kind);
      }
    }
    function valid(s){
      for(const c of s.cities){
        if(c.developmentFocus!==undefined&&(!Object.hasOwn(focuses,c.developmentFocus)||c.kind==='pass'&&!['balanced','military'].includes(c.developmentFocus)))return false;
        if(c.focusReviewPeriod!==undefined&&!integer(c.focusReviewPeriod,0,period(s)))return false;
        const p=c.focusChange;if(p!=null&&(!record(p)||!Object.hasOwn(focuses,p.kind)||p.owner!==c.owner||c.kind==='pass'&&!['balanced','military'].includes(p.kind)||!integer(p.startedDay,0,s.totalDays)||p.finishDay!==E.calendarInfo(p.startedDay).nextPeriodDay||p.finishDay<=s.totalDays))return false;
      }return true;
    }
    return {focuses,effects,normalize,retireStewardship,status,setFocus,settleFocuses,planAI,valid};
  }
  return {create};
});
