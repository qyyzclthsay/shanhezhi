/* Local ink-and-watercolour map artwork. Source: built-in image generation, geographic guide plus user's visual reference. */
(function(root){const art={
  "assets": {
    "terrain": "assets/map/ink-landscape-09b1573b893d.webp",
    "settlements": "assets/map/ink-citadels-defb974ff177.webp"
  },
  "cells": {
    "major": [
      2,
      159,
      818,
      404
    ],
    "town": [
      851,
      234,
      566,
      278
    ],
    "pass": [
      1441,
      221,
      729,
      345
    ]
  }
};if(typeof module==='object'&&module.exports)module.exports=art;root.TKMapArt=art;})(globalThis);
