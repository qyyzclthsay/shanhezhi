/* Seasonal ink paintings and readable miniature castles, using a fixed geographic reference. */
(function(root){const art={
  "assets": {
    "settlements": "assets/map/clear-citadels-38c4be34bdd6.webp",
    "summer": "assets/map/ink-summer-74fba41d30fe.webp",
    "spring": "assets/map/ink-spring-cf790b926cbc.webp",
    "autumn": "assets/map/ink-autumn-5b7e66c04b24.webp",
    "winter": "assets/map/ink-winter-6055b2de1319.webp"
  },
  "cells": {
    "major": [
      9,
      104,
      843,
      527
    ],
    "town": [
      852,
      248,
      564,
      327
    ],
    "pass": [
      1436,
      147,
      731,
      476
    ]
  }
};if(typeof module==='object'&&module.exports)module.exports=art;root.TKMapArt=art;})(globalThis);
