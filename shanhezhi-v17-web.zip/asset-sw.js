'use strict';
const ART_CACHE='shanhezhi-art-v1';
const assetRoot=new URL('./assets/',self.location.href);
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==assetRoot.origin||!url.pathname.startsWith(assetRoot.pathname)||!/-[a-f0-9]{12}\.(?:webp|png|svg)$/.test(url.pathname))return;
  event.respondWith((async()=>{
    let cache;
    try{cache=await caches.open(ART_CACHE);const hit=await cache.match(event.request);if(hit)return hit;}catch(_){}
    const response=await fetch(event.request);
    if(response.ok&&cache){try{await cache.put(event.request,response.clone());}catch(_){}}
    return response;
  })());
});
