(function(root){
  'use strict';
  const STORAGE_KEY='shanhezhi-cg-gallery-v1';
  const GROUPS=[['opening','乱世初启'],['capture','攻城告捷'],['loss','城池失守'],['empire','定鼎立国'],['victory','山河归一'],['defeat','山河未尽']];
  const TITLES={opening:'乱世将启',capture:'旌旗入城',loss:'故城暂别',empire:'定鼎立国',victory:'山河归一',defeat:'山河未尽'};
  const BUTTONS={capture:'继续征程',loss:'整军再起',empire:'定鼎山河',victory:'查看征程结算',defeat:'查看征程结算'};
  let api={},current=null,queue=[],timer=null,storageWarning=false;
  let memory={unlocked:[],selections:{},seen:{}};
  const pending=new Set();
  const own=(object,key)=>Object.prototype.hasOwnProperty.call(object,key);
  const esc=value=>String(value??'').replace(/[&<>"']/g,letter=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[letter]));
  const assetsFor=kind=>Array.isArray(root.TKCGAssets?.[kind])?root.TKCGAssets[kind]:[];
  const allAssets=()=>GROUPS.flatMap(([kind])=>assetsFor(kind).map(asset=>({...asset,kind})));
  const element=(tag,className,text)=>{const node=root.document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
  function read(){
    try{
      const saved=JSON.parse(root.localStorage.getItem(STORAGE_KEY)||'null');
      if(saved&&typeof saved==='object')memory={unlocked:Array.isArray(saved.unlocked)?saved.unlocked.filter(id=>typeof id==='string'):[],selections:saved.selections&&typeof saved.selections==='object'?saved.selections:{},seen:saved.seen&&typeof saved.seen==='object'?saved.seen:{}};
    }catch(_){/* Keep this session's collection when browser storage is unavailable. */}
  }
  function save(){
    try{root.localStorage.setItem(STORAGE_KEY,JSON.stringify(memory));}
    catch(_){if(!storageWarning){storageWarning=true;api.toast?.('本机存储不可用，图卷暂时仅保留在本次游玩中。');}}
  }
  const eventId=(kind,key)=>key===undefined||key===null||key===''?null:JSON.stringify([kind,String(key)]);
  function unlock(value){
    const id=typeof value==='string'?value:value?.id;
    if(!allAssets().some(asset=>asset.id===id))return false;
    if(!memory.unlocked.includes(id)){memory.unlocked.push(id);save();}
    return true;
  }
  function selectionFor(kind,eventKey){
    const assets=assetsFor(kind);if(!assets.length)return null;
    const key=eventId(kind,eventKey),saved=key&&own(memory.selections,key)?memory.selections[key]:null;
    let asset=assets.find(item=>item.id===saved);
    if(!asset){asset=assets[Math.floor(Math.random()*assets.length)];if(key)memory.selections[key]=asset.id;}
    unlock(asset.id);if(key)save();
    return {...asset,kind};
  }
  function textFor(kind,{city='这座大城',empire='新朝',leader='群英'}={}){
    switch(kind){
      case 'capture':return `旌旗已上${city}城头。此战告捷，新的山河已收入你的版图。`;
      case 'loss':return `${city}暂落敌手，山河一角蒙尘。整军蓄力，来日再夺故土。`;
      case 'empire':return `今日定国号为「${empire}」。百官奉诏，四方闻名。愿你开创新朝，安定山河。`;
      case 'victory':return '你以谋略聚群英，以坚韧定山河。如今四海归一，百姓重见太平。这一卷功业，因你而成。';
      case 'defeat':return '此番征途暂歇，你与群英并肩的岁月，已写入山河。胜败不尽英雄志，重整旗鼓，下一卷由你再书。';
      default:return `乱世风起，你将与${leader}共书山河之志。`;
    }
  }
  const hasForeignDialog=()=>!!root.document?.querySelector('dialog[open]:not(.tk-cg-dialog)');
  function schedule(){if(timer!==null||!queue.length)return;timer=root.setTimeout(()=>{timer=null;pump();},100);}
  function dismiss(entry,continueFlow){
    if(!entry||current!==entry||entry.done)return;
    entry.done=true;current=null;
    if(entry.dialog.open)entry.dialog.close();entry.dialog.remove();
    if(entry.key)pending.delete(entry.key);
    try{if(continueFlow&&typeof entry.options.onContinue==='function')entry.options.onContinue(entry.asset);}
    finally{schedule();}
  }
  async function download(asset,button,status){
    if(!memory.unlocked.includes(asset.id))return;
    const label=button.textContent;button.disabled=true;button.textContent='正在准备…';status.textContent='';
    try{
      const url=new URL(asset.full,root.location.href);
      if(url.origin!==root.location.origin)throw new Error('Original asset must be same-origin');
      const response=await root.fetch(url.href,{cache:'force-cache'});if(!response.ok)throw new Error('Image download failed');
      const blob=await response.blob();if(!blob.size)throw new Error('Empty image');
      const objectURL=root.URL.createObjectURL(blob),link=element('a');
      link.href=objectURL;link.download=`山河志-${asset.title||TITLES[asset.kind]||'图卷'}-${asset.width}x${asset.height}.webp`;link.hidden=true;
      root.document.body.append(link);link.click();link.remove();root.setTimeout(()=>root.URL.revokeObjectURL(objectURL),30000);
      status.textContent='已准备原尺寸图片，请在浏览器下载中保存。';
    }catch(_){status.textContent='图片下载未完成，请稍后重试。';api.toast?.('图片下载未完成，请稍后重试。');}
    finally{button.disabled=false;button.textContent=label;}
  }
  function present(entry){
    const {asset,options}=entry,kind=entry.kind;
    const dialog=element('dialog','tk-cg-dialog');
    dialog.setAttribute('aria-labelledby','tk-cg-title');dialog.setAttribute('aria-describedby','tk-cg-copy');
    const card=element('div','tk-cg-card'),art=element('div','tk-cg-art');
    const width=Math.max(1,Number(asset.width)||941),height=Math.max(1,Number(asset.height)||1672);
    art.style.aspectRatio=`${width} / ${height}`;
    const image=element('img','tk-cg-image');image.src=asset.full||asset.thumb;image.alt=asset.title||TITLES[kind]||'山河图卷';image.width=width;image.height=height;image.decoding='async';image.loading='eager';
    image.addEventListener('error',()=>{if(asset.thumb&&image.getAttribute('src')!==asset.thumb){image.src=asset.thumb;return;}image.hidden=true;art.append(element('span','tk-cg-image-error','画卷暂未载入'));},{once:false});art.append(image);
    const story=element('div',`tk-cg-story${kind==='empire'||kind==='victory'?' tk-cg-story-gold':''}`);
    const title=element('h2','tk-cg-title',options.title||TITLES[kind]||asset.title);title.id='tk-cg-title';
    const copy=element('p','tk-cg-copy',options.text??textFor(kind,options));copy.id='tk-cg-copy';story.append(title,copy);
    const footer=element('div','tk-cg-footer'),button=element('button','tk-cg-continue',options.buttonLabel||BUTTONS[kind]||'继续征程');
    button.type='button';button.autofocus=true;
    if(options.gallery){
      footer.classList.add('tk-cg-gallery-actions');
      const saveButton=element('button','tk-cg-download','下载原图'),status=element('p','tk-cg-download-status');
      saveButton.type='button';saveButton.title=`保存 ${width} × ${height} 原尺寸图片`;status.setAttribute('role','status');
      saveButton.addEventListener('click',()=>download(asset,saveButton,status));footer.append(saveButton,button,status);
    }else footer.append(button);
    card.append(art,story,footer);dialog.append(card);entry.dialog=dialog;current=entry;
    button.addEventListener('click',()=>dismiss(entry,true));
    dialog.addEventListener('cancel',event=>{event.preventDefault();dismiss(entry,true);});
    dialog.addEventListener('close',()=>dismiss(entry,true));root.document.body.append(dialog);
    try{dialog.showModal();}
    catch(_){dismiss(entry,true);return;}
    if(entry.key){memory.seen[entry.key]=true;save();}
    button.focus({preventScroll:true});
  }
  function pump(){
    if(current||!queue.length)return;
    if(hasForeignDialog()){schedule();return;}
    const entry=queue.shift();present(entry);
  }
  function showEvent(kind,options={}){
    if(!root.document?.body||!assetsFor(kind).length)return false;
    const key=eventId(kind,options.eventKey);
    if(key&&(own(memory.seen,key)||pending.has(key)))return false;
    const asset=selectionFor(kind,options.eventKey);if(!asset)return false;
    if(key)pending.add(key);
    queue.push({kind,key,asset,options,done:false});pump();return true;
  }
  function galleryVisible(){return !!root.document?.querySelector('#main-dialog[open] #tk-cg-gallery');}
  function openGallery(){
    if(typeof api.dialog!=='function')return false;
    const total=allAssets().length,unlocked=allAssets().filter(asset=>memory.unlocked.includes(asset.id)).length;
    const body=GROUPS.map(([kind,label])=>{
      const assets=assetsFor(kind);if(!assets.length)return '';
      const count=assets.filter(asset=>memory.unlocked.includes(asset.id)).length;
      return `<section class="tk-cg-group"><h3>${esc(label)}<span>${count} / ${assets.length}</span></h3><div class="tk-cg-grid">${assets.map(asset=>{
        if(!memory.unlocked.includes(asset.id))return `<div class="tk-cg-tile tk-cg-locked" aria-label="${esc(label)}，尚未解锁"><div class="tk-cg-thumb"><span aria-hidden="true">?</span></div><span class="tk-cg-tile-title">尚未解锁</span></div>`;
        return `<button type="button" class="tk-cg-tile" data-cg-id="${esc(asset.id)}" aria-label="查看${esc(asset.title)}"><span class="tk-cg-thumb"><img src="${esc(asset.thumb||asset.full)}" alt="${esc(asset.title)}" width="${Number(asset.width)||941}" height="${Number(asset.height)||1672}" loading="lazy" decoding="async"></span><span class="tk-cg-tile-title">${esc(asset.title)}</span></button>`;
      }).join('')}</div></section>`;
    }).join('');
    api.dialog('CG图卷',`已解锁 ${unlocked} / ${total}`,`<div id="tk-cg-gallery"><p class="tk-cg-gallery-note">点选已解锁的画卷，可查看并下载原尺寸图片。</p>${body}</div>`,`<button class="primary-button" data-close>合上图卷</button>`,'medium');
    const host=root.document.querySelector('#tk-cg-gallery');
    host?.querySelectorAll('[data-cg-id]').forEach(button=>button.addEventListener('click',()=>{
      const asset=allAssets().find(item=>item.id===button.dataset.cgId);if(!asset||!memory.unlocked.includes(asset.id))return;
      root.document.querySelector('#main-dialog')?.close();
      queue.push({kind:asset.kind,key:null,asset,options:{gallery:true,title:asset.title,text:`${asset.width} × ${asset.height} · 原尺寸画卷`,buttonLabel:'返回图卷',onContinue:openGallery},done:false});pump();
    }));
    return true;
  }
  function clear(){
    queue=[];pending.clear();if(timer!==null){root.clearTimeout(timer);timer=null;}
    dismiss(current,false);if(galleryVisible())root.document.querySelector('#main-dialog')?.close();
  }
  function init(value={}){api=value;read();return root.TKCG;}
  root.TKCG={init,showEvent,selectionFor,unlock,textFor,openGallery,clear,isUnlocked:id=>memory.unlocked.includes(id),get active(){return !!current||queue.length>0||galleryVisible();}};
})(globalThis);
