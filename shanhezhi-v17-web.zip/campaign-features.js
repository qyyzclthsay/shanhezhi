(function(root,factory){
  'use strict';const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.TKCampaignFeatures=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const tactics=['steady','assault','flank'];
  const number=value=>Number.isFinite(value)?Math.max(0,Math.floor(value)):0;
  const unique=list=>[...new Set((Array.isArray(list)?list:[]).filter(id=>typeof id==='string'&&id.length>0))];
  function resolveFormation(preference,available,defaultIds=[]){
    const roster=new Map((available||[]).map(g=>[g.id,g])),saved=unique(preference?.generalIds),usedPreference=saved.length>0;
    const unavailableIds=saved.filter(id=>!roster.has(id));let candidates=saved.filter(id=>roster.has(id));
    const fallback=usedPreference&&!candidates.length;
    if(!candidates.length)candidates=unique(defaultIds).filter(id=>roster.has(id));
    const limit=Math.max(1,Math.min(5,number(roster.get(candidates[0])?.limit)||1)),excessIds=candidates.slice(limit),generalIds=candidates.slice(0,limit);
    return {generalIds,tactic:tactics.includes(preference?.tactic)?preference.tactic:'steady',troopRatio:Number.isFinite(preference?.troopRatio)?Math.max(0,Math.min(1,preference.troopRatio)):.65,
      usedPreference,adjusted:unavailableIds.length>0||excessIds.length>0,fallback,unavailableIds,excessIds};
  }
  // A battle lineup is fixed by the engine: reorder it without adding or losing
  // officers, even when the next defending wave has entirely different people.
  function orderCombatants(preferredIds,actualIds){
    const actual=unique(actualIds);return unique(preferredIds).filter(id=>actual.includes(id)).concat(actual.filter(id=>!preferredIds?.includes(id)));
  }
  function preferenceNotice(resolved){
    if(!resolved?.usedPreference)return '确认出征后会记住将领顺序、方针和出兵比例。';
    if(resolved.fallback)return '常用将领当前不可用，已改用本城推荐编队。';
    const missed=resolved.unavailableIds.length,excess=resolved.excessIds.length;
    return '已沿用常用编队'+(missed||excess?'；'+[missed?'略去 '+missed+' 位不在城中或忙碌的人物':'',excess?'按当前主将编制略去 '+excess+' 人':''].filter(Boolean).join('，'):'')+'。';
  }
  function derive(battle={},result={},playerFaction){
    if(result.unopposed)return {summary:'无驻军接战，本次进驻没有战斗伤亡。',promotionText:'',evidence:{kind:'unopposed'}};
    const own=playerFaction===battle.attackerFaction?'attacker':playerFaction===battle.defenderFaction?'defender':null,side=own||(['attacker','defender'].includes(result.winner)?result.winner:'attacker'),other=side==='attacker'?'defender':'attacker';
    const ours=own?'我方':side==='attacker'?'攻方':'守方',theirs=own?'敌方':other==='attacker'?'攻方':'守方';
    const loss=which=>Number.isFinite(result[which+'Losses'])?number(result[which+'Losses']):null;
    const ownLoss=loss(side),otherLoss=loss(other),casualties=ownLoss!==null&&otherLoss!==null?ours+'损失 '+ownLoss+'，'+theirs+'损失 '+otherLoss+'。':'本战已结算，旧战报缺少完整伤亡记录。';
    const frames=Array.isArray(result.simulation?.frames)?result.simulation.frames:[],events=frames.flatMap(frame=>Array.isArray(frame.events)?frame.events:[]),groups=new Map();
    let supports=0,favorable=0,unfavorable=0;
    const add=(g,trait,mode)=>{if(!g||!trait?.name||!trait.kind)return;const key=g.id+'|'+trait.kind+'|'+mode,record=groups.get(key)||{generalId:g.id,name:g.name,traitName:trait.name,traitKind:trait.kind,mode,count:0};record.count++;groups.set(key,record);};
    for(const e of events){
      if(e.side===side&&Number.isInteger(e.from)&&battle[side+'Generals']?.[e.from]){
        if(e.support)supports++;if(e.counter>0)favorable++;if(e.counter<0)unfavorable++;
        add(battle[side+'Generals'][e.from],e.trait,'attack');
      }else if(e.side===other&&Number.isInteger(e.to))add(battle[side+'Generals']?.[e.to],e.guardTrait,'guard');
    }
    const top=[...groups.values()].sort((a,b)=>b.count-a.count||a.generalId.localeCompare(b.generalId))[0];
    let summary=casualties,evidence={kind:'casualty',ownLoss,otherLoss};
    if(top){summary=top.name+'的「'+top.traitName+'」在交锋中生效 '+top.count+' 次'+(supports?'，'+ours+'另有 '+supports+' 次邻路支援':'')+'；'+casualties;evidence={kind:'trait',...top,supports,ownLoss,otherLoss};}
    else if(supports){summary=ours+'记录 '+supports+' 次邻路支援；'+casualties;evidence={kind:'support',supports,ownLoss,otherLoss};}
    else if(favorable||unfavorable){summary=ours+'有 '+favorable+' 次有利克制、'+unfavorable+' 次不利克制；'+casualties;evidence={kind:'counter',favorable,unfavorable,ownLoss,otherLoss};}
    const promotions=(Array.isArray(result.promotions)?result.promotions:[]).filter(p=>p&&p.to>p.from&&Number.isFinite(p.to)&&Number.isFinite(p.from));
    promotions.sort((a,b)=>Number([3,5,10].includes(b.to))-Number([3,5,10].includes(a.to))||b.to-a.to);
    const highlight=promotions[0],promotionText=highlight&&(!own||own===result.winner)?highlight.name+' '+highlight.from+' → '+highlight.to+' 阶'+(highlight.title?' · '+highlight.title:'')+(Number.isFinite(highlight.capacity)?' · 可带 '+highlight.capacity+' 兵':'')+(promotions.length>1?'；另 '+(promotions.length-1)+' 人晋阶':''):'';
    return {summary,promotionText,evidence};
  }
  function evaluateMilestones(s,playerId=s?.player){
    const h=s?.campaignHistory;if(!h||!playerId)return [];
    const existing=new Set((h.milestones||[]).map(m=>typeof m==='string'?m:m.id)),events=Array.isArray(h.events)?h.events:[],cities=Array.isArray(s.cities)?s.cities:[],result=[];
    const add=(id,title,text)=>{if(!existing.has(id))result.push({id,title,text});};
    const captures=number(h.captures);
    if(h.wins>=1)add('first-win','初战告捷','阶段成就 · 初战告捷：取得本局首场交战胜利。');
    if(captures>=3)add('capture-3','拓土三处','阶段成就 · 拓土三处：累计攻取或进驻 3 处据点。');
    if(captures>=6)add('capture-6','拓土六处','阶段成就 · 拓土六处：累计攻取或进驻 6 处据点。');
    const acquired=new Set(events.filter(e=>e.kind==='capture'||e.kind==='submission').flatMap(e=>e.cityIds||[e.cityId]).filter(Boolean));
    const regions=new Map();for(const c of cities.filter(c=>c.kind!=='pass'&&c.region)){if(!regions.has(c.region))regions.set(c.region,[]);regions.get(c.region).push(c);}
    const complete=[...regions].filter(([,group])=>group.length>=3&&group.every(c=>c.owner===playerId)&&group.some(c=>acquired.has(c.id))).sort((a,b)=>a[0].localeCompare(b[0]))[0];
    if(complete)add('region-unified','一统'+complete[0],'阶段成就 · 一统'+complete[0]+'：据有本剧本'+complete[0]+'全部 '+complete[1].length+' 座城池。');
    const gates=['hulao','tongguan'];if(gates.every(id=>cities.some(c=>c.id===id&&c.owner===playerId))&&gates.some(id=>acquired.has(id)))add('central-passes','两关在握','阶段成就 · 两关在握：同时控制虎牢、潼关两座要关。');
    return result;
  }
  return {resolveFormation,orderCombatants,preferenceNotice,derive,evaluateMilestones};
});
