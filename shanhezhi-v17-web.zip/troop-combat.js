(function(root,factory){'use strict';const common=typeof module==='object'&&module.exports;const api=factory(common?require('./troops.js'):root.TKTroops);if(common)module.exports=api;root.TKTroopCombat=api;})(globalThis,function(T){
  'use strict';
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),clone=x=>JSON.parse(JSON.stringify(x));
  const sum=rows=>rows.reduce((n,c)=>n+c.troops,0);
  function quality(g,type){
    const w=T.definitions[type].forceWeight,force=g.force??35,mind=g.intellect??35;
    const skill=['crossbow','scout'].includes(type)?Math.max(force,mind)*.75+Math.min(force,mind)*.25:force*w+mind*(1-w);
    const leadership=g.leadership??35,attackAbility=(leadership*.4+skill*.6)/100,defenseAbility=(leadership*.65+skill*.35)/100;
    // Officer quality is the main multiplier. The supplied 10/20% counter
    // matrix matters between peers without overturning a clear ability gap.
    return {attack:.6+2.2*attackAbility**2+Math.min(100,g.xp||0)*.0005,defense:.7+1.8*defenseAbility**2};
  }
  const fortification=b=>1+(b.wallBonus??(b.wall||0)*.08);
  function terrainFactor(type,terrain){if(terrain==='plain')return type==='cavalry'?1.08:1;if(terrain==='mountain')return type==='cavalry'?.85:type==='scout'?1.08:type==='crossbow'?1.05:1;if(terrain==='river')return type==='cavalry'?.92:type==='crossbow'?1.06:1;return 1;}
  function tacticFactor(tactic,g,enemy){if(tactic==='assault')return 1.12;if(tactic==='flank')return 1+clamp(((g.intellect??35)-(enemy?.intellect??35))*.0025,-.08,.12);return 1;}
  function traitEffect(g,{side,round=0,index=0,enemy,terrain,support=false}={}){
    const trait=T.traitInfo(g),effect={attack:1,guard:1,pierce:0,support:.55,trait:null};if(!trait)return effect;
    const force=g.force??35,mind=g.intellect??35,lead=g.leadership??35,scale=g.commonKind?.7:1;
    const pulse=cycle=>round===0?1/cycle:(round-1+index)%cycle===0?1:0;
    let bonus=0,active=false,text='';
    if(trait.kind==='strike'){bonus=(.08+force/550)*scale*pulse(4);effect.attack+=bonus;active=bonus>0;text='强攻 +'+Math.round(bonus*100)+'%';}
    if(trait.kind==='guard'){bonus=(.06+lead/1000+(side==='defender'?.05:0))*scale;effect.guard-=bonus;active=true;text='减伤 '+Math.round(bonus*100)+'%';}
    if(trait.kind==='tactics'){bonus=(.10+mind/700+clamp((mind-(enemy?.general?.intellect??35))/1000,0,.08))*scale*pulse(5);effect.attack+=bonus;effect.pierce=.25*pulse(5);active=bonus>0;text='谋击 +'+Math.round(bonus*100)+'%';}
    if(trait.kind==='maneuver'){bonus=(.08+lead/800)*scale*(round===0?.2:round<=2?1:0);effect.attack+=bonus;effect.support=.75;active=bonus>0||support;text=support?'转援保留75%战力':'先机 +'+Math.round(bonus*100)+'%';}
    if(trait.kind==='archery'){bonus=(.06+Math.max(force,mind)/800)*scale*(round===0?.5:enemy&&enemy.troops>enemy.initial*.5?1:0);effect.attack+=bonus;active=bonus>0;text='齐射 +'+Math.round(bonus*100)+'%';}
    if(trait.kind==='water'){bonus=(terrain==='river'?.22:.15*pulse(4))*scale;effect.attack+=bonus;active=bonus>0;text=terrain==='river'?'水战 +22%':'突袭 +'+Math.round(bonus*100)+'%';}
    if(trait.kind==='rally'){bonus=.1*scale*pulse(5);effect.attack+=bonus;active=true;text='全队振军';}
    if(trait.kind==='supply'){effect.guard-=.08*scale;active=true;text='军需护持';}
    if(trait.kind==='discipline'){bonus=(.03+lead/1600)*scale;effect.attack+=bonus;effect.guard-=bonus;active=true;text='攻防 +'+Math.round(bonus*100)+'%';}
    if(active&&round>0)effect.trait={kind:trait.kind,name:trait.name,text};return effect;
  }
  function auras(rows){
    const effect={attack:1,guard:1};
    for(const c of rows.filter(c=>!c.routed)){const kind=T.traitInfo(c.general)?.kind,scale=c.general.commonKind?.7:1;
      if(kind==='rally')effect.attack=Math.max(effect.attack,1+(.025+(c.general.charisma||0)/2500)*scale);
      if(kind==='supply')effect.guard=Math.min(effect.guard,1-(.025+(c.general.politics||0)/2500)*scale);
    }
    return effect;
  }
  function target(rows,index){if(rows[index]&&!rows[index].routed)return {index,support:false};const viable=rows.map((c,i)=>({c,i})).filter(x=>!x.c.routed);viable.sort((a,b)=>Math.abs(a.i-index)-Math.abs(b.i-index)||a.i-b.i);return viable.length?{index:viable[0].i,support:true}:null;}
  function sideRows(b,side){return T.formation(b[side+'Generals'],b[side==='attacker'?'attackers':'defenders']);}
  function factors(b,side,c,enemy,tactic){const q=quality(c.general,c.type),condition=(.8+(b[side+'Training']??25)*.004)*(.8+(b[side+'Morale']??75)*.003),terrain=terrainFactor(c.type,b.terrain),wall=side==='defender'?fortification(b):1;return {q,condition,terrain,wall,counter:1+T.counter(c.type,enemy?.type),tactic:tacticFactor(tactic,c.general,enemy?.general)};}
  function powers(b,tactic='steady'){
    const rows={attacker:sideRows(b,'attacker'),defender:sideRows(b,'defender')};
    const summarize=(side,tac)=>{const enemy=side==='attacker'?'defender':'attacker',total=sum(rows[side])||1,result={command:0,counter:0,terrain:0,condition:0,tactic:0},aura=auras(rows[side]);rows[side].forEach((c,i)=>{const other=rows[enemy][target(rows[enemy],i)?.index],f=factors(b,side,c,other,tac),skill=traitEffect(c.general,{side,enemy:other,terrain:b.terrain}),w=c.initial/total;result.command+=w*f.q.attack*f.q.defense*skill.attack*aura.attack/(skill.guard*aura.guard);result.counter+=w*f.counter;result.terrain+=w*f.terrain;result.condition+=w*f.condition;result.tactic+=w*f.tactic;});return result;};
    const a=summarize('attacker',tactic),d=summarize('defender',b.defenderTactic||'steady'),wall=fortification(b);
    return {attack:b.attackers*a.command*a.counter*a.terrain*a.condition*a.tactic,defense:b.defenders*d.command*d.counter*d.terrain*d.condition*d.tactic*wall,attackCommand:a.command,defenseCommand:d.command,attackerCounter:a.counter,defenderCounter:d.counter,attackTerrain:a.terrain,defenseTerrain:d.terrain,attackTraining:a.condition,defenseTraining:d.condition,attackMorale:1,defenseMorale:1,strategy:a.tactic,defenseAbility:d.tactic,defenseWall:wall};
  }
  // Every replay frame comes from these simultaneous exchanges. No visual-only
  // casualty curve: ordering, individual abilities and counters change outcomes.
  function simulate(b,tactic='steady'){
    const rows={attacker:sideRows(b,'attacker'),defender:sideRows(b,'defender')},initial={attacker:b.attackers,defender:b.defenders};let seed=b.seed>>>0;
    const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    const frames=[],snapshot=events=>({attacker:rows.attacker.map(c=>({troops:c.troops,routed:c.routed})),defender:rows.defender.map(c=>({troops:c.troops,routed:c.routed})),events});
    frames.push(snapshot([]));let winner=b.defenders===0?'attacker':null;
    for(let round=1;round<=2048&&!winner;round++){
      const losses={attacker:rows.attacker.map(()=>0),defender:rows.defender.map(()=>0)},events=[],armyBuffs={attacker:auras(rows.attacker),defender:auras(rows.defender)};
      for(const side of ['attacker','defender']){const other=side==='attacker'?'defender':'attacker',tac=side==='attacker'?tactic:b.defenderTactic||'steady';
        rows[side].forEach((c,i)=>{if(c.routed)return;const aim=target(rows[other],i);if(!aim)return;const enemy=rows[other][aim.index],f=factors(b,side,c,enemy,tac),dq=quality(enemy.general,enemy.type),enemyTactic=other==='attacker'?tactic:b.defenderTactic||'steady';
          const skill=traitEffect(c.general,{side,round,index:i,enemy,terrain:b.terrain,support:aim.support}),defenseSkill=traitEffect(enemy.general,{side:other,round,index:aim.index,enemy:c,terrain:b.terrain});
          const wall=other==='defender'?1+(fortification(b)-1)*(1-skill.pierce):1,guard=enemyTactic==='steady'?1.06:enemyTactic==='assault'?.94:1;
          const damage=Math.max(1,Math.round(Math.pow(c.troops,.9)*.16*(1+Math.max(0,round-40)*.035)*f.q.attack*f.condition*f.terrain*f.counter*f.tactic*skill.attack*armyBuffs[side].attack*(aim.support?skill.support:1)*(.96+random()*.08)*defenseSkill.guard*armyBuffs[other].guard/(dq.defense*wall*guard)));
          losses[other][aim.index]+=damage;events.push({side,from:i,to:aim.index,damage,support:aim.support,counter:Math.round((f.counter-1)*100),trait:skill.trait,guardTrait:defenseSkill.guard<1?defenseSkill.trait:null});
        });
      }
      for(const side of ['attacker','defender'])rows[side].forEach((c,i)=>{if(c.routed)return;c.troops=Math.max(0,c.troops-losses[side][i]);if(c.troops===0)c.routed=true;});
      frames.push(snapshot(events));
      const broken=side=>sum(rows[side])===0,ab=broken('attacker'),db=broken('defender');
      if(ab||db)winner=ab&&db?(sum(rows.attacker)/Math.max(1,initial.attacker)>sum(rows.defender)/Math.max(1,initial.defender)?'attacker':'defender'):db?'attacker':'defender';
    }
    // Positive minimum damage plus late-round pressure guarantees depletion.
    if(!winner)throw new Error('Combat did not reach depletion');
    return {version:'lanes-v2',winner,rounds:frames.length-1,initial:{attacker:rows.attacker.map(c=>({generalId:c.general.id,type:c.type,troops:c.initial})),defender:rows.defender.map(c=>({generalId:c.general.id,type:c.type,troops:c.initial}))},frames,attackersRemaining:sum(rows.attacker),defendersRemaining:sum(rows.defender)};
  }
  return {simulate,powers,quality,terrainFactor,traitEffect,auras,commandProfile:T.commandProfile,formation:T.formation};
});
