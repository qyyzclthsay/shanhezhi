(function(root){
  'use strict';
  let current=null;
  const element=(tag,className,text)=>{
    const node=root.document.createElement(tag);
    if(className)node.className=className;
    if(text!==undefined)node.textContent=text;
    return node;
  };
  const nameOf=(value,fallback)=>typeof value==='string'?value:value?.leader?.name||value?.leader||value?.name||fallback;
  function dismiss(entry,continueGame){
    if(!entry||current!==entry||entry.done)return;
    entry.done=true;current=null;
    if(entry.dialog.open)entry.dialog.close();
    entry.dialog.remove();
    if(continueGame&&typeof entry.onContinue==='function')entry.onContinue();
  }
  function clear(){dismiss(current,false);}
  function show({faction,location,onContinue}={}){
    clear();
    if(!root.document?.body)return false;
    const dialog=element('dialog','tk-opening-dialog');
    dialog.setAttribute('aria-labelledby','tk-opening-title');
    dialog.setAttribute('aria-describedby','tk-opening-copy');
    const card=element('div','tk-opening-card'),art=element('div','tk-opening-art');
    const assets=root.TKAssets?.opening||{},small=assets.small||assets.large,large=assets.large||assets.small;
    if(small){
      const image=element('img','tk-opening-image');
      image.alt='乱世山河开场图';image.width=941;image.height=1672;image.src=small;
      if(large&&large!==small)image.srcset=`${small} 1x, ${large} 2x`;
      image.decoding='async';image.loading='eager';image.fetchPriority='high';
      art.append(image);
    }
    const story=element('div','tk-opening-story');
    const title=element('h2','tk-opening-title','乱世将启');title.id='tk-opening-title';story.append(title);
    const copy=element('div','tk-opening-copy');copy.id='tk-opening-copy';
    copy.append(element('p','',`汉室衰微，十六方势力争雄。有人为苍生，有人逐权柄。你将随${nameOf(faction,'所选君主')}从${nameOf(location,'起始城池')}起兵，写下山河之志。`));
    story.append(copy);
    const footer=element('div','tk-opening-footer'),button=element('button','tk-opening-continue','开启征程');
    button.type='button';button.autofocus=true;footer.append(button);card.append(art,story,footer);dialog.append(card);
    const entry={dialog,onContinue,done:false};current=entry;
    button.addEventListener('click',()=>dismiss(entry,true));
    dialog.addEventListener('cancel',event=>{event.preventDefault();dismiss(entry,true);});
    dialog.addEventListener('close',()=>dismiss(entry,false));
    root.document.body.append(dialog);
    try{dialog.showModal();}catch(error){dismiss(entry,false);throw error;}
    button.focus({preventScroll:true});
    return true;
  }
  root.TKOpening={show,clear,get active(){return !!current&&!current.done;}};
})(globalThis);
