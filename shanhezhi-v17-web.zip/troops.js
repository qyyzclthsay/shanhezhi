(function(root,factory){'use strict';const common=typeof module==='object'&&module.exports;const api=factory(common?require('./troop-assignments.js'):root.TKTroopAssignments,root,common?require('./office-titles.js'):root.TKOfficeTitles);if(common)module.exports=api;root.TKTroops=api;})(globalThis,function(assignments,root,offices){
  'use strict';
  const ids=['scout','shield','spear','crossbow','cavalry'];
  // Row attacks column. This is the exact matrix supplied by the player.
  const matrix=[[0,.2,-.1,.1,-.2],[-.2,0,.1,.2,-.1],[.1,-.1,0,-.2,.2],[-.1,-.2,.2,0,.1],[.2,.1,-.2,-.1,0]];
  const definitions={
    scout:{name:'斥候',color:'#69785a',forceWeight:.25,detail:'善于侦察与迂回，强克盾兵、轻克弩兵。'},
    shield:{name:'盾兵',color:'#6e7c88',forceWeight:.75,detail:'稳守正面，强克弩兵、轻克枪兵。'},
    spear:{name:'枪兵',color:'#a87843',forceWeight:.8,detail:'列阵迎击，强克骑兵、轻克斥候。'},
    crossbow:{name:'弩兵',color:'#91724c',forceWeight:.35,detail:'强克枪兵，轻克骑兵；战力以武力、统率、政治为基础。'},
    cavalry:{name:'骑兵',color:'#985b4a',forceWeight:.85,detail:'善于平原突击，强克斥候、轻克盾兵。'}
  };
  function typeOf(g){return assignments?.assignments?.[typeof g==='string'?g:g?.id]?.type||assignments?.common?.[g?.commonKind]|| (g?.commonKind==='civil'?'scout':g?.garrison?'shield':g?.role==='civil'?'scout':'spear');}
  function info(g){const type=ids.includes(g)?g:typeOf(g);return {id:type,...definitions[type],reason:assignments?.assignments?.[g?.id]?.reason||definitions[type].detail};}
  function counter(a,b){return matrix[ids.indexOf(a)]?.[ids.indexOf(b)]||0;}
  function badge(g,extra=''){const t=info(g),asset=root.TKAssets?.troops?.[t.id];return `<span class="troop-badge ${extra}" data-troop="${t.id}" title="${t.detail}">${asset?`<img src="${asset.small}" width="24" height="24" alt="" loading="lazy" decoding="async">`:''}<span>${t.name}</span></span>`;}
  function table(){return `<table class="troop-counter-table"><caption>我方伤害修正 · 行为我方，列为敌方</caption><thead><tr><th>我方 / 敌方</th>${ids.map(id=>`<th>${badge(id)}</th>`).join('')}</tr></thead><tbody>${ids.map(a=>`<tr><th>${badge(a)}</th>${ids.map(b=>{const n=Math.round(counter(a,b)*100);return `<td class="${n>0?'favorable':n<0?'unfavorable':''}">${n?(n>0?'+':'')+n+'%':'—'}</td>`;}).join('')}</tr>`).join('')}</tbody></table>`;}
  function allocate(total,weights){total=Math.max(0,Math.floor(total));if(!weights.length)return [];const sum=weights.reduce((a,b)=>a+b,0)||1,raw=weights.map(w=>total*w/sum),out=raw.map(Math.floor),order=raw.map((n,i)=>({i,f:n-out[i]})).sort((a,b)=>b.f-a.f||a.i-b.i);for(let n=total-out.reduce((a,b)=>a+b,0),i=0;n>0;n--,i++)out[order[i%order.length].i]++;return out;}
  function commandProfile(g){
    const specialist=g?.role==='civil'?(g.intellect||0):Math.max(g?.force||0,g?.role==='ruler'?(g.intellect||0):0);
    const command=Math.max(g?.leadership||0,Math.round(specialist*.85));
    const officialRank=Math.max(1,Math.min(10,Math.floor(g?.officialRank||(g?.role==='ruler'?2:1))));
    const officers=officialRank>=5?5:officialRank>=3?4:3;
    const kind=g?.role==='civil'||g?.role==='ruler'&&(g.intellect||0)>(g.force||0)+10?'civil':'military',titles=kind==='civil'?civilRanks:militaryRanks;
    const title=offices?.valid(g,officialRank,kind)?g.officeTitle:offices?.fallback(officialRank,kind)||titles[officialRank-1];
    return {command,rank:officialRank,officialRank,title,officers,capacity:officialRank*200,base:200,growth:(officialRank-1)*200,maximum:2000,nextXp:null};
  }
  // Game progression titles; civil and military tracks have separate names.
  const civilRanks=['书佐','主簿','功曹','县令','郡丞','治中','别驾','尚书','少府','议政大臣'];
  const militaryRanks=['队率','军侯','司马','都尉','校尉','裨将军','偏将军','中郎将','镇军将军','领军将军'];
  const traitKinds={
    strike:{label:'破阵',color:'#a65e42',detail:'每四轮发动一次强攻，武力越高，额外伤害越高。'},
    guard:{label:'坚守',color:'#667f94',detail:'持续减少所部伤亡；统率越高越强，守城时更有效。'},
    tactics:{label:'谋击',color:'#537b71',detail:'每五轮发动谋击；智力提高伤害，并穿透部分城防。'},
    maneuver:{label:'疾袭',color:'#8d7251',detail:'开战前两轮伤害提高，转援邻路时保留更多战力。'},
    archery:{label:'齐射',color:'#9a7841',detail:'对兵力尚足的目标远射更强，取武力、智力较高者。'},
    water:{label:'水战',color:'#477d8e',detail:'水乡交战伤害提高；其他地形每四轮发动一次突袭。'},
    rally:{label:'振军',color:'#a58335',detail:'魅力提高全队伤害，同类取最高；所部每五轮额外奋战。'},
    supply:{label:'筹援',color:'#718452',detail:'政治减少全队伤亡，同类取最高；所部额外获得守备增益。'},
    discipline:{label:'整军',color:'#7e708e',detail:'统率持续增强所部攻防，适合稳定作战。'}
  };
  const traitGroups={rally:'liubei yuanshao sunquan daqiao xiaoqiao diaochan kongrong zhanglu',supply:'xunyu jianyong zhangzhao lufan kuaiyue liubiao liuzhang yanpu wanglang taoqian mizhu chendeng lusu huangyueying yuanshu',water:'zhouyu ganning caimao huanggai huangzu liuyao',archery:'huangzhong taishici sunshangxiang',maneuver:'xiahouyuan zhangliao zhanghe gongsunzan mateng machao hansui zhaoyun'};
  const traitAssignments=Object.fromEntries(Object.entries(traitGroups).flatMap(([kind,names])=>names.split(' ').map(id=>[id,kind])));
  function traitInfo(g){
    if(!g||g.garrison)return null;
    const kind=traitAssignments[g.id]||(g.commonKind==='civil'?'supply':{assault:'strike',defense:'guard',flank:'tactics',steady:'discipline'}[g.ability]||'discipline');
    const def=traitKinds[kind],name=g.commonKind?(g.commonKind==='civil'?'筹援':'奋战'):g.trait?.split(/[：:]/)[0]||def.label;
    return {kind,name,...def};
  }
  function formation(generals,total){const gs=generals?.length?generals.slice(0,5):[{id:'garrison',name:'地方守军',garrison:true,leadership:35,force:35,intellect:35,politics:30,charisma:35,xp:0}];const amounts=allocate(total,gs.map(g=>commandProfile(g).capacity));return gs.map((g,i)=>({general:g,type:typeOf(g),initial:amounts[i],troops:amounts[i],lane:i,routed:amounts[i]===0}));}
  return {ids,definitions,matrix,counter,typeOf,info,badge,table,allocate,formation,commandProfile,civilRanks,militaryRanks,traitInfo};
});
