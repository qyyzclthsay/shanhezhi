(function(root){
  'use strict';
  let api,session=null,worker=null,status='idle',progress=null,error='';
  const dependencies=['calendar.js','officer-ratings.js','scenario.js','troop-assignments.js','office-titles.js','troops.js','troop-combat.js','personalities.js','campaign-features.js','realm-management.js','war-diplomacy.js','aftermath.js','engine.js'];
  const node=id=>root.document.getElementById(id),esc=value=>api.esc(String(value??'')),fmt=value=>api.fmt(value);
  const date=day=>{const d=root.TKCalendar.fromTotalDays(day);return d.year+'年'+d.month+'月'+d.day+'日';};
  const realm=f=>f.empire?'「'+f.empire+'」':f.name+'势力';
  function dispose(){worker?.terminate();worker=null;session=null;status='idle';progress=null;error='';}
  function observe(){if(session&&api.getState()!==session)dispose();}
  function pause(){if(status!=='running')return;status='paused';worker?.postMessage({type:'pause'});paint();}
  function eventsMarkup(events){return events?.length?'<ol class="aftermath-events">'+events.map(e=>'<li><time>'+esc(date(e.day))+'</time><span>'+esc(e.text)+'</span></li>').join('')+'</ol>':'<p class="aftermath-note">后续的攻城、称帝、继承与议和将在这里记入战史。</p>';}
  function resultMarkup(r){
    const winner=r.realms.find(f=>f.id===r.winnerId),lead=r.realms[0],unified=r.reason==='unified';
    const outcome=unified?realm(winner)+'统一天下':'天下未定 · 诸侯并立';
    const copy=unified?(r.endDay===r.sourceDay?'你败亡时，天下已归一统。':esc(date(r.endDay))+'，'+esc(realm(winner))+'平定全部城关，对手在途军队亦已终结。'):'推演至'+esc(date(r.endDay))+'，'+(r.reason==='stalemate'?'已连续五年没有领土变化，当前也无攻军在途。':'已达到十五年的推演期限。')+'各方仍未完成统一。'+(lead?'此时'+esc(realm(lead))+'综合实力领先，尚不能称为最终赢家。':'各地仍由地方守军占据。');
    return `<section class="aftermath-result${unified?' is-unified':''}"><span class="aftermath-seal" aria-hidden="true">${unified?'统':'续'}</span><small>依据本局败亡时的局势继续推演</small><h3>${esc(outcome)}</h3><p>${copy}</p>${winner?`<div class="aftermath-winner">${winner.empire?'帝王':'君主'} <b>${esc(winner.leader)}</b>${winner.empire?' · 国号 <b>'+esc(winner.empire)+'</b>':''}</div>`:''}<div class="aftermath-stats"><span><b>${fmt(r.endDay-r.sourceDay)}</b>后续日数</span><span><b>${fmt(r.battles)}</b>交战次数</span><span><b>${fmt(r.cityChanges)}</b>攻取城关</span></div><h4>推演结束时的天下格局</h4><div class="aftermath-table-wrap"><table class="aftermath-table"><thead><tr><th>势力 / 当时君主</th><th>城关</th><th>兵力</th></tr></thead><tbody>${r.realms.map(f=>`<tr><td><strong>${esc(realm(f))}</strong><small>${esc(f.leader)}</small></td><td>${fmt(f.cities)}</td><td>${fmt(f.troops)}</td></tr>`).join('')}${r.neutralCities?'<tr><td>地方守军</td><td>'+fmt(r.neutralCities)+'</td><td>—</td></tr>':''}</tbody></table></div><h4>你离场之后</h4>${eventsMarkup(r.events)}${r.omitted?'<p class="aftermath-note">另有 '+fmt(r.omitted)+' 条战事已汇总至统计。</p>':''}<p class="aftermath-note">这是沿用本局规则与随机种子的模拟后传。你的败亡日期、战绩、兵粮和原有历史记录保留；推演结果随征程保存。</p></section>`;
  }
  function paint(){
    const host=node('aftermath-content');if(!host||api.getState()!==session)return;
    const done=session.aftermath;if(done){host.innerHTML=resultMarkup(done);node('aftermath-control').hidden=true;node('aftermath-return').textContent='返回山河';return;}
    const p=progress,elapsed=p?p.endDay-p.sourceDay:0,limit=root.TKAftermathModel.LIMIT_DAYS;
    host.innerHTML=`<section class="aftermath-progress-panel"><span class="aftermath-seal" aria-hidden="true">史</span><h3>${status==='error'?'推演暂未完成':status==='paused'?'后传已暂停':'群雄仍在争夺天下'}</h3><p class="aftermath-live" role="status">${status==='error'?esc(error):p?'已推演至 '+esc(date(p.endDay))+' · 尚存 '+p.realmCount+' 方势力':'正在从 '+esc(date(session.totalDays))+' 的局势继续推演。'}</p><progress max="${limit}" value="${elapsed}" aria-label="十五年推演期限内的已推演日数"></progress><p class="aftermath-note">已推演 ${fmt(elapsed)} 日 / 最多十五年；统一时提前结束。${p?.leader?'当前领先：'+esc(realm(p.leader))+'，'+fmt(p.leader.cities)+' 座城关。':''}</p><p class="aftermath-explanation">各方继续使用现有规则募兵、筹粮、出征、结盟、议和和继承。只有一方占有全部城关，且其他势力已无在途军队，才认定统一；长期僵持会如实记为割据。</p><p class="aftermath-note">推演可能需要一些时间，可以暂停。关闭此页或切到后台会暂停推演，原征程不会向后推进。</p>${eventsMarkup(p?.events)}</section>`;
    const control=node('aftermath-control');control.hidden=false;control.textContent=status==='running'?'暂停推演':status==='error'?'重新推演':'继续推演';node('aftermath-return').textContent='返回山河';
  }
  function fail(message){worker?.terminate();worker=null;status='error';error=message;paint();}
  function start(){
    if(!session||session!==api.getState()||session.status!=='lost'||session.aftermath)return;
    if(worker){status='running';worker.postMessage({type:'resume'});paint();return;}
    try{
      if(!root.Worker)throw new Error('当前浏览器不支持后台推演，请使用支持此功能的浏览器。');
      const urls=dependencies.map(file=>{const script=[...root.document.scripts].find(s=>s.src&&new URL(s.src).pathname.split('/').pop()===file);if(!script)throw new Error('推演组件不完整，请刷新游戏后再试。');return script.src;});
      const resource=node('aftermath-worker-resource');if(!resource)throw new Error('推演组件加载失败，请刷新游戏。');
      const source=session,current=new root.Worker(resource.href);worker=current;status='running';error='';
      current.onmessage=event=>{
        if(current!==worker||source!==api.getState())return;
        const data=event.data;
        if(data.type==='error'){fail(data.message);return;}
        if(data.type==='progress'){progress=data.progress;paint();return;}
        if(data.type==='complete'){
          if(!root.TKAftermathModel.validReport(data.result,source)){fail('后传结果校验失败，原征程仍保留。');return;}
          source.aftermath=data.result;status='complete';current.terminate();worker=null;api.save();api.render();paint();
        }
      };
      current.onerror=event=>{event.preventDefault();if(current===worker)fail('推演组件加载失败，请检查网络后重试。原征程仍保留。');};
      current.postMessage({type:'start',dependencies:urls,state:source});paint();
    }catch(e){fail(e.message);}
  }
  function show(){
    if(!api?.hasCampaign()||!api.isGameVisible()||api.getState().status!=='lost')return;
    observe();if(!session){session=api.getState();status=session.aftermath?'complete':'idle';}
    api.dialog('天下后传','本局败亡后的 AI 推演','<div id="aftermath-content"></div>','<button class="secondary-button" id="aftermath-return" data-close>返回山河</button><button class="primary-button" id="aftermath-control">暂停推演</button>','medium');
    node('aftermath-control').onclick=()=>status==='running'?pause():start();paint();if(status==='idle')start();
  }
  function mount(context){api=context;node('main-dialog').addEventListener('close',pause);root.document.addEventListener('visibilitychange',()=>{if(root.document.hidden)pause();});root.addEventListener('pagehide',dispose);}
  root.TKAftermath={mount,show,pause,observe};
})(globalThis);
