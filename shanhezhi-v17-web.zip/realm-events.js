(function(root){
  'use strict';
  let api,session,observed=new Set(),observedEmpires=new Set(),queue=[],notice=null;
  const keyOf=e=>e.id||`${e.faction}:${e.totalDays}`;
  const empireKey=f=>`${f.id}:${f.imperial.declaredDay}:${f.imperial.name}`;
  const esc=value=>api.esc(String(value??''));
  function observe(){
    if(!api)return;
    const s=api.getState(),entries=s.eliminations||[];
    if(session!==s){
      session=s;observed=new Set(entries.map(keyOf));observedEmpires=new Set(s.factions.filter(f=>f.imperial).map(empireKey));queue=[];
      if(notice){const previous=notice;notice=null;previous.close();previous.remove();}
      return;
    }
    for(const entry of entries){
      const key=keyOf(entry);if(observed.has(key))continue;observed.add(key);
      queue.push({kind:entry.type==='submission'?'submission':'elimination',entry,totalDays:entry.totalDays});
    }
    for(const f of s.factions.filter(f=>f.imperial)){
      const key=empireKey(f);if(observedEmpires.has(key))continue;observedEmpires.add(key);
      if(f.id!==s.player)queue.push({kind:'imperial',key,faction:f.id,factionName:f.name,leader:f.leader||f.name,name:f.imperial.name,totalDays:f.imperial.declaredDay});
    }
    queue.sort((a,b)=>(a.totalDays||0)-(b.totalDays||0));
  }
  function continueQueue(s,onContinue){
    if(api.getState()!==s)return;
    api.render();if(!maybeShow(onContinue))onContinue?.();
  }
  function showImperial(entry,s,onContinue){
    const card=root.document.createElement('dialog');notice=card;
    card.className='tk-imperial-notice';card.setAttribute('aria-labelledby','tk-imperial-notice-title');
    card.innerHTML=`<div class="tk-imperial-notice-heading"><span class="tk-imperial-notice-seal" aria-hidden="true">诏</span><div><span class="tk-imperial-notice-eyebrow">天下大势</span><h2 id="tk-imperial-notice-title">天下诏闻</h2></div></div><p class="tk-imperial-notice-copy"><strong>${esc(entry.factionName)}势力</strong>昭告天下，<strong>${esc(entry.leader)}</strong>即帝位，定国号为<strong>「${esc(entry.name)}」</strong>。</p><p class="tk-imperial-notice-note">新的帝旗已经升起，诸侯间的盟敌形势随之改变。</p><button type="button" class="tk-imperial-notice-continue" autofocus>知晓诏闻</button>`;
    card.addEventListener('close',()=>{
      if(notice===card)notice=null;
      card.remove();continueQueue(s,onContinue);
    },{once:true});
    card.querySelector('button').onclick=()=>card.close();
    root.document.body.append(card);root.TKCampaign?.pause?.();card.showModal();return true;
  }
  function maybeShow(onContinue){
    if(!api||!queue.length||notice?.open||!api.hasCampaign()||!api.isGameVisible()||root.TKCG?.active||root.TKOpening?.active||root.document?.querySelector('dialog[open]'))return false;
    const s=api.getState();if(s!==session||s.pendingBattle)return false;
    while(queue.length){
      const event=queue.shift();
      if(event.kind==='imperial')return showImperial(event,s,onContinue);
      const entry=event.entry,fallen=api.E.getFaction(s,entry.faction),victor=api.E.getFaction(s,entry.byFaction);
      if(!fallen)continue;
      const own=entry.byFaction===s.player,lost=entry.faction===s.player;
      const fallenName=fallen.imperial?`「${fallen.imperial.name}」`:`${fallen.name}势力`,victorName=victor?.imperial?`「${victor.imperial.name}」`:victor?.name||'群雄';
      if(event.kind==='submission'){
        const leader=s.generals?.find(g=>g.id===fallen.leaderId)?.name||fallen.leader||fallen.name;
        const submittedFaction=fallen.imperial?`${leader}率「${fallen.imperial.name}」众`:`${leader}率众`;
        const text=own?`${submittedFaction}奉表归顺${victorName}。城关、军队与府库纳入你的版图，文武同心，愿与你共护百姓，再续山河之志。`:`${fallenName}奉表归顺${victorName}。自此两方合旗，城关、军队与府库一并纳入，群雄版图再添新局。`;
        root.TKCampaign?.pause?.();
        const shown=root.TKCG?.showEvent('submission',{eventKey:`${api.getCGCampaignId()}:submission:${keyOf(entry)}`,title:'诸侯归心',text,leaderNames:[leader],onContinue:()=>continueQueue(s,onContinue)});
        if(shown)return true;
        continue;
      }
      const text=own?`${fallenName}最后的城头易帜，一方争衡至此落幕。你平定了这片疆土，接下来当安民纳士，再续山河之志。`:lost?`故城尽失，${fallenName}暂别天下争衡。你曾走过的每一步，仍将记入这一卷山河。`:`${fallenName}在与${victorName}的争衡中退出天下舞台。旧旗落下，群雄版图再度改写，新的战机也随之而来。`;
      root.TKCampaign?.pause?.();
      const shown=root.TKCG?.showEvent('elimination',{eventKey:`${api.getCGCampaignId()}:elimination:${keyOf(entry)}`,title:own?'平定一方':lost?'旧旗暂落':'诸侯落幕',text,onContinue:()=>continueQueue(s,onContinue)});
      if(shown)return true;
    }
    return false;
  }
  function init(context){api=context;observe();}
  root.TKRealmEvents={init,observe,maybeShow,get active(){return !!notice?.open;}};
})(globalThis);
