(function(root){
  'use strict';
  let api,session,observed=new Set(),queue=[];
  const keyOf=e=>e.id||`${e.faction}:${e.totalDays}`;
  function observe(){
    if(!api)return;
    const s=api.getState(),entries=s.eliminations||[];
    if(session!==s){session=s;observed=new Set(entries.map(keyOf));queue=[];return;}
    for(const entry of entries){
      const key=keyOf(entry);if(observed.has(key))continue;observed.add(key);
      if(entry.type!=='submission')queue.push(entry);
    }
  }
  function maybeShow(onContinue){
    if(!api||!queue.length||!api.hasCampaign()||!api.isGameVisible()||root.TKCG?.active||root.TKOpening?.active||root.document?.querySelector('dialog[open]'))return false;
    const s=api.getState();if(s!==session)return false;
    while(queue.length){
      const entry=queue.shift(),fallen=api.E.getFaction(s,entry.faction),victor=api.E.getFaction(s,entry.byFaction);
      if(!fallen)continue;
      const own=entry.byFaction===s.player,lost=entry.faction===s.player;
      const fallenName=fallen.imperial?`「${fallen.imperial.name}」`:`${fallen.name}势力`,victorName=victor?.imperial?`「${victor.imperial.name}」`:victor?.name||'群雄';
      const text=own?`${fallenName}最后的城头易帜，一方争衡至此落幕。你平定了这片疆土，接下来当安民纳士，再续山河之志。`:lost?`故城尽失，${fallenName}暂别天下争衡。你曾走过的每一步，仍将记入这一卷山河。`:`${fallenName}在与${victorName}的争衡中退出天下舞台。旧旗落下，群雄版图再度改写，新的战机也随之而来。`;
      root.TKCampaign?.pause?.();
      const shown=root.TKCG?.showEvent('elimination',{eventKey:`${api.getCGCampaignId()}:elimination:${keyOf(entry)}`,title:own?'平定一方':lost?'旧旗暂落':'诸侯落幕',text,onContinue:()=>{if(api.getState()!==s)return;api.render();if(!maybeShow(onContinue))onContinue?.();}});
      if(shown)return true;
    }
    return false;
  }
  function init(context){api=context;observe();}
  root.TKRealmEvents={init,observe,maybeShow};
})(globalThis);
