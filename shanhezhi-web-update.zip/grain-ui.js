(function(root){
  'use strict';let api;
  const labels={recruit:'募兵',train:'练兵',search:'寻访',attack:'出征',transfer:'调兵移将',diplomacy:'外交与岁贡',empire:'称帝',other:'其他行动'};
  const date=day=>{const d=root.TKCalendar.fromTotalDays(day);return `${d.year}年${d.month}月${d.day}日`;};
  const signed=n=>(n>=0?'+':'−')+api.fmt(Math.abs(n));
  function policyMarkup(s=api.getState()){
    const p=api.E.imperialPolicyPreview(s);if(!p)return '';
    const latest=s.logs.find(l=>l.kind==='imperial_policy'&&l.faction===s.player),name=api.E.imperialPolicies[p.policy].name;
    let detail;
    if(p.policy==='military'){
      detail='<p>当季各次月结的军饷、军粮均足额支付时，换季给予每座驻军城池训练 +10、士气 +10、兵力 +20。</p>';
      if(!p.seasonSuppliesPaid)detail+='<p class="grain-warning">本季曾缺饷或缺粮，本季整军增益无法发放。</p>';
    }else if(p.policy==='farming'){
      detail=`<p>按现有库存估算：<b>粮 ${signed(p.estimatedGrain)}</b></p><p>每季按结算时的粮草库存增加5%，不足1粮向下取整。先结算当月产粮和军粮，再计算奖励；到账数量随库存变化。</p>`;
    }else{
      detail=`<p>本季已累计奖励：<b>金 ${signed(p.earnedGold)}</b></p><p>累计当季施行期间已完成月结的税金收入，换季按5%发放。</p>`;
    }
    return `<section class="grain-policy-detail"><strong>现行国策 · ${api.esc(name)}</strong>${detail}<p>下次结算：${date(p.nextDay)}</p>${latest?`<small>最近到账：${api.esc(latest.text)}</small>`:''}</section>`;
  }
  function show(){
    if(!api?.hasCampaign()||root.document.querySelector('#battle-dialog[open]')||root.TKCG?.active||root.TKOpening?.active)return;
    root.TKCampaign?.pause?.();
    const s=api.getState(),E=api.E,f=E.getFaction(s,s.player),forecast=E.grainForecast(s),inc=E.incomePreview(s),spending=E.grainSpendingStatus(s),next=forecast.rows[0],fmt=api.fmt;
    const row=(label,n,expense=false)=>`<div><span>${label}</span><strong class="${expense?'is-cost':'is-gain'}">${expense?'−':'+'}${fmt(n)}</strong></div>`;
    const risk=forecast.riskDay!==null?`<p class="grain-warning" role="status">粮草预警：按当前收支，${date(forecast.riskDay)}月结时可能缺粮。</p>`:'';
    const expenseRows=Object.entries(spending.byKind).filter(([,v])=>v>0).map(([k,v])=>row(labels[k],v,true)).join('');
    const body=`<div class="grain-ledger"><div class="grain-stock"><span>现有粮草</span><strong>${fmt(f.grain)}</strong><small>点击顶部粮草可随时查看</small></div>${risk}<section><h3>${date(next.totalDays)} · 预计月结</h3><div class="grain-breakdown">${row('全境产粮',next.production)}${row('驻军粮耗 · '+fmt(inc.garrisonTroops)+'兵',next.garrison,true)}${row('在途粮耗 · '+fmt(inc.marchingTroops)+'兵',next.marching,true)}${next.policy?row('国策季结奖励',next.policy):''}<div class="grain-total"><span>预计净变化</span><strong class="${next.net<0?'is-cost':'is-gain'}">${signed(next.net)}</strong></div></div></section><section><h3>未来一季 · 3次月结估算</h3><div class="grain-breakdown">${row('累计产粮',forecast.production)}${row('累计养兵',forecast.garrison+forecast.marching,true)}${row('国策奖励',forecast.policy)}<div class="grain-total"><span>预计净变化</span><strong class="${forecast.net<0?'is-cost':'is-gain'}">${signed(forecast.net)}</strong></div></div><p class="grain-note">按现有城池、委派和兵力位置估算，计入季节变化；未来建设、募兵、行军抵达及其他行动会改变结果。</p></section>${policyMarkup(s)}<section><h3>本季行动支出 · 已支付 ${fmt(spending.total)} 粮</h3><div class="grain-breakdown">${expenseRows||'<p class="grain-note">记录期间暂无行动用粮。</p>'}</div>${spending.partial?`<p class="grain-note">记录自${date(spending.startedDay)}更新后开始；此前支出未补记。</p>`:''}<p class="grain-note">这部分已经从库存扣除，不会再次扣入未来预计收支。</p></section><p class="grain-note">每100兵每月：驻城${E.RULES.upkeepGrain}粮，在途${E.RULES.marchingUpkeepGrain}粮；冬季＋5%。农田下季起增加月产粮。</p></div>`;
    api.dialog('粮草账本','全境收支 · 实时估算',body,'<button class="primary-button" data-close>返回天下</button>','medium');
  }
  function bindResource(){
    const node=root.document.getElementById('grain-ledger-entry');if(!api||!node)return;
    const s=api.getState(),forecast=api.E.grainForecast(s),low=forecast.riskDay!==null;
    node.classList.toggle('is-grain-low',low);node.setAttribute('aria-label',`粮草 ${api.fmt(api.E.getFaction(s,s.player).grain)}，${low?'未来一季可能缺粮，':''}查看收支账本`);
    node.onclick=show;node.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();show();}};
  }
  function recruitmentNote(host,amount,cost){
    if(!api||!host)return;
    const s=api.getState(),before=api.E.grainForecast(s),after=api.E.grainForecast(s,s.player,{additionalGarrison:amount,spend:cost});
    host.classList.toggle('grain-warning',after.riskDay!==null);
    host.textContent=`新增驻军每月粮耗 +${api.fmt(after.additionalUpkeep)}；募兵后未来3次月结预计净变化 ${signed(after.net)} 粮（当前 ${signed(before.net)}）。${after.riskDay!==null?'按当前收支，'+date(after.riskDay)+'可能缺粮。':'本次募兵费用已计入库存估算。'}`;
  }
  root.TKGrain={mount:value=>{api=value;},show,bindResource,policyMarkup,recruitmentNote};
})(globalThis);
