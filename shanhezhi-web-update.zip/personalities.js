(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.TKPersonalities=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  // Original game fiction inspired by familiar Three Kingdoms characterisations.
  // Labels, dialogue, relationships and AI preferences are adaptations, not
  // historical quotations or claims that an encounter happened in this scenario.
  const neutralAI=Object.freeze({aggression:1,riskTolerance:1,talentSeeking:1,commerce:1,farming:1,fortification:1,diplomacy:1});
  const rulerRows=[
    ['wei','caocao','曹操','雄略爱才',['爱才','善谋'],'重用能人，先筹粮秣，再把握敌军的破绽。','天下未定，谁有真本事，谁便来助我成事！',{aggression:1.08,riskTolerance:1.02,talentSeeking:1.20,commerce:1.05,farming:1.10,fortification:.95,diplomacy:1.05}],
    ['shu','liubei','刘备','仁厚求贤',['仁义','求贤'],'重民生、惜人才，愿以礼相交，稳住根基再进取。','一城虽小，也要让百姓安居，让有志之士有所归。',{aggression:.92,riskTolerance:.90,talentSeeking:1.18,commerce:.95,farming:1.18,fortification:1.05,diplomacy:1.15}],
    ['wu','sunce','孙策','锐气开疆',['豪迈','急进'],'喜用精锐抢占先机，敢于争夺江东要地。','有路便闯，有城便取！诸君，与我打出一番天地！',{aggression:1.20,riskTolerance:1.15,talentSeeking:1.10,commerce:1.02,farming:.94,fortification:.90,diplomacy:.95}],
    ['qun','yuanshao','袁绍','名门自重',['好名','持重'],'看重声望与兵势，倾向积蓄大军、稳守河北。','袁氏旗号既立，当聚天下英杰，成天下大业。',{aggression:1.02,riskTolerance:.95,talentSeeking:1.08,commerce:1.02,farming:1.10,fortification:1.08,diplomacy:1.08}],
    ['lvbu','lvbu','吕布','骁勇性急',['勇猛','急躁'],'偏爱进攻与冒险，见敌阵松动便催军向前。','兵马备好便随我出城，休教天下小看了吕布！',{aggression:1.20,riskTolerance:1.20,talentSeeking:.90,commerce:.90,farming:.90,fortification:.85,diplomacy:.85}],
    ['yuanshu','yuanshu','袁术','矜贵逐利',['贪财','好势'],'看重府库与排场，倾向经营富庶城池和市集。','淮南钱粮丰厚，府库充盈，方显我袁氏气象。',{aggression:1.05,riskTolerance:1.08,talentSeeking:.90,commerce:1.20,farming:1.08,fortification:.95,diplomacy:.88}],
    ['gongsunzan','gongsunzan','公孙瓒','白马争先',['强硬','好战'],'重骑军与边防，愿主动出兵争夺北方道路。','白马旗向南，北地儿郎的胆气，今日教人看个明白！',{aggression:1.14,riskTolerance:1.12,talentSeeking:.98,commerce:.90,farming:1.02,fortification:1.08,diplomacy:.85}],
    ['mateng','mateng','马腾','西凉豪勇',['豪爽','重义'],'以兵马立足，重视粮草和盟友，择机向东进军。','马要养壮，人要吃饱；西凉弟兄，咱们一同向前。',{aggression:1.08,riskTolerance:1.08,talentSeeking:1.02,commerce:.96,farming:1.12,fortification:1.02,diplomacy:1.10}],
    ['lijue','lijue','李傕','恃兵争利',['强横','逐利'],'偏重军力和控制关口，较少主动礼贤修好。','关中握在手里，粮道握在手里，谁来都得掂量！',{aggression:1.15,riskTolerance:1.12,talentSeeking:.82,commerce:1.08,farming:.98,fortification:1.12,diplomacy:.82}],
    ['liubiao','liubiao','刘表','清望守境',['守成','重文'],'倾向经营荆襄、招纳文士，守好疆界再谈远征。','荆襄既有田粮，也有士望，先使这一方安定下来。',{aggression:.82,riskTolerance:.85,talentSeeking:1.10,commerce:1.08,farming:1.15,fortification:1.18,diplomacy:1.10}],
    ['liuzhang','liuzhang','刘璋','宽缓守土',['宽厚','谨慎'],'优先保有益州田粮与关防，出兵较为谨慎。','蜀地百姓经不起折腾，诸务还请诸位替我多费心。',{aggression:.80,riskTolerance:.80,talentSeeking:1.02,commerce:1.04,farming:1.20,fortification:1.20,diplomacy:1.12}],
    ['zhanglu','zhanglu','张鲁','安民自守',['惠民','自守'],'重粮仓、乡里与关隘，愿以和议维持一方安宁。','让行旅有食，让乡里少忧；汉中的根本在人心。',{aggression:.82,riskTolerance:.85,talentSeeking:1.02,commerce:1.02,farming:1.20,fortification:1.15,diplomacy:1.18}],
    ['liuyao','liuyao','刘繇','持名守序',['重名分','审慎'],'讲求秩序和名分，倾向守城固防、维持盟好。','既领一方之任，便当整肃号令，不可任人轻取。',{aggression:.88,riskTolerance:.90,talentSeeking:.95,commerce:1.02,farming:1.08,fortification:1.15,diplomacy:1.08}],
    ['wanglang','wanglang','王朗','文治兴商',['重文','兴商'],'看重文治和市井，优先经营财赋，谨慎应战。','书声不可绝，市肆不可空；治好会稽，便是根本。',{aggression:.82,riskTolerance:.85,talentSeeking:1.08,commerce:1.20,farming:1.08,fortification:1.08,diplomacy:1.15}],
    ['taoqian','taoqian','陶谦','安徐惜民',['安民','守业'],'重视田粮和地方安定，更愿礼贤结好、少兴战事。','徐州这片田土，还望诸君与我一同照拂。',{aggression:.80,riskTolerance:.85,talentSeeking:1.08,commerce:1.10,farming:1.18,fortification:1.12,diplomacy:1.18}],
    ['kongrong','kongrong','孔融','好士尚义',['礼贤','清谈'],'喜访贤才、结交邻邦，以士望和经营支撑孤城。','北海城小，待贤之席却宽；有志之士，皆可来坐。',{aggression:.82,riskTolerance:.88,talentSeeking:1.20,commerce:1.08,farming:1.05,fortification:1.08,diplomacy:1.20}]
  ];
  const profiles=Object.freeze(Object.fromEntries(rulerRows.map(([id,leaderId,name,label,tags,description,opening,ai])=>[id,Object.freeze({id,leaderId,name,label,tags:Object.freeze(tags),description,opening,ai:Object.freeze({...neutralAI,...ai})})])));
  // id | name | voice | attack | defend | rally | civil assignment | march | accept | refuse
  // Every named officer has authored lines; common recruits use the fallback in atmosphere.js.
  const officerRows=`
caocao|曹操|雄略爱才|敌阵也有能人，可惜今日挡了我的路。|阵脚未乱，何必惧他？|莫急，胜机就在下一合。|钱粮要明，能者要用，我自看成效。|整军赴{city}，先报虚实，再听号令。|能容我展志，便与你共谋一程。|我心中尚有大局，此事不必再提。
xiahou|夏侯惇|刚烈直率|随我进军，不可迟疑！|守住阵线，迎敌！|伤亡各有，阵脚不可乱！|有令便办，休拿空话误了城务。|向{city}进军，谁也不许掉队！|既已应下，往后便看我如何办事。|战败归战败，休拿软话劝我。
xiahouyuan|夏侯渊|果决疾行|敌军还在整队？正好赶上！|先封住要道，别教他们绕过去。|阵后留人接应，轻军随我再进！|快办不等于乱办，文书粮册都跟上。|轻装赴{city}，军粮车别落得太远。|换了旗号，也误不得行军时辰。|我的路还未走尽，今日不应。
caoren|曹仁|沉毅守御|一步压上去，后阵不许露空。|城垣在，我便在此守着。|缺口由我来补，各部守住旗号！|先查缺漏，粮库、城门一处不漏。|到{city}先察险要，给全军留好依托。|既托城防于我，曹仁当尽此责。|我守的不只是一堵城墙。
caohong|曹洪|刚勇护军|随我压上，莫让敌军冲散阵脚！|主阵由我护住，诸军各守其位！|伤兵向后，缺口我来补！|钱粮点清，守备安排妥当，才好放心出兵。|赴{city}，护住粮车，前后相应。|既肯以诚相托，曹洪自当尽力。|旧日恩义未了，恕曹洪难从。
quyi|麴义|傲锐善阵|强弩列前，待我号令齐发！|稳住，待敌近前再放箭！|阵列未散，胜负便还未定！|事有章法，赏罚分明，部众才肯用命。|赴{city}，先察地势，再列强弩。|若肯听我用兵，麴义便为你破阵。|徒有空言，尚不足使我心服。
zhoutai|周泰|坚忍护主|跟紧我，杀开这条路！|有我在，休想越过此阵！|我还能战，诸军莫退！|城门、粮仓，逐处查过；托付之事不能有失。|向{city}进军，我来护住队伍。|既蒙信任，周泰愿效死力。|此身可败，旧义不可轻弃。
dianwei|典韦|忠勇质朴|挡路的过来，先问问这双戟！|有俺在，谁也别想近前！|俺还站着，弟兄们莫退！|细账俺慢慢学，差事绝不糊弄。|去{city}的路俺开，主公只管跟上。|你肯以诚相待，俺便以命尽力。|恩义尚在，俺不能答应。
xunyu|荀彧|端方远虑|军心既齐，方可徐徐进取。|根本未摇，阵前便不可先乱。|守其纲纪，兵虽困而可再振。|先正法度、择贤任事，民心自会归稳。|赴{city}当先定粮程，勿以一战误了根本。|若能安民持正，彧愿尽绵薄之力。|所守之道未同，恕彧不能从命。
chengyu|程昱|峻直持重|彼处兵虽多，未必敢拼到底。|眼前这点声势，还压不垮我。|退一步便失根本，此时更要站稳。|难办的事也须办，先把积弊说清。|向{city}推进，后路不稳便不贪快。|既议定了，往后切莫临事犹疑。|利害我已想透，毋须多言。
yujin|于禁|肃然执纪|按旗进退，擅离阵者必究！|各营归列，不得抢前乱后。|损兵也须成阵，随我收拢队伍！|账有定数，事有定期，依规办理。|行至{city}，队列、粮车皆照军令。|承此任用，于禁仍以军纪自持。|军令未改，岂能任意去就。
yuejin|乐进|短促敢先|城下这一步，我先上！|敌近了？随我迎住！|旗还没倒，接着进！|差事虽细，也要做在头里。|{city}就在前面，头阵交给我！|给我一面旗，我便替你打出路。|未到甘心之时，莫再劝了。
lvbu|吕布|骁勇性急|谁敢挡我兵锋？|放马过来，吕布在此！|随我再冲，打穿此阵！|城中诸事办利索，别误我整军出城。|催马向{city}，此战便教他们识得我！|既识得我的本事，便给我一军施展！|区区一败，便想让我俯首？
zhangliao|张辽|沉着锐断|看准敌隙，随我突进！|列阵待敌，勿失号令。|集中兵力，再破一路！|先分轻重缓急，军民各得其所。|赴{city}，前锋探路，中军紧随。|既得信任，文远自以战功作答。|胜负未定，张辽尚有自己的选择。
gaoshun|高顺|寡言严整|列齐。进阵。|守位，不许擅动。|旗不乱，阵不散。|名册、仓簿，逐一核实。|赴{city}，依次开拔。|既受命，必尽职。|志未改，不必劝。
chengong|陈宫|锐直有谋|此刻不动，更待何时？|敌锋正盛，且教他撞上虚处。|照计行事，切莫又凭一时意气！|政事也需谋断，莫把忠言留到事后。|进{city}前，请先听完此番部署。|既愿听我之言，宫便尽心筹谋。|择主之事，我自有决断。
diaochan|貂蝉|柔语藏锋|阵前声势再大，也藏不住心虚。|诸君莫疑，先守住眼前这一线。|人心未散，便还有转圜之处。|先听各方心事，再解纠缠之结。|赴{city}，愿诸君都能平安归来。|既留一分善意，便可另开一局。|言辞虽美，我却还不能信。
liubei|刘备|仁厚求贤|诸军随我，勿伤无辜！|城中百姓在后，此阵不可失。|稳住阵脚，我与诸君同在！|先安百姓，再足府库，不负这一城所托。|诸军随我前往{city}，沿途勿扰百姓。|若能容我护民济困，备愿同心相助。|诸多旧望尚未放下，恕备不能相从。
guanyu|关羽|矜重守义|关某在此，请来接战！|且看你如何过我这一关。|收拢阵形，随关某再战！|既领此任，关某自当安民守土。|诸军听令，随关某向{city}进军！|既以诚义相待，关某自有交代。|关某心有所守，岂可轻言改易。
zhangfei|张飞|豪烈直言|前面的，来与我较量！|想过此阵，先问过俺！|跟紧俺，一鼓作气！|这事交给俺，谁敢偷懒，俺可看得见！|目标{city}，都跟紧俺！|你这人说话爽快，俺便认下这份情！|别绕弯子，俺今日就是不应！
jianyong|简雍|疏朗善谈|阵前也讲个理，讲不通才动手。|慢着，咱们把这一阵守清楚。|愁眉苦脸作甚，还没到散席的时候。|先坐下听听乡里怎么说，事便好办。|去{city}路上，容我与乡亲问问情形。|话说得明白，我也不故作推辞。|这番道理，还没说到我心里。
sunce|孙策|锐气开疆|随我冲阵，打开一条路！|江东子弟，列阵迎敌！|再进一阵，莫让敌军喘息！|城里办得兴旺，我才好放心往前闯。|将士们，随我向{city}开路！|能并肩开拓，今日便交你这个朋友！|要我收起这番志气，还早！
zhouyu|周瑜|从容雅断|先断其势，再破其阵。|敌军虽众，未必无隙。|稳住中军，待其阵形松动。|如调弦定音，诸务各得其序才好。|水陆相应，向{city}从容进军。|若能同谋远略，瑜愿执此一节。|曲意相从，并非周瑜的志向。
chengpu|程普|宿将稳健|照旧法稳进，锋头不可太散。|老兵守前，新卒守后，听我号令。|这等阵仗见得多了，莫慌！|年资不抵实事，城务一样要亲自查。|往{city}行军，让老卒照看新兵。|既受新命，老夫仍按军法办事。|多年旗号，岂能一句话便改。
huanggai|黄盖|老辣坚毅|老夫还当得起这番冲锋！|有种便来，看谁先撑不住。|这点苦头，老夫受得住！|劳苦事让我来，别把百姓逼得太紧。|开赴{city}，险处老夫先看。|既肯托付，黄盖自当尽力到底。|老骨头还硬，劝降的话免了。
zhangzhao|张昭|肃正敢谏|师出当有节，勿因进兵废了号令。|城中法度未乱，守军便有依凭。|先止纷议，再收军心。|簿籍与法度先立起来，不能只凭兴头。|赴{city}须留人理事，后方不可一日无主。|既肯纳谏，昭当直言尽职。|若只要顺耳之言，何必来问我。
zhuzhi|朱治|宽实安民|入阵有序，不许扰及乡里。|护住归路，民户都在城后。|各护本营，邻阵相援。|把乡里安顿妥当，军中自然少忧。|赴{city}，先通告沿路乡亭。|能安定一方，便值得尽这一份力。|治尚有旧责，不敢轻弃。
lufan|吕范|精细整肃|粮械已齐，各营依次前进。|船车各守其位，别把阵后堵了。|补足短处，再催前军。|入库出库都记清，节用才能久用。|赴{city}的车船钱粮，我已逐项点过。|既付我掌事，账目便不容含糊。|凭一席话，尚不足使我改主。
yuanshao|袁绍|名门自重|河北众将，莫负袁氏威名！|兵势在我，先稳住中军。|我军底蕴尚在，诸将各展其能！|事要办得周全，也要教士民心服。|大军赴{city}，旗鼓仪列不可失序。|既以礼相待，袁某便与你共议前程。|袁氏基业尚在，岂能轻言屈就。
yanliang|颜良|勇锐自负|河北颜良，谁来接我这一阵！|你若不退，便来刀下见高低。|前军随我，杀开这道口子！|细事也能办，只盼早些整军上阵。|向{city}开进，头阵莫与我争！|给我精兵，成败自有刀锋作答。|颜良的气还没泄，莫来劝降。
wenchou|文丑|骁悍争先|马蹄一动，便教你站不稳！|敌骑近前，正好放手一战。|跟紧我的马旗，再冲一回！|先把人手聚齐，别让差事拖在后头。|驰往{city}，落后的赶紧跟上！|既信我的骑军，便看我替你取胜。|战马还在嘶鸣，我怎肯低头。
zhanghe|张郃|灵活审地|换一路进兵，莫撞他坚处。|坡谷自有用处，请敌军来试。|阵势随敌而变，不可拘守一处。|看清地利与人情，再排事务先后。|去{city}，山径渡口都须先探。|能许我临机应变，郃便尽力效命。|时势尚有变化，容我自作判断。
tianfeng|田丰|耿直远谋|此战要看全局，切莫只争眼前。|坚守足以耗敌，何必自乱良谋。|尚可挽回，先停无益的争先！|长策须从今日做起，莫等缺粮再议。|兵向{city}，后续粮运可曾备妥？|肯听逆耳之言，我便不惜直谏。|道理未明，丰不能以败易志。
jushou|沮授|审慎经略|先断通路，再迫敌军自乱。|要害既固，敌军便难久留。|各守所分，别因一处胜败乱了全局。|户口、仓储、军备，须合在一处谋算。|赴{city}应留有接应，兵势不可悬绝。|若能从长计议，授愿为之筹画。|旧责尚在，不能因利害便弃之。
xuyou|许攸|机敏自矜|寻常打法何用？我偏取他要害！|别只盯前阵，他的软肋还在后头。|看见没有？那一处正是可乘之隙。|要办得快，先把我问的实数报来。|往{city}可有捷径？这事该早来问我。|早听我的，便省下许多周折。|这点许诺，就想换我的主意？
yuanshu|袁术|矜贵逐利|兵多粮足，何人敢逆我军威！|府库在后，诸将给我守稳！|赏赐自不会少，先把阵线顶住！|账上的进项要足，门面的气象也不可薄。|进军{city}，沿路财赋先查个明白。|既厚礼相待，我也并非不能商量。|你给的前程，未免太小了些。
jiling|纪灵|勇悍奉令|纪灵奉命，前来取阵！|三尖刀在此，休想轻过。|重整枪刀，再压上一阵！|主公有命，我便按件办妥。|进兵{city}，诸营跟紧中军。|既受调遣，纪灵便以战功回报。|未敢擅改所奉之命。
gongsunzan|公孙瓒|强硬争先|白马义从，策马破敌！|北地阵前，容不得你放肆。|扬起马旗，再把敌锋压回去！|民户要有粮，边骑更不能少草料。|白马旗指向{city}，全军跟上！|既肯共护边土，我便与你同行。|北地的旗还在，我怎可低头。
zhaoyun|赵云|忠谨果敢|诸军跟紧，莫乱阵形！|有我在，此路不会失守。|护住两翼，随我向前！|先顾百姓安危，再把军民诸务办稳。|行向{city}，前后呼应，不许遗下伤卒。|既托我以信义，云当竭诚相报。|志在安民，未敢轻改所从。
tianyu|田豫|边略务实|敌骑有去路，先把那处截住。|守边不能赌气，看准了再动。|轻兵接应，别让溃卒乱了阵脚。|乡情、道路都要问清，治地不能凭空。|赴{city}先派哨骑，沿路留心异动。|若可使一方少患，豫愿效力。|时局须再看清，今日尚不能应。
mateng|马腾|豪爽重义|西凉儿郎，把马蹄放开！|家乡在后，岂容敌骑轻进！|弟兄们并肩顶住，别各自为战！|人得吃饱，马得养壮，根本不可亏。|赴{city}，水草与粮道一路看准。|既以义相待，马某便不负这份情。|西凉旧部尚有托付，不能就此应允。
machao|马超|骁烈锋锐|西凉铁骑，随我向前！|此路有我，休想轻过！|策马再进，冲开敌阵！|差事我自办妥，莫把铁骑久置城中。|铁骑向{city}，先夺敌军锐气！|既许我统军，便看此枪再立新功。|我这口气，尚未平下去！
pangde|庞德|刚毅决绝|今日向前，绝不惜这一身力气！|我守此阵，便容不得半步含糊。|刀锋还在，庞德便还能战！|既然接下了，难处也由我扛。|赴{city}，把退路看清，更把决心立定。|既许一诺，往后便拿性命尽责。|成败可以认，志气不能丢。
hansui|韩遂|老练权衡|看准风向，再催西凉健儿！|把要道握住，自有人来商量。|别逞匹夫之勇，合兵才有胜算。|各家各有难处，须把利害说透。|向{city}走，先问沿路各部的意思。|利害既已说清，咱们便合力成事。|这盘棋还没定，何必催得如此急。
lijue|李傕|强横恃兵|兵锋压上，教他们知道怕！|关口在手，谁敢来夺！|都给我站住，后面可没空地方退！|先点清库粮，军中用度不许短缺。|开向{city}，粮车紧跟兵锋。|既给我兵马立足，便暂共这一局。|我手下的旗号，还轮不到你来改！
guosi|郭汜|悍急争利|前头有路，砍开便是！|想碰我的阵，先掂掂骨头！|谁先怯了，别怪我不客气！|人手与钱粮都给足，差事自然能办。|向{city}压过去，慢吞吞作甚！|有粮有兵，那就一道干！|这点话，还唬不住我。
jiaxu|贾诩|深静审势|不必争强，只须取其不得不救处。|敌锋会尽，何妨稍待。|先保阵形，再议胜机。|看似无事之处，往往最该留心。|赴{city}，先备不利之策，再求可胜之机。|既蒙容纳，诩当谨慎自效。|去就系于全局，此时尚不宜定。
zhangji|张济|老兵求稳|前军莫散，随我压住阵脚。|守住粮道，便有继续作战的本钱。|把各营接上，别教敌军各个击破。|营伍要稳，乡里也得有个活路。|到{city}先找驻营之地，别叫军士露宿。|既有安身之处，济愿尽此一军之力。|旧部还等我交代，不能轻易答应。
liubiao|刘表|雍容守境|荆襄军士，进退须有章法。|保境安民，此阵当守得。|诸君勿躁，我军尚有余力。|先定礼法，再理田赋，使士民各安其业。|兵赴{city}，切记稳守后方，不可轻躁。|若肯保全荆襄士民，表愿再议前程。|一方所托未了，岂能匆匆改易。
caimao|蔡瑁|精明务势|沿河推进，别叫他们抢了渡口。|荆襄水道，我比你熟。|船阵接稳，岸上自有照应。|地方的账目与人情，都须有人打理。|往{city}的渡口，我先派人照看。|既重用荆襄之才，瑁愿助上一程。|这份安排，还未见得稳妥。
huangzu|黄祖|强硬守江|江上来敌，正好迎头截住！|江夏的门，可不是随意开的！|水岸一同守住，休让敌军登稳！|水口、粮仓、守具，我都要亲自过问。|赴{city}，先把水边险处查清。|既仍许我领军守土，便可一议。|江上风浪见得多，劝不倒我。
kuaiyue|蒯越|明达筹略|敌心若散，兵锋便不难进。|稳住州郡之心，自能稳住此阵。|利害已明，诸将当同心行事。|先明各方所需，再定钱粮人事。|赴{city}前，宜把当地人情探明。|大势既明，越愿助其归于安定。|此议尚欠周全，容我不从。
huangzhong|黄忠|老而锐健|老夫这张弓，还拉得开！|来得正好，且试老夫弓力！|稳住，老夫尚有余力！|别只看老夫年岁，差事一样办得利落。|赴{city}，老夫跟得上，不必等！|肯用老夫，这张弓便还有报效之日。|弓弦未松，老夫也不肯松口。
liuzhang|刘璋|宽缓谨慎|诸将务必相顾，莫使军士徒伤。|险关尚在，且稳稳守住。|还望诸位同心，莫教百姓受难。|诸事从宽办理，也请把账目查得明白些。|赴{city}须多备粮草，平安最要紧。|若能保蜀地安宁，璋愿听此安排。|此事牵动太多，容我再想一想。
zhangren|张任|坚毅守隘|山路我熟，随我切入敌侧！|蜀门在此，来者止步。|险处还有我，诸营各守其位！|一处关防一处民生，都不能留下缺口。|进赴{city}，先查山道是否通畅。|既定去就，张任便以尽职作答。|守土之志未改，不必再说。
yanyan|严颜|刚直不屈|老夫出阵，不会只摆个架子！|巴郡老将，尚能守此一关！|头可昂着，阵也得站直了！|任我办事便放心，莫拿年龄作推托。|往{city}去，老夫亲自押住后队。|敬我一分骨气，我便还你一分尽心。|败了便败了，休想折了我的志气。
huangquan|黄权|清醒审势|进时也要看退路，诸军相应。|把渡口留住，局势便不至于尽失。|不可只顾一翼，另一边也需照看！|先陈利弊，再行其事，省得追悔。|赴{city}，须把各路接应逐一落实。|既承信任，权当据实献策。|我的顾虑尚未释去，不能仓促应诺。
zhanglu|张鲁|温厚凝众|诸军相助，只为护住一方。|粮在仓中，民在身后，此阵当守。|同心扶持，困处也能走过去。|让有饥者得食，有难者得助，乡里才安。|前往{city}，沿途看顾行旅与乡民。|只愿民众少受兵祸，鲁可与君同心。|众人所托尚未有着落，不能应允。
yanpu|阎圃|审慎辅谋|敌军若疲，方可顺势而进。|山川足恃，更须人心齐整。|稳住根本，勿逐一时浮利。|汉中大小诸务，贵在量力而行。|赴{city}须慎择山口，莫使后援不继。|若肯量势安民，圃愿略陈所见。|这一步尚有隐忧，未可轻诺。
liuyao|刘繇|持名循序|各依号令，勿辱本军名分。|既任守土之责，便不能退让。|上下各安其位，军势方能重整。|任事须有章程，不能只凭声势。|兵赴{city}，文告与军令一并发下。|既以礼相请，繇愿共议治理。|名分与职责未明，尚不能从。
taishici|太史慈|磊落信义|阵前较量，各凭本事！|想破此阵，先胜过我！|随我再战，莫负此身胆气！|既然应下，子义便给你一个明白交代。|行向{city}，说好何时到，便何时到。|你以诚待我，我以信报你。|我的诺言未了，不能再许第二家。
wanglang|王朗|博闻重治|进兵亦当守法，切勿乱了次序。|城有法度，岂容轻侮。|先止纷争，众议方可归于一令。|士有书读，商有路行，城治才算有成。|赴{city}，沿路文牍与民情一并察看。|若能容我施行文治，朗愿相助。|此中义理未通，恕我不能点头。
taoqian|陶谦|安民惜土|只求止此兵祸，诸军慎进。|徐州百姓在后，请诸位尽心守住。|莫使乡里再受惊，先把阵脚稳下。|粮田莫荒，乡老多问，不能只看府中簿册。|前往{city}，务必约束军士，不扰耕作。|只要百姓能安顿，谦愿放下旧争。|尚有一方托付，未敢轻易答应。
mizhu|糜竺|温厚善筹|军资齐备，诸将可放心向前。|库粮尚足，莫教军心先贫。|把急需的补上，前阵自然能撑住。|生意贵在诚信，治城亦不可只图眼前。|赴{city}，粮车与赏资我来照应。|既愿共济难局，竺愿倾心相助。|钱财可议，所从之义不能贱卖。
chengui|陈珪|老谋善察|不必抢先，看谁先露出底牌。|来者心思未一，不妨静候其变。|乱中先察人心，便知何处可定。|各家的难处，老夫心中自有分寸。|赴{city}之前，先听听地方怎么议论。|时势如此，老夫也愿共谋安定。|这番话，尚未解开我心里的结。
chendeng|陈登|敏干经略|兵势要紧，粮道更要紧，一并压上。|河渠城垒皆可为用，莫只守一角。|调开后队，把两翼重新接起来。|田水通了，仓廪满了，城防才有根。|行向{city}，沿路水势和粮运都记下来。|若有经略一方之地，登愿尽才。|眼前之利，尚不足定长远之策。
kongrong|孔融|儒雅尚义|诸君各尽其能，莫负平日所学。|一城士民在此，岂可轻弃。|义气尚在，便不可先散人心。|延贤之席常开，百姓之苦常问。|前往{city}，也请留心沿途隐居之士。|愿以一身所学，助你兴文安民。|言虽动听，尚未合我心中之义。
xuchu|许褚|憨直勇猛|让开路，俺要冲过去！|俺站这里，你便过不去！|还有俺在，慌什么！|话说简单些，活儿俺认真干。|往{city}走，重活儿都交给俺！|你待俺实在，俺就替你尽力！|俺不懂绕弯的道理，就是不应。
guojia|郭嘉|洒脱洞见|他以为我会稳走？偏试他不敢防处。|声势越足，越要看看他遮掩什么。|别急着叹气，这才露出一点意思。|繁文可省，真正要紧的几件却得看透。|去{city}，不妨先猜猜对面最怕什么。|这一局有趣，嘉愿陪君走下去。|尚未见到值得下注的前程。
ganning|甘宁|豪爽锐进|健儿们，随我抢下此阵！|此处有我，休想讨巧！|趁势向前，别给他整阵的机会！|别嫌我性急，交来的事一样给你办成。|开往{city}，叫弟兄们把精神提起来！|肯放手让我做事，我便替你争气！|只凭几句好话，可留不住甘宁。
xuhuang|徐晃|沉稳严整|斧锋向前，阵形不可乱。|各营守稳，莫因敌声轻动。|按部接应，缺口由我来压住。|事有先后，赏罚有据，照章做实。|赴{city}，军士不得离列取便。|既领新命，公明当以勤谨尽责。|心中职责未了，尚不能从命。
lusu|鲁肃|宽厚远图|此阵牵动全局，诸军当同心。|先保住要冲，日后才有余地。|粮援尚可接续，切莫自失信心。|一家一城的账，也要放到天下去看。|到{city}先结人心，再通往来粮道。|若可共成安定之局，肃愿竭其所有。|眼下之议，尚未见长久之利。
zhugeliang|诸葛亮|谨严筹谋|依计进军，切勿贪功。|各守其位，静候敌变。|阵势尚在，勿自乱方寸。|事无大小，须有始终；先把章程落实。|赴{city}各依部署，沿途粮程不得疏忽。|既以诚相托，亮当尽所能而后已。|所图尚未相合，亮不能轻许。
jiangwei|姜维|锐志好学|察得敌隙，诸军随我进取！|长枪与阵势并用，莫让敌军轻进。|胜负未尽，待我重整前军！|兵事之外也须明治道，维愿从实学起。|赴{city}，地势与敌情一同记熟。|得遇知己，维愿以所学相报。|志尚未酬，不能便在此处止步。
xushu|徐庶|温直识阵|彼阵关节已露，循此处进！|且看敌军换阵，再定应法。|前后照应，莫让一处乱了全军。|先听实情，再解难处，莫被文书遮住眼。|前往{city}，庶先探一探沿路阵势。|若能以诚相待，庶愿献此所学。|心中尚有牵挂，未能相从。
fazheng|法正|锋利决断|机不可再，便在此处下手！|任他叫阵，所求无非诱我先动。|若循旧路无功，便改一着险棋！|拖着不决才最误事，先把关键定下。|赴{city}，该走险处时不可犹疑。|既肯用我的策，我便还你一个结果。|这样的安排，恐怕用不尽我的本事。
weiyan|魏延|自负争功|给我精兵，前阵自能打开！|这一路交给我，休再疑来疑去。|还可再攻，为何便想着退！|既然让我领事，就请看实绩。|兵赴{city}，愿让我独当前锋！|既肯放手任用，魏延必拿功业作答。|我的志向，可不止于这点安置。
pangtong|庞统|疏放奇谋|循常法太慢，且换条路试试。|看他布阵齐整，未必经得起一变。|局面虽乱，恰好可下新棋。|别被枝节缠住，抓住症结便能通盘理顺。|往{city}去，容我先想一条不寻常的路。|既不以形貌论才，统便尽此胸中筹画。|还没给我施展的地方，何必忙着相请。
sunshangxiang|孙尚香|爽利好强|休小看我，阵前自见高低！|此处我守，你尽管来试！|把旗举高，还没轮到认输的时候！|既把差事交给我，便别只当我来凑数。|向{city}出发，别叫我等得不耐烦！|肯认真用我，我也认真与你共事。|我的去留，由我自己拿主意。
zhurong|祝融|烈性果敢|锋刃已出，谁敢上前！|想从我面前过去，先拿出本事！|这点阵势还困不住我！|交我办的事，我自有爽快的办法。|往{city}去，别让脚步落在胆气后头！|你敢信我，我便敢与你并肩。|想让我低头？先收起那些空话。
huangyueying|黄月英|细察巧思|敌阵再巧，也有接不上之处。|先看清来势，再逐处补牢。|解开一处难题，全阵便可转圜。|先看怎样运转，再改哪里费力，事便省心。|去{city}前，把车具和粮程再核一遍。|既重所长，我便尽心把事情做成。|尚未看清你的用意，不能轻诺。
daqiao|大乔|温雅善理|诸军相顾，莫让孤阵独受其锋。|人心安稳，才守得住眼前。|伤卒先有人照应，余众再整旗号。|待人周全，理事分明，繁务也能安顿。|前往{city}，请把留城的人也安置妥当。|既以诚相请，愿助一方少些纷扰。|这份托付还未放心，暂难应下。
xiaoqiao|小乔|灵秀善察|听得声势甚急，未必真有后援。|先辨虚实，不必随敌军起落。|阵声虽乱，旗号还在，便能重整。|细处照看妥当，许多纷争便起不来。|赴{city}，先察沿途消息，莫只催着赶路。|若能容我尽其所长，便与你同心。|言辞我听明白了，心意却还未定。
sunquan|孙权|权衡纳众|诸将各展所长，齐心向前。|凭险守稳，来日自可再图。|一处有缺，各部同补，不许自争。|人才各有所长，钱粮各有用处，须配得其宜。|向{city}进军，前后军务都须有人照应。|若能纳众议、成远图，权愿与君共事。|一时成败，尚不足定我的去就。
wuanguo|武安国|坚勇朴实|铁锤在手，让我打头阵！|北海的门，俺来守！|锤还握得住，便还能再战！|俺不善讲文话，只把交来的差事做实。|往{city}开拔，重械由俺领着走！|你信得过俺，俺便替你顶在前头！|吃一场败仗，可没丢了这身骨气。
zhouxin|周昕|慎思守境|文武相济，进兵不可无序。|守境须定，莫随敌意轻出。|列伍重整，便还有可守之势。|把文簿理清，把乡里安稳，二事不可偏废。|赴{city}，沿途守备也需逐一交接。|若可继续守护乡土，昕愿效力。|所受之责尚在，暂不能答应。
luxun|陆逊|谦静耐心|先察虚实，莫被声势所惑。|守稳阵脚，等他露出破绽。|敌势渐缓，正可从容应对。|先理清条目，再逐事落实，不必争一时声名。|赴{city}须留意敌变，进退不必抢在一刻。|既肯听取所见，逊愿尽心筹划。|时机尚未明朗，容逊再作考量。
`.trim().split('\n');
  const victories=Object.fromEntries(`
caocao|有功者记下，有才者莫轻慢。
xiahou|该守的地方，一处也别松懈。
xiahouyuan|传令要快，点兵更要仔细。
caoren|先补阵缺，再谈赏功。
dianwei|主公无恙，俺便放心了。
xunyu|军令既定，战后亦不可废。
chengyu|莫为一胜，忘了根本。
yujin|各营依册报数，不得虚报。
yuejin|头阵打过，善后也得做在前头。
lvbu|这番兵锋，可曾看清！
zhangliao|哨骑再探，莫给敌军回身之隙。
gaoshun|点兵。整械。候令。
chengong|此番得势，更须听取后计。
diaochan|兵锋暂歇，也让人心缓一缓。
liubei|我愿诸军平安，乡里也少些惊忧。
guanyu|功过依实而论，军纪不可稍弛。
zhangfei|打得痛快！有伤的先来歇着。
jianyong|总算能喘口气，先听听各营的难处。
sunce|弟兄们争气，功劳我都记着！
zhouyu|一阵既定，还须看全局余势。
chengpu|越是得胜，越不能忘了老规矩。
huanggai|老夫尚能当事，苦差也不会躲。
zhangzhao|战后赏罚，须照功籍施行。
zhuzhi|别惊扰乡里，让道路先恢复往来。
lufan|兵械粮车，重新核过再发给各营。
yuanshao|诸将有功，自当昭示众军。
yanliang|此番刀锋，也算扬了河北威名！
wenchou|好马好兵，果然没有白养！
zhanghe|把此处地势记下，往后仍有用处。
tianfeng|一时得胜，长策更不可废。
jushou|要路与后援，仍须牢牢接住。
xuyou|这一处关节，我早说过要紧。
yuanshu|功劳要录，钱粮的账也须点清。
jiling|既奉军命，此番总算有个交代。
gongsunzan|白马旗还须扬稳，别只顾着喝彩！
zhaoyun|再查一遍，莫有失散军士。
tianyu|先报边路消息，免得虚胜实惊。
mateng|弟兄们辛苦，马匹也要好好喂养。
machao|铁骑锐气犹在，整顿后再听军令！
pangde|应下的职责，庞德已尽这一分。
hansui|这一阵过后，各路更该通通消息。
lijue|粮道握牢，才算把胜势留住。
guosi|都看见了吧，咱们的兵可不好惹！
jiaxu|局面虽顺，后手仍不可少。
zhangji|让各营安顿下来，莫再四处散开。
liubiao|保境之外，还请宽待受扰乡民。
caimao|沿河渡口，也得再派人看住。
huangzu|江防不可松，敌军未必就此罢手。
kuaiyue|战后人心所向，宜趁此时安定。
huangzhong|老夫这张弓，可还没叫人失望！
liuzhang|诸位平安便好，善后还请多费心。
zhangren|险道继续设哨，蜀门不可无备。
yanyan|老骨头尚有用，后生们也都争气！
huangquan|此时须明进退，莫只看眼前得失。
zhanglu|若有饥困之人，也请一同照顾。
yanpu|收住一时锐气，先算后续粮程。
liuyao|军中有功有过，皆按号令定论。
taishici|这一阵尽了本事，接下来也不负信义。
wanglang|兵事稍定，文牍与民务便该续上。
taoqian|只愿徐州田里，能少添几分兵祸。
mizhu|军中所需仍由我筹，诸将安心休整。
chengui|此刻各方的心思，还须再看一看。
chendeng|通水道、运粮车，不能等军中来催。
kongrong|诸君护得一方，亦当珍惜此番辛劳。
xuchu|俺还有力气，搬抬伤兵也算一个！
guojia|这才见了分晓，后面的棋仍可细看。
ganning|弟兄们够胆！该领的赏，一个别落。
xuhuang|胜后仍守军纪，方才算得强军。
lusu|此胜当放在全局衡量，莫急于独取。
zhugeliang|功籍、粮簿与军报，须一并核明。
jiangwei|此番所得，不独战功，也有用兵之理。
xushu|此阵关节看明了，还须留心后变。
fazheng|既得这一着，便莫轻易放过后机。
weiyan|我的精兵，这回没有负了所托！
pangtong|棋路既通，下一步便更有可议之处。
sunshangxiang|这回总该知道，我可不是来凑数的！
zhurong|锋刃有了交代，弟兄们也该好生歇息。
huangyueying|损坏的器具与调度的缺处，都记下来。
daqiao|归来的每一人，都该有人照应。
xiaoqiao|喧声稍歇，更听得清各营所需。
sunquan|诸将各有其功，我自当一一记取。
wuanguo|铁锤没叫大家失望，俺也算尽了力！
zhouxin|武事既毕，地方文务也不可耽搁。
luxun|不必多争声名，先把余下诸事办稳。
`.trim().split('\n').map(row=>row.split('|')));
  const officers=Object.freeze(Object.fromEntries(officerRows.map(row=>{
    const [id,name,label,attack,defend,rally,assignment,march,accept,refuse]=row.split('|');
    return [id,Object.freeze({id,name,label,attack,defend,rally,assignment,march,accept,refuse,victory:victories[id]})];
  })));
  const byName=Object.fromEntries(Object.values(officers).map(g=>[g.name,g]));
  function voiceFor(g){return typeof g==='string'?officers[g]||byName[g]||null:officers[g?.id]||byName[g?.name]||null;}
  const rulerById=Object.fromEntries(Object.values(profiles).map(p=>[p.leaderId,p]));
  // Successor policy is original game characterisation, not a historical score.
  // Eight baselines keep the choices coherent; explicit individual adjustments
  // distinguish officers within a baseline. Neither these nor common profiles
  // modify combat attributes, prices or success chances.
  const archetypeRows=[
    ['vanguard','勇进争先','偏好主动出兵、争取先机，较少等待守备完备。',[1.16,1.15,.94,.90,.96,.90,.90]],
    ['raider','机动取势','重视主动进军和迂回时机，保留适度接应。',[1.12,1.07,1.00,.96,1.00,.96,.98]],
    ['disciplined','严整用兵','先整军和补足守备，再按准备情况出击。',[1.02,.94,1.04,1.00,1.06,1.14,.98]],
    ['guardian','固守要冲','多留预备兵，优先修防和粮草，谨慎出征。',[.86,.84,1.02,1.04,1.10,1.18,1.04]],
    ['strategist','筹谋择机','重视求贤与粮秣准备，审察形势再寻机出兵。',[1.02,.94,1.14,1.04,1.12,1.08,1.08]],
    ['steward','持重治政','重视田粮和人才，先把城中诸务安排妥当。',[.84,.84,1.12,1.10,1.16,1.08,1.10]],
    ['diplomat','结好纳士','优先结交邻邦与延揽人才，少作冒险进军。',[.90,.88,1.14,1.10,1.06,1.02,1.20]],
    ['merchant','通商筹资','优先经营集市和财赋，以充足钱粮支持军务。',[.86,.88,1.04,1.20,1.10,1.04,1.14]]
  ];
  const aiKeys=Object.keys(neutralAI);
  const archetypes=Object.freeze(Object.fromEntries(archetypeRows.map(([id,label,description,values])=>[id,Object.freeze({id,label,description,ai:Object.freeze(Object.fromEntries(aiKeys.map((key,i)=>[key,values[i]])))})])));
  const successorRows=[
    ['xiahou','vanguard',{aggression:1.14,fortification:1.02},'敢于迎敌，整军之外也会留心本城守备。'],
    ['xiahouyuan','raider',{aggression:1.18,riskTolerance:1.14,farming:1.04},'喜抢行军先机，尽量缩短等候，也会预备粮秣。'],
    ['caoren','guardian',{fortification:1.20,riskTolerance:.80,aggression:.88},'优先修防、多留守兵，兵势充分才向外进取。'],
    ['dianwei','vanguard',{aggression:1.10,riskTolerance:1.10,fortification:1.06},'用兵勇猛，较少经营盟约，更愿亲力护住根本。'],
    ['xunyu','steward',{talentSeeking:1.20,farming:1.18,diplomacy:1.14},'先求贤、足田粮，以稳固后方支撑长期进取。'],
    ['chengyu','guardian',{aggression:.96,talentSeeking:1.10,diplomacy:.94},'临敌重守根本，肯用人才，但不轻易依赖盟好。'],
    ['yujin','disciplined',{riskTolerance:.88,fortification:1.18,diplomacy:.92},'重军纪与守备，准备不足时宁可暂缓出兵。'],
    ['yuejin','vanguard',{aggression:1.19,riskTolerance:1.12,talentSeeking:.98},'积极争取出击机会，稍有准备便愿率先攻坚。'],
    ['zhangliao','raider',{aggression:1.16,riskTolerance:1.02,fortification:1.08},'善取进攻时机，同时保留接应，少作孤注一掷。'],
    ['gaoshun','disciplined',{riskTolerance:.86,fortification:1.20,talentSeeking:1.08},'先整军、固守与选任能人，准备齐整再出阵。'],
    ['chengong','strategist',{aggression:1.08,riskTolerance:1.06,diplomacy:.96},'愿用奇策主动进取，更重谋划与人才而非盟约。'],
    ['diaochan','diplomat',{aggression:.84,commerce:1.14,talentSeeking:1.16},'重视修好与人事周旋，以经营和纳士减少兵争。'],
    ['guanyu','disciplined',{aggression:1.14,riskTolerance:1.04,diplomacy:.92},'军务整肃而进取心强，较少以外交代替出战。'],
    ['zhangfei','vanguard',{aggression:1.20,riskTolerance:1.20,commerce:.86},'敢战敢进，等待较少，把更多精力用在军务。'],
    ['jianyong','diplomat',{aggression:.82,talentSeeking:1.18,commerce:1.08},'倾向访贤和商谈，先以人情与盟好稳住局面。'],
    ['zhouyu','strategist',{aggression:1.10,riskTolerance:1.02,talentSeeking:1.16,fortification:1.12},'求贤与军备并重，准备充分便主动争取战机。'],
    ['chengpu','disciplined',{aggression:.98,riskTolerance:.90,farming:1.10},'用兵持重，照顾粮秣与守备，不急于冒进。'],
    ['huanggai','vanguard',{aggression:1.12,riskTolerance:1.08,fortification:1.06},'愿担险战，也会补足防备，保持再战的余地。'],
    ['zhangzhao','steward',{commerce:1.16,talentSeeking:1.18,fortification:1.12},'先理财赋、任用能人和修防，少兴仓促之师。'],
    ['zhuzhi','steward',{aggression:.92,farming:1.20,fortification:1.14},'重田粮和地方安定，守备稳固后才谋进军。'],
    ['lufan','steward',{commerce:1.18,farming:1.14,fortification:1.16},'精心筹措军需，先经营财赋、补防，再谈远征。'],
    ['yanliang','vanguard',{aggression:1.18,riskTolerance:1.18,diplomacy:.86},'偏爱正面进取，敢以较少准备争夺阵前胜机。'],
    ['wenchou','vanguard',{aggression:1.17,riskTolerance:1.16,fortification:.86},'催军争先，偏重进攻，通常少留预备兵。'],
    ['zhanghe','raider',{riskTolerance:.98,talentSeeking:1.08,fortification:1.10},'主动寻找可乘之机，兼顾人才、守备与撤转余地。'],
    ['tianfeng','strategist',{aggression:.90,riskTolerance:.82,talentSeeking:1.18,farming:1.20},'重长期准备、求贤和粮草，反对兵势不足时冒进。'],
    ['jushou','strategist',{aggression:.92,riskTolerance:.86,fortification:1.18,farming:1.18},'将守备和粮运连同全局谋划，出兵保留充足后援。'],
    ['xuyou','strategist',{aggression:1.10,riskTolerance:1.14,commerce:1.16,talentSeeking:1.06},'愿用风险较高的机会，也看重财赋与眼前收益。'],
    ['jiling','vanguard',{aggression:1.10,riskTolerance:1.02,fortification:1.10},'倾向出兵争功，同时比急进之将多备守兵。'],
    ['zhaoyun','disciplined',{riskTolerance:.86,talentSeeking:1.12,farming:1.14,diplomacy:1.10},'重军民安定与接应，整军求贤后稳妥进取。'],
    ['tianyu','guardian',{aggression:.94,riskTolerance:.90,talentSeeking:1.10,diplomacy:1.12},'先固守要道、通好邻邦，再寻找有利战机。'],
    ['machao','vanguard',{aggression:1.20,riskTolerance:1.18,fortification:.88},'积极催军进取，敢抢先机，留守兵力较少。'],
    ['pangde','vanguard',{aggression:1.12,riskTolerance:1.04,farming:1.06,fortification:1.10},'敢于攻坚，也重粮草和预备，不轻弃已定职责。'],
    ['hansui','diplomat',{aggression:1.02,riskTolerance:1.02,commerce:1.16,talentSeeking:1.04},'以修好协调局势，也愿在利害合宜时出兵。'],
    ['guosi','vanguard',{aggression:1.20,riskTolerance:1.19,talentSeeking:.82,diplomacy:.82},'恃兵争先，敢作险进，较少投入求贤与修好。'],
    ['jiaxu','strategist',{aggression:.88,riskTolerance:.80,fortification:1.16,diplomacy:1.16},'先保全兵力与后路，借修好和筹备等待稳妥机会。'],
    ['zhangji','disciplined',{aggression:.96,riskTolerance:.92,farming:1.16,diplomacy:1.08},'重粮道与军伍安定，倾向有后援的稳步行动。'],
    ['caimao','guardian',{aggression:.90,commerce:1.18,diplomacy:1.12},'优先掌握财赋和要地，借修好稳住守备局面。'],
    ['huangzu','guardian',{aggression:1.00,riskTolerance:.94,diplomacy:.88},'注重守防而态度强硬，必要时愿主动迎敌。'],
    ['kuaiyue','steward',{talentSeeking:1.16,diplomacy:1.20,commerce:1.14},'兼顾内政与修好，以任贤和协商安定周边。'],
    ['huangzhong','vanguard',{aggression:1.10,riskTolerance:1.02,farming:1.04,fortification:1.12},'锐气不减，也有耐心备战，兼顾粮草与防务。'],
    ['zhangren','guardian',{aggression:.90,fortification:1.20,diplomacy:.94},'严守险要，多留预备，较少依靠盟好解围。'],
    ['yanyan','guardian',{aggression:.96,riskTolerance:.90,fortification:1.20,diplomacy:.98},'守土坚定，先备城防，也敢在稳妥时迎战。'],
    ['huangquan','steward',{riskTolerance:.80,fortification:1.18,diplomacy:1.16},'重后路与长远利害，备好守防、粮运再行进取。'],
    ['yanpu','steward',{aggression:.82,farming:1.20,fortification:1.16,diplomacy:1.14},'量力经营田粮与山关，以修好争取休养时间。'],
    ['taishici','raider',{aggression:1.14,riskTolerance:1.04,talentSeeking:1.08,diplomacy:1.10},'勇于进取而重信义，愿与可靠盟友相互照应。'],
    ['mizhu','merchant',{talentSeeking:1.18,diplomacy:1.18,farming:1.12},'优先兴商筹资，也肯花费财货延揽人才、结好邻邦。'],
    ['chengui','diplomat',{aggression:.84,riskTolerance:.82,talentSeeking:1.10,fortification:1.12},'先察人情、联结邻邦，少作风险难料的出兵。'],
    ['chendeng','steward',{aggression:1.00,riskTolerance:.94,farming:1.20,commerce:1.16},'优先经营田粮与水运，有了积蓄便谋主动进取。'],
    ['xuchu','vanguard',{aggression:1.14,riskTolerance:1.12,talentSeeking:.90,fortification:1.04},'重直接出兵与护卫根本，较少经营求贤事务。'],
    ['guojia','strategist',{aggression:1.14,riskTolerance:1.16,talentSeeking:1.18,fortification:.96},'积极求贤，愿以较高风险抓住稍纵即逝的战机。'],
    ['ganning','raider',{aggression:1.20,riskTolerance:1.16,commerce:.90,diplomacy:.92},'偏爱快速主动的出兵，敢抢先机，不愿久待。'],
    ['xuhuang','disciplined',{aggression:1.06,riskTolerance:.90,fortification:1.18,farming:1.12},'先整军、足粮、固防，再有序压上兵锋。'],
    ['lusu','diplomat',{talentSeeking:1.18,commerce:1.18,farming:1.14,riskTolerance:.84},'修好居先，同时筹措财赋和人才，支撑长远局面。'],
    ['zhugeliang','strategist',{aggression:.96,riskTolerance:.84,talentSeeking:1.20,farming:1.20,fortification:1.16},'优先求贤、筹粮和修防，准备周全后再推进。'],
    ['jiangwei','strategist',{aggression:1.16,riskTolerance:1.08,talentSeeking:1.16,fortification:1.02},'求贤与进取并重，较少长久停留于守成。'],
    ['xushu','strategist',{aggression:.98,riskTolerance:.90,talentSeeking:1.18,diplomacy:1.14},'重求贤和察敌，准备与盟好都有着落才出兵。'],
    ['fazheng','strategist',{aggression:1.14,riskTolerance:1.18,talentSeeking:1.10,diplomacy:.94},'敢用险策抢占机会，较少为等待盟好推迟出兵。'],
    ['weiyan','vanguard',{aggression:1.20,riskTolerance:1.16,fortification:.94,talentSeeking:1.02},'希望主动领军争功，愿以更少等候换取战机。'],
    ['pangtong','strategist',{aggression:1.12,riskTolerance:1.16,talentSeeking:1.20,commerce:1.08},'喜访贤才、另辟进路，对有价值的险机更愿尝试。'],
    ['sunshangxiang','raider',{aggression:1.16,riskTolerance:1.12,commerce:.92,diplomacy:.96},'行事爽利，偏爱主动出击，不耐久候与繁复财务。'],
    ['zhurong','vanguard',{aggression:1.18,riskTolerance:1.20,commerce:.84,diplomacy:.88},'勇于直进，对险战顾虑较少，经营投入偏低。'],
    ['huangyueying','steward',{talentSeeking:1.18,commerce:1.16,fortification:1.20,riskTolerance:.82},'重任贤、改善经营和补牢防备，少作仓促远征。'],
    ['daqiao','diplomat',{aggression:.80,commerce:1.18,farming:1.14,talentSeeking:1.18},'先理财赋、安顿地方，再以求贤和修好巩固根本。'],
    ['xiaoqiao','diplomat',{aggression:.84,riskTolerance:.82,talentSeeking:1.20,fortification:1.10},'重延揽人才和审察局势，以盟好与守备争取余地。'],
    ['sunquan','steward',{aggression:.94,riskTolerance:.90,talentSeeking:1.16,commerce:1.15,farming:1.08,fortification:1.12,diplomacy:1.15},'经营、求贤与外交并举，先稳住根基再择路开拓。'],
    ['wuanguo','guardian',{aggression:.94,riskTolerance:.90,fortification:1.20,talentSeeking:.96},'重守土和军备，也敢为保住要地迎战。'],
    ['zhouxin','guardian',{aggression:.88,commerce:1.12,talentSeeking:1.10,diplomacy:1.08},'兼顾文务与守备，经营稳妥后再考虑进军。'],
    ['luxun','strategist',{aggression:.90,riskTolerance:.80,talentSeeking:1.16,fortification:1.20,farming:1.16},'先固防、筹粮和观望敌变，待条件有利再出兵。']
  ];
  const successors=Object.freeze(Object.fromEntries(successorRows.map(([leaderId,archetype,changes,description])=>{
    const person=officers[leaderId],base=archetypes[archetype];
    return [leaderId,Object.freeze({leaderId,name:person.name,label:person.label,archetype,tags:Object.freeze([base.label,person.label]),description,opening:person.assignment,ai:Object.freeze({...base.ai,...changes})})];
  })));
  const fallbackProfile=Object.freeze({id:'neutral',leaderId:null,name:'地方统领',label:'审势而行',tags:Object.freeze(['均衡']),description:'根据当前兵粮、城防与周边形势安排事务。',opening:'先安一城，再谋前路。',ai:neutralAI});
  const bounded=(value,min,max)=>Math.max(min,Math.min(max,value));
  function commonProfile(factionId,leader){
    const military=leader.commonKind==='military'||leader.commonKind!=='civil'&&leader.role==='military';
    const source=leader.baseStats||leader,defaults=military?{force:48,leadership:42,intellect:25,politics:25,charisma:35}:{force:20,leadership:25,intellect:45,politics:48,charisma:40};
    const stats=Object.fromEntries(Object.entries(defaults).map(([key,value])=>[key,Number.isFinite(source[key])?bounded(source[key],0,100):value]));
    const {force,leadership,intellect,politics,charisma}=stats;
    const key=military?(intellect>=Math.max(force,leadership)+12?'strategist':force>=leadership+10?'vanguard':leadership>=force+10?'guardian':'disciplined'):(charisma>=Math.max(intellect,politics)+10?'diplomat':intellect>=politics+10?'strategist':'steward');
    const base=archetypes[key],delta={aggression:(force-leadership)*.0004,riskTolerance:(force-intellect)*.0004,talentSeeking:(intellect+charisma-100)*.0003,commerce:(intellect-50)*.0008,farming:(politics-50)*.0008,fortification:(leadership-50)*.0008,diplomacy:(charisma-50)*.0008};
    const ai=Object.fromEntries(aiKeys.map(name=>[name,Math.round(bounded(base.ai[name]+delta[name],.8,1.2)*1000)/1000]));
    return {id:factionId||'neutral',leaderId:leader.id||null,name:leader.name||'地方统领',label:(military?'武人·':'文士·')+base.label,archetype:key,tags:[military?'统军':'治政',base.label],description:base.description,opening:military?'整好军伍、备足粮草，再定进退。':'理清政务、充实仓储，让诸事各得其所。',ai};
  }
  function profileFor(faction,leader){
    const id=typeof faction==='string'?faction:faction?.id,base=Object.hasOwn(profiles,id)?profiles[id]:null;
    const explicit=leader!==undefined&&leader!==null,leaderId=typeof leader==='string'?leader:explicit?leader.id:faction?.leaderId;
    if(Object.hasOwn(rulerById,leaderId))return rulerById[leaderId];
    if(Object.hasOwn(successors,leaderId))return {...successors[leaderId],id:id||'neutral'};
    if(leader&&typeof leader==='object'&&(['military','civil'].includes(leader.commonKind)||['military','civil'].includes(leader.role)))return commonProfile(id,leader);
    const declaredLeader=explicit||typeof faction==='object'&&faction!==null&&Object.hasOwn(faction,'leaderId');
    if(!declaredLeader)return base||fallbackProfile;
    return {...fallbackProfile,id:id||'neutral',leaderId:leaderId||null,name:leader?.name||fallbackProfile.name};
  }
  function aiFor(faction,leader){return profileFor(faction,leader).ai;}

  // Pair lines require both people to be present in the supplied live context.
  // An allied line never assumes a marriage, a fixed allegiance, or an event year.
  const pairs=[
    {ids:['liubei','caocao'],label:'青梅论志',battle:['孟德，此战各为其志。','玄德，阵前便各尽所能。'],surrender:[['孟德既肯以诚相待，备愿共谋安民。','玄德能容我展志，我便同你走这一程。'],['孟德，天下之志，备尚未肯放下。','玄德，我还有自己的路要走。']]},
    {ids:['zhangfei','lvbu'],label:'阵前争雄',battle:['吕布，来与俺正面一战！','张翼德，且看你有几分本事！']},
    {ids:['guanyu','caocao'],label:'知勇重义',battle:['孟德既来，关某便不留手。','云长的本事，我自会领教。'],surrender:[['孟德厚意，关某记下；既应此诺，便当尽责。','云长重义，我也愿与你以诚相待。'],['孟德知我，也当知关某不能轻改其志。','云长，此时尚非我改弦之日。']]},
    {ids:['sunce','taishici'],label:'惺惺相惜',battle:['子义，今日便较量一场！','伯符，请出招！'],march:['子义，与我并辔，看谁先到阵前！','伯符放心，既同行，便不负所约。'],surrender:[['子义如此相邀，孙策岂会扭捏！','伯符既信我，我便以信相报！'],['子义，阵前虽敬你，此时还不能应。','伯符厚意我明白，只是诺言未了。']]},
    {ids:['zhouyu','caocao'],label:'水陆斗智',battle:['兵多未必阵稳，请君细看。','公瑾，妙计还要阵前见分晓。']},
    {ids:['liubei','guanyu'],label:'桃园同心',march:['云长在侧，此行更须不负百姓。','兄长放心，关某自当护住侧翼。'],assignment:['云长，治城亦须尽心于民。','兄长所托，关某不敢有负。'],surrender:[['云长来相请，备自当与你再担此任。','兄长既至，关某愿再并肩尽力。'],['云长，这番去就，备仍有未解之处。','兄长容我想清，此诺不可轻许。']]},
    {ids:['liubei','zhangfei'],label:'桃园并辔',march:['翼德，勇气可嘉，也须护好后军。','大哥只管前行，俺把后边照应好！'],assignment:['翼德，城中百姓也要耐心照拂。','大哥放心，俺这回细细办！']},
    {ids:['guanyu','zhangfei'],label:'二将相顾',march:['翼德，前后呼应，不可只顾争先。','二哥在旁，俺冲得更有底气！'],assignment:['翼德，军令之外，也听听乡民的话。','二哥说得是，俺先把事情问明白。']},
    {ids:['liubei','zhaoyun'],label:'旧识重逢',march:['子龙同行，备便少了一分忧虑。','使君放心，云会照看每一队军士。'],surrender:[['子龙以诚相请，备愿同你再行一程。','使君仍怀安民之志，云愿追随。'],['子龙，我尚有必须交代的旧事。','使君厚意，云尚须想清去就。']]},
    {ids:['liubei','zhugeliang'],label:'如鱼得水',assignment:['孔明，军民诸事，还请你多费心。','主公有托，亮当逐事落实。'],march:['有孔明筹画，此行便依部署而进。','主公请放心，粮程与接应俱须安排。']},
    {ids:['sunce','zhouyu'],label:'总角同谋',march:['公瑾，你掌中军，我去试试前锋！','伯符，勇气之外，也请给谋划留一步。'],assignment:['公瑾，等城中诸务办妥，咱们再议远图。','伯符只管用人，诸务自当各得其序。']},
    {ids:['sunce','sunquan'],label:'兄弟共业',march:['仲谋，后方交待清楚，再随我看此一战。','兄长放心，我会把前后军务照应妥当。'],assignment:['仲谋，这些细事，最能磨出真本领。','兄长开拓在前，我也须学会守业用人。']},
    {ids:['zhouyu','lusu'],label:'同筹江山',assignment:['子敬看得长远，钱粮一事请多留心。','公瑾善于用兵，我便替前军多筹一步。'],march:['子敬，水陆相接处，还请照应粮运。','公瑾放心，后援不可落在兵锋之后。']},
    {ids:['zhouyu','zhugeliang'],label:'两智试锋',battle:['孔明奇策，瑜愿阵前领教。','公瑾善断，亮亦不敢轻忽。'],assignment:['孔明看此局，可还有另一条路？','公瑾所见甚明，亮愿补一二细处。']},
    {ids:['zhugeliang','pangtong'],label:'龙凤论策',assignment:['士元有奇思，也请照应施行的细处。','孔明善理细务，我便去寻那一着活棋。'],march:['士元，此行各尽所长，莫使兵粮脱节。','孔明把根本守稳，我来替前阵寻路。']},
    {ids:['zhugeliang','huangyueying'],label:'巧思相参',assignment:['此处条目繁杂，愿与你逐一推敲。','先把费力之处找出来，章程便更好用。'],march:['粮程虽定，仍请帮我再查车具损耗。','车具与调度相配，才不让兵锋空等。']},
    {ids:['sunce','daqiao'],label:'刚柔相济',assignment:['我性子急，细务还请替我多看一眼。','伯符向前时，也请记得照应留城的人。'],march:['此行自会谨慎，城中诸事还望照应。','伯符有胆气，更要把平安带回来。']},
    {ids:['zhouyu','xiaoqiao'],label:'知音相和',assignment:['诸务如曲，各归其位，方能相和。','公瑾定大节，我便照看容易忽略的细处。'],march:['此去依势进军，未必只争声势。','声势之外，公瑾也请多看沿途消息。']},
    {ids:['lvbu','diaochan'],label:'锋芒与周旋',assignment:['这些纷杂人事，还请替我理个明白。','将军肯耐心听，许多结便能慢慢解开。'],march:['此去看我破敌，何须多虑！','将军勇猛，也请给平安归来留一条路。']},
    {ids:['lvbu','zhangliao'],label:'并州战友',march:['文远，跟紧我的马旗，一同破阵！','将军向前，辽便守住侧翼。'],battle:['文远既在对面，此战便各凭本事！','将军勇冠三军，辽仍当守好此阵。']},
    {ids:['caocao','xunyu'],label:'军政相济',assignment:['文若，前军求胜，后方根本便托你了。','明公放心，根本稳固，进取方能持久。'],march:['文若的筹画已定，诸军依令而行。','明公进兵，也请记住人心与粮秣同样紧要。']},
    {ids:['caocao','guojia'],label:'知谋善任',assignment:['奉孝，别只说有趣，且把可行处讲明。','明公若肯试，我便将此局利害说透。'],march:['奉孝看中的破绽，我也想亲眼一见。','明公，此行先试敌心，胜机便会自己露出来。']},
    {ids:['caocao','dianwei'],label:'帐前相护',march:['恶来，勇气可嘉，也须照应后队。','主公放心，俺把前后都看紧！'],assignment:['恶来，城务也要认真，不能只顾操戟。','主公交代的，俺一件件办！']},
    {ids:['caocao','xuchu'],label:'虎卫同行',march:['仲康随行，这条路便更稳当了。','主公跟紧，俺不让人近前！']},
    {ids:['mateng','machao'],label:'父子西征',march:['孟起，勇则勇矣，莫离后军太远。','父亲放心，前锋开路也会留好接应。'],assignment:['孟起，养兵之前，须先懂百姓的难处。','父亲教诲，超会记在办事之中。']},
    {ids:['machao','pangde'],label:'西凉并骑',march:['令明，此战你我并进，教敌军难顾两翼！','孟起放心，我军旗号必不相失。']},
    {ids:['zhangfei','yanyan'],label:'敬重老将',battle:['老将军，来与俺堂堂正正打一阵！','张将军有胆，老夫也不会相让！'],march:['老将军熟路，俺便依你的向导走！','张将军肯相敬，老夫自当把前路看清。'],surrender:[['老将军说话硬朗，俺便认你这份诚！','将军既敬老夫骨气，老夫愿尽此一力。'],['老将军，俺心里这关还没过。','败阵我认，折志之言却不必再说。']]},
    {ids:['guanyu','huangzhong'],label:'刀弓相敬',battle:['老将军弓力如何，关某愿一试。','关将军请看，老夫弓弦尚劲！'],march:['老将军压住一翼，关某便可放心向前。','云长放心，远处的敌阵老夫照应。']},
    {ids:['kongrong','taishici'],label:'信义相知',march:['子义重信，此行愿与你相互照应。','府君厚意在心，慈自当尽力。'],surrender:[['子义以信相请，融愿同谋安民。','府君信我，慈便不负此番托付。'],['子义，融尚有心中所守。','府君见谅，慈尚有旧诺未了。']]},
    {ids:['liubei','mizhu'],label:'倾心相助',assignment:['子仲屡为钱粮费心，备不敢相忘。','府君所图若在安民，竺便尽力筹措。']},
    {ids:['gongsunzan','zhaoyun'],label:'白马旧阵',march:['子龙随白马旗前行，且看北地锋芒。','将军放心，云会与各部相互照应。'],battle:['子龙既各为其主，今日便阵前见高低。','将军昔日相识，今日仍须尽此守责。']},
    {ids:['yuanshao','caocao'],label:'旧交争锋',battle:['孟德，此番且看河北众志！','本初，兵多之外，还要看调度。']},
    {ids:['yuanshu','yuanshao'],label:'袁氏争雄',battle:['本初，你我今日各看手段！','公路，且先把眼前的阵摆稳。']},
    {ids:['caocao','chengong'],label:'旧路异志',battle:['公台所谋，我自会留心。','孟德知我，也当知我不会轻让。']},
    {ids:['yanliang','wenchou'],label:'河北双锋',march:['文丑，你守侧翼，我先撞开前阵！','颜良向前，我这一路也不会落后！']},
    {ids:['huangzhong','yanyan'],label:'宿将论勇',march:['严将军，你我老卒也能走在前头！','汉升这话正合我意，且教后生看着！']},
    {ids:['sunquan','lusu'],label:'君臣远图',assignment:['子敬，眼前钱粮之外，也请共议长远。','主公肯听远谋，肃愿把利害一一陈明。']},
    {ids:['sunquan','luxun'],label:'纳谏任贤',assignment:['伯言所见，不妨直说，不必拘于资历。','主公肯听，逊便将细处据实陈明。']},
    {ids:['zhugeliang','jiangwei'],label:'传习兵略',march:['伯约，临阵审势，切莫只凭锐气。','先生部署，维会牢记，也会留心应变。'],assignment:['伯约，兵法之外，也须明白治军理民。','先生所教，维当逐事求实。']},
    {ids:['chengui','chendeng'],label:'父子经略',assignment:['元龙，先看透人情，再谈如何施行。','父亲放心，谋划与田政，登都会做实。']}
  ];
  function pairEvent(event){return ['governor','farming','commerce','training','search'].includes(event)?'assignment':['transfer','occupy'].includes(event)?'march':event;}
  function pairLine(g,partner,event,context={}){
    const a=voiceFor(g),b=voiceFor(partner);if(!a||!b||a.id===b.id)return null;
    const type=pairEvent(event);
    for(const pair of pairs){
      const index=pair.ids.indexOf(a.id);if(index<0||pair.ids[1-index]!==b.id)continue;
      const lines=type==='surrender'?pair.surrender?.[context.success===true?0:1]:pair[type];
      if(lines)return lines[index];
    }
    return null;
  }
  function encounter(first,second,event,context={}){
    for(const one of first||[])for(const two of second||[]){
      const lineOne=pairLine(one,two,event,context),lineTwo=pairLine(two,one,event,context);
      if(lineOne&&lineTwo)return {one,two,lineOne,lineTwo};
    }
    return null;
  }
  return {revision:'personalities-v30',profiles,officers,pairs,archetypes,successors,neutralAI,profileFor,aiFor,voiceFor,pairLine,encounter};
});
